function ding(id)
{
	jQ.get('/comment.php?do=grade',{
		cid:id,
		act:'ding',
		t:Math.random()
	},function(n){
		jQ("#c_ding_"+id).html(n);
	})
}
function cai(id)
{
	jQ.get('/comment.php?do=grade',{
		cid:id,
		act:'cai',
		t:Math.random()
	},function(n){
		jQ("#c_cai_"+id).html(n);
	})
}
function star_onmouse_over(objName,index,msg_id){
     
     obj=document.getElementsByName(objName);
     count=obj.length; //星星的数量
     for (i=0;i<count;i++ )
     {
     obj[i].className=i<index?"click_on":"";
     
     }
     document.getElementById(msg_id).innerHTML=obj[index-1].title;
   }

   function star_onmouse_out(objName,star_val_obj,msg_id){   
     
     obj=document.getElementsByName(objName);
     count=obj.length;
     star_val=document.getElementById(star_val_obj).value;
     if(star_val==0){


      for (i=0;i<count;i++ )
      {
      obj[i].className="";
     
      }
     document.getElementById(msg_id).innerHTML='欢迎评分';
     }
     else{
   
     star_onmouse_over(objName,star_val,msg_id)

     }

   }
   function star_onclick(id,index,appid){
     	jQ.get("/comment.php?do=grade",{cid:id,f:index,t:Math.random(),act:'pf',idtype:appid},function(data){
			if(data == -255)
			{
				alert('你已经评过分了，请不要重复评分');
			}
			else
			{
				alert('评分成功');
				var d = data.split(',')
				jQ("#pjfs").html(d[2]);
				jQ("#pjpf").removeClass();
				jQ("#pjpf").addClass('start'+d[1]);
			}
		})
		document.getElementById('score').value=index;
   }
  function stateText(t,s)
  {
	  var m = '';
	  if(s =='want')
	  {
		  switch(t)
		  {
			  case "booksid":
			  m = '我想看这本书';
			  break;
			  case "moviesid":
			   m = '我想看这部电影';
			  break;
			  case "musicid":
			   m = '我想听这首歌';
			  break;
			  case "artsid":
			   m = '我想看这书画作品';
			  break;
		  }
	   }
	   else
	   {
			 switch(t)
		  {
			  case "booksid":
			  m = '我看过这本书';
			  break;
			  case "moviesid":
			   m = '我看过这部电影';
			  break;
			  case "musicid":
			   m = '我听过这首歌';
			  break;
			  case "artsid":
			   m = '我看过这书画作品';
			  break;
		  }
	   }
	   jQ("#nowmystate").html(m);
  }
  function mystate(s,type,id)
   {
	   	jQ.get("/comment.php?do=mystate",{state:s,idtype:type,t:Math.random(),appid:id,act:'setmy'},function(data){
				stateText(type,s);
		});
   }
   function getmystate(id,idtype)
   {
   		jQ.get("/comment.php?do=mystate",{act:'getmy',idtype:idtype,t:Math.random(),appid:id},function(data){
			    if(data != '')
				{
				stateText(idtype,data);
				
				}
		});
   }
  function showtext(id)
	{	
		jQ('#comment_content_'+id).html(jQ('#tmphide_comment_'+id).val());
	}
	function commentlist(id,t,by)
	{
		jQ.get("comment.php?do=list",{
			idtype:t,
			id:id,
			page:1,
			ajax:true,
			by:by,
			t:Math.random()
		},function(data){		
			jQ("#comment_ul").html(data);
		})
	}
