<?php
/*
	[UCenter Home] (C) 2007-2008 Comsenz Inc.
	$Id: space.php 13003 2009-08-05 06:46:06Z liguode $
*/

include_once('./common.php');


//�Ƿ�ر�վ��
checkclose();


//��������
$dos = array('index','create','my','view','search','new','list','newbooks','tag');

//��ȡ����
$isinvite = 0;
$uid = empty($_GET['uid'])?0:intval($_GET['uid']);
$username = empty($_GET['username'])?'':$_GET['username'];
$domain = empty($_GET['domain'])?'':$_GET['domain'];
$do = (!empty($_GET['do']) && in_array($_GET['do'], $dos))?$_GET['do']:'index';



//��ȡ�ռ�
if($uid) {
	$space = getspace($uid, 'uid');
} elseif ($username) {
	$space = getspace($username, 'username');
} elseif ($domain) {
	$space = getspace($domain, 'domain');
} elseif ($_SGLOBAL['supe_uid']) {
	$space = getspace($_SGLOBAL['supe_uid'], 'uid');
}

if($space) {
	
	//��֤�ռ��Ƿ�����
	if($space['flag'] == -1) {
		showmessage('space_has_been_locked');
	}
	
	//��˽���
	/*if(empty($isinvite) || ($isinvite<0 && $code != space_key($space, $_GET['app']))) {
		//�ο�
		if(empty($_SCONFIG['networkpublic'])) {
			checklogin();//��Ҫ��¼
		}
		if(!ckprivacy($do)) {
			include template('space_privacy');
			exit();
		}
	}*/
	
	
} elseif($uid) {

	//�жϵ�ǰ�û��Ƿ�ɾ��
	$query = $_SGLOBAL['db']->query("SELECT * FROM ".tname('spacelog')." WHERE uid='$uid' AND flag='-1'");
	if($value = $_SGLOBAL['db']->fetch_array($query)) {
		showmessage('the_space_has_been_closed');
	}
	
	//δ��ͨ�ռ�
	include_once(S_ROOT.'./uc_client/client.php');
	if($user = uc_get_user($uid, 1)) {
		$space = array('uid' => $user[0], 'username' => $user[1], 'dateline'=>$_SGLOBAL['timestamp'], 'friends'=>array());
		$_SN[$space['uid']] = $space['username'];
	}
}


//����
include_once(S_ROOT."./movies/source/{$do}.php");

?>