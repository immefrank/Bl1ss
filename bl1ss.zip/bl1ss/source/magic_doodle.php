<?php
/*
	[UCenter Home] (C) 2007-2008 Comsenz Inc.
	$Id: function_image.php 7350 2008-05-12 09:36:04Z liguode $
*/

if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}

//Ϳѻ��
if(submitcheck("usesubmit")) {

	//magic_use($mid, array(), true);

	$op = 'show';
}

?>