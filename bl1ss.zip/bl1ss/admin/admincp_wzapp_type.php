<?php
/*
	[UCenter Home] (C) 2007-2008 Comsenz Inc.
	$Id: admincp_profield.php 11954 2009-04-17 09:29:53Z liguode $
*/

if(!defined('IN_UCHOME') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

//Ȩ��
if(!checkperm('manageprofield')) {
	cpmessage('no_authority_management_operation');
}

@include_once(S_ROOT.'./data/data_profield.php');

//ȡ�õ�������
$thevalue = $typelist = array();
$_GET['typeid'] = empty($_GET['typeid'])?0:intval($_GET['typeid']);
if($_GET['typeid']) {
	$query = $_SGLOBAL['db']->query("SELECT * FROM ".tname('wzapptype')." WHERE id='$_GET[typeid]'");
	$thevalue = $_SGLOBAL['db']->fetch_array($query);
}


if(submitcheck('fieldsubmit')) 
{
  $info=$_POST['info'];
  if(empty($thevalue['id'])) {
		inserttable('wzapptype',$info);
	} else {
		updatetable('wzapptype', $info, array('id'=>$thevalue['id']));
	}
  
  cpmessage('do_success', 'admincp.php?ac=wzapp_type');
}

if(empty($_GET['op'])) 
{
	//�б�
	$query = $_SGLOBAL['db']->query("SELECT * FROM ".tname('wzapptype')." ORDER BY id");
	while ($value = $_SGLOBAL['db']->fetch_array($query)) {
		$typelist[] = $value;
	}

} 
elseif($_GET['op'] == 'add') 
{
	//����
	$thevalue = array('filedid' => 0, 'formtype' => 'text');

}
elseif($_GET['op'] == 'delete') 
{
	
		$_SGLOBAL['db']->query("delete from ".tname('wzapptype')." WHERE id='$_GET[typeid]'");
	 cpmessage('do_success', 'admincp.php?ac=wzapp_type');
}

?>