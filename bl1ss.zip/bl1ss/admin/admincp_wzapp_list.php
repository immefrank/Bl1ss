<?php
/*
	[UCenter Home] (C) 2007-2008 Comsenz Inc.
	$Id: admincp_blog.php 12568 2009-07-08 07:38:01Z zhengqingpeng $
*/

if(!defined('IN_UCHOME') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$lmid = empty($_GET['lmid'])?0:intval($_GET['lmid']);
//Ȩ��
if(!$allowmanage = checkperm('manageblog')) {
	$_GET['uid'] = $_SGLOBAL['supe_uid'];//ֻ�ܲ������˵�
	$_GET['username'] = '';
}

//��������
if(submitcheck('gosubmit')) 
{
	$idarr=$_POST['ids'];
	$optype=$_POST['optype'];
	if(!empty($idarr))
	{
	  if(!empty($optype))
	  {
	    if($optype=='del')
	    {
	      $_SGLOBAL['db']->query("delete FROM ".tname('wzapp')."  WHERE id in(".implode(',',$idarr).")");
	    }
	    elseif($optype=='sh')
	    {
	      $_SGLOBAL['db']->query("update ".tname('wzapp')." set status=1 WHERE id in(".implode(',',$idarr).")");	
	    }
	    elseif($optype=='qxsh')
	    {
	      $_SGLOBAL['db']->query("update ".tname('wzapp')." set status=0 WHERE id in(".implode(',',$idarr).")");		
	    }
		elseif($optype=='groom0')
	    {
	      $_SGLOBAL['db']->query("update ".tname('wzapp')." set groom=0 WHERE id in(".implode(',',$idarr).")");		
	    }
		elseif($optype=='groom1')
	    {
	      $_SGLOBAL['db']->query("update ".tname('wzapp')." set groom=1 WHERE id in(".implode(',',$idarr).")");		
	    }
		elseif($optype=='groom2')
	    {
	      $_SGLOBAL['db']->query("update ".tname('wzapp')." set groom=2 WHERE id in(".implode(',',$idarr).")");		
	    }
		elseif($optype=='groom3')
	    {
	      $_SGLOBAL['db']->query("update ".tname('wzapp')." set groom=3 WHERE id in(".implode(',',$idarr).")");		
	    }	
	    showmessage('do_success','admincp.php?ac=wzapp_list&lmid='.$lmid, 2);
	  }
	  //print_r($idarr);	
	}
}
//end
$page = empty($_GET['page'])?1:intval($_GET['page']);
if($page<1) $page=1;

//��ҳ
$perpage = 10;
$perpage = mob_perpage($perpage);

$start = ($page-1)*$perpage;

//��鿪ʼ��
ckstart($start, $perpage);
$list = array();
$count = 0;
$wheresql=' 1 ';
if(!empty($lmid))
{
	$wheresql.=" and a.lmid='{$lmid}'";
}
$theurl='admincp.php?ac=wzapp_list&lmid='.$lmid;

$list=array();
$count = $_SGLOBAL['db']->result($_SGLOBAL['db']->query("SELECT COUNT(*) FROM ".tname('wzapp')." a  WHERE $wheresql"),0);
if($count)
{
	$query=$_SGLOBAL['db']->query("SELECT a.*,b.typename FROM ".tname('wzapp')." a left join ".tname('wzapptype')." b on b.id=a.typeid  WHERE $wheresql order by a.submitdate desc LIMIT $start,$perpage");
	while ($value = $_SGLOBAL['db']->fetch_array($query)) 
	{
		$list[]=$value;
	}
	
	//��ҳ
  $multi = multi($count, $perpage, $page, $theurl);
}

if(empty($lmid))
{
 $actives = array('all' => ' class="active"');	
}
else
{
 $actives = array($lmid => ' class="active"');
}

//ʵ��
realname_get();

?>