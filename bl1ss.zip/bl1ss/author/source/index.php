<?php

if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}
$id = empty($_GET['id'])?0:intval($_GET['id']);
 //��ȡ������Ϣ
$query = $_SGLOBAL['db']->query("SELECT * FROM ".tname('author')."  WHERE id='$id'");
$con = $_SGLOBAL['db']->fetch_array($query);


$list = array();
$query=$_SGLOBAL['db']->query("SELECT * FROM ".tname('books')." where authorid=".$id."  order by id desc");
	while($row=$_SGLOBAL['db']->fetch_array($query))
	{
		$list[]=$row;
	}
realname_get();
include_once template("author/tpl/index");

?>