<?php

if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}
if(submitcheck('consubmit')) 
{
	$info=$_POST['info'];
	
	$bigimgdir='attachment/movies/bigimg';//ͼƬ���·��
	$smallimgdir='attachment/movies/smallimg';
	if(!empty($_FILES['upimgfile']['name']))
	{
		if(!is_dir(S_ROOT.$bigimgdir))
		{
			@mkdir(S_ROOT.$bigimgdir);
		}
		$coupic=explode('.',$_FILES['upimgfile']['name']);
		$imgtype=$coupic[(count($coupic)-1)];
		$imgfilename=$bigimgdir.'/'.mktime().'.'.$imgtype;
		move_uploaded_file($_FILES['upimgfile']['tmp_name'],$imgfilename);
		$info['pic']=$imgfilename;
	}
	$info['addtime']= date("Y-m-d H:i:s");
	$info['state']=0;
	$info['groom']= 0;
	$info['username']=$_SGLOBAL['username'];
	$info['userid']=$_SGLOBAL['supe_uid'];
	$tagarr = array();
	$tagarr = explode(",",$info['tag']);
	$mid = inserttable('movies',$info,1);
	foreach($tagarr as  $t)
	{
		$tag = array();
		$tag['tagname'] = $t;
		$tag['dateline'] = mktime();
		$tag['blognum'] = 0;
		$tag['close'] = 0;
		$tag['tagtype'] = 'movies';
		$tag['id'] =$mid;
		inserttable('tag',$tag);
	}
	
	showmessage('do_success','movies.php', 2);
}
realname_get();
include_once template("movies/tpl/create");

?>