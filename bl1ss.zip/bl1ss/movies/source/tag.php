<?php
if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}
$tpl = 'tag';
if(empty($_GET['k']))
{
	$taglist = array();
	$query=$_SGLOBAL['db']->query("SELECT * FROM ".tname('tag')." where tagtype='movies' ");
	while($row=$_SGLOBAL['db']->fetch_array($query))
	{
		$taglist[]=$row;
	}	
}
else
{
	$page = empty($_GET['page'])?1:intval($_GET['page']);
	$perpage = 6;
	$perpage = mob_perpage($perpage);
	$start = ($page-1)*$perpage;
	ckstart($start, $perpage);
	
	$k = $_GET['k'];
	$movieslist = array();
	$query=$_SGLOBAL['db']->query("SELECT * FROM ".tname('movies')." where tag like '%$k%'  LIMIT $start,$perpage");
	while($row=$_SGLOBAL['db']->fetch_array($query))
	{
		$row['taglist'] = GetTag($row['id'],'movies');
		$row['pf'] = GetPF($row['id'],'moviesid');
		$movieslist[]=$row;
		
	}
	$count = $_SGLOBAL['db']->result($_SGLOBAL['db']->query("SELECT count(11) FROM ".tname('movies')." where tag like '%$k%'"),0);
	$theurl='movies.php?do=tag&k='.urlencode($k);
	$multi = multi($count, $perpage, $page, $theurl);
}

realname_get();
include_once template("movies/tpl/tag");

?>