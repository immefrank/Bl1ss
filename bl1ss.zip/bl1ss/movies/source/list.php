<?php
if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}
$t = empty($_GET['t'])?'new':$_GET['t'];

$list = array();
$page = empty($_GET['page'])?1:intval($_GET['page']);
$perpage = 6;
$perpage = mob_perpage($perpage);
$start = ($page-1)*$perpage;
ckstart($start, $perpage);
$titleshow = 'list';
if($t == 'new')
{
	$query=$_SGLOBAL['db']->query("SELECT * FROM ".tname('movies')."  order by id desc LIMIT $start,$perpage");
	while($row=$_SGLOBAL['db']->fetch_array($query))
	{
		$row['taglist'] = GetTag($row['id'],'movies');
		$row['pf'] = GetPF($row['id'],'moviesid');
		$list[]=$row;
	}
	$count = $_SGLOBAL['db']->result($_SGLOBAL['db']->query("SELECT count(1) FROM ".tname('movies')),0);
	$theurl='movies.php?do=list&t=new';
	$titleshow = 'new movie list';
}
else if($t == 'type')
{
	
}
else if($t == 'gf')
{

	$query=$_SGLOBAL['db']->query("SELECT *,(select AVG(fenshu) from ".tname('wzapp_pf')." where  cid=b.id and idtype='moviesid') as wzpf FROM ".tname('movies')." as b   order by wzpf desc LIMIT $start,$perpage");
	while($row=$_SGLOBAL['db']->fetch_array($query))
	{
		$row['taglist'] = GetTag($row['id'],'movies');
		$row['pf'] = GetPF($row['id'],'moviesid');
		$list[]=$row;
	}
	$count = $_SGLOBAL['db']->result($_SGLOBAL['db']->query("SELECT count(1) FROM ".tname('books')),0);
	$theurl='movies.php?do=list&t=gf';
	$titleshow = 'High socre movie list';
}
else if($t == 'hot')
{
	$query=$_SGLOBAL['db']->query("SELECT * FROM ".tname('movies')."  order by viewcount desc LIMIT $start,$perpage");
	while($row=$_SGLOBAL['db']->fetch_array($query))
	{
		$row['taglist'] = GetTag($row['id'],'movies');
		$row['pf'] = GetPF($row['id'],'moviesid');
		$list[]=$row;
	}
	$count = $_SGLOBAL['db']->result($_SGLOBAL['db']->query("SELECT count(1) FROM ".tname('movies')),0);
	$theurl='movies.php?do=list&t=new';
	$titleshow = 'Hot movie list';
}
else if($t == 'tag')
{
	
	if(empty($_GET['k']))
	{
		$taglist = array();
		$query=$_SGLOBAL['db']->query("SELECT * FROM ".tname('tag')." where tagtype='books' and status=1  ");
		while($row=$_SGLOBAL['db']->fetch_array($query))
		{
			$taglist[]=$row;
		}	
	}
	else
	{
		$k = $_GET['k'];
		$query=$_SGLOBAL['db']->query("SELECT * FROM ".tname('books')." where tag like '%$k%' and status=1   LIMIT $start,$perpage");
		while($row=$_SGLOBAL['db']->fetch_array($query))
		{
			$row['taglist'] = GetTag($row['id'],'books');
			$row['pf'] = GetPF($row['id'],'booksid');
			$list[]=$row;
			
		}
		$count = $_SGLOBAL['db']->result($_SGLOBAL['db']->query("SELECT count(1) FROM ".tname('books')." where tag like '%$k%'"),0);
		$theurl='books.php?do=tag&k='.urlencode($k);
		$titleshow = 'TAG:'.$k;
	}
}

$multi = multi($count, $perpage, $page, $theurl);
realname_get();
include_once template("movies/tpl/list");

?>