<?php

if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}
//���µ�Ӱ��
$NewMovies = array();
$query=$_SGLOBAL['db']->query("SELECT * from ".tname("movies")." order by addtime desc LIMIT 0,4");
while ($value = $_SGLOBAL['db']->fetch_array($query)) 
{
	$value['pf'] = GetPF($value['id'],'moviesid');
	$value['tag'] = GetTag($value['id'],'movies');
	$NewMovies[]=$value;
}

//���ŵ�Ӱ��
$HotMovies = array();
$query=$_SGLOBAL['db']->query("SELECT * from ".tname("movies")." order by viewcount desc LIMIT 0,4");
while ($value = $_SGLOBAL['db']->fetch_array($query)) 
{
	$value['pf'] = GetPF($value['id'],'moviesid');
	$value['tag'] = GetTag($value['id'],'movies');
	$HotMovies[]=$value;
}

//�߷ֵ�Ӱ��
$HMovies = array();
$query=$_SGLOBAL['db']->query("SELECT *,(select AVG(fenshu) from ".tname('wzapp_pf')." where cid=m.id and idtype='moviesid') as wzpf from ".tname("movies")." as m order by wzpf desc LIMIT 0,4");
while ($value = $_SGLOBAL['db']->fetch_array($query)) 
{
	$value['pf'] = GetPF($value['id'],'moviesid');
	$value['tag'] = GetTag($value['id'],'movies');
	$HMovies[]=$value;
}
//�Ƽ��ĵ�Ӱ
$GroomBooks = array();
$GroomQuery=$_SGLOBAL['db']->query("SELECT * from ".tname("movies")." order by addtime desc LIMIT 0,2");
while ($value = $_SGLOBAL['db']->fetch_array($GroomQuery)) 
{
	$GroomBooks[]=$value;
}

//���ű�ǩ 
$HotTag = array();
$query=$_SGLOBAL['db']->query("SELECT *,count(1) as c FROM ".tname('tag')." where  tagtype='movies'  group by tagname order by c desc");
while($row=$_SGLOBAL['db']->fetch_array($query))
{
	$HotTag[]=$row;
	
}

$goodlist= array();
$query=$_SGLOBAL['db']->query("SELECT *,(select AVG(fenshu) from ".tname("wzapp_pf")." where cid=a.id and idtype='moviesid') as pf from ".tname("movies")." as a order by pf desc LIMIT 0,10");
while ($value = $_SGLOBAL['db']->fetch_array($query)) 
{
	$goodlist[]=$value;
}

//����֧�ֵ�Ӱ����
$Commentlist = array();
$query=$_SGLOBAL['db']->query("SELECT *,(select count(1) from ".tname('commentback')." where cid=c.cid) as bcount,(select count(1) from ".tname('commentlike')." where cid=c.cid) as lcount from ".tname('comment')." as c where c.idtype='moviesid' and c.title<>'' order by lcount desc  LIMIT 0,5");
while ($value = $_SGLOBAL['db']->fetch_array($query)) {
		$value['avatar'] = avatar($value['uid'],'small');
		
		$queryback = $_SGLOBAL['db']->query("SELECT id,cid,msg,uid,dateline,uname FROM ".tname('commentback')." as cb where cb.cid='$value[cid]'");	
		while($barr=$_SGLOBAL['db']->fetch_array($queryback))
		{
			$barr['avatar'] = avatar($barr['uid'],'small');
			$barr['dateline'] = $barr['dateline'];
			$value['backlist'][] = $barr;
		}
		$Commentlist[] = $value;
}
//���Ⱥ��
$grouplist = array();
$query=$_SGLOBAL['db']->query("SELECT * FROM ".tname('mtag')." where  fieldid='2'  order by membernum  desc LIMIT 0,4");
while($row=$_SGLOBAL['db']->fetch_array($query))
{
	if(empty($row['pic'])) {
				$row['pic'] = 'image/nologo.jpg';
			}
	$grouplist[]=$row;
	
}
realname_get();
include_once template("movies/tpl/index");

?>