<?php

if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}

//最新图书
$NewMoviesList = array();
$newquery=$_SGLOBAL['db']->query("SELECT * FROM ".tname('movies')." LIMIT 0,6");
while ($value = $_SGLOBAL['db']->fetch_array($newquery)) 
{
	$NewMoviesList[]=$value;
}
$HotBooks = array();
$hotquery=$_SGLOBAL['db']->query("SELECT a.*,b.typename FROM ".tname('wzapp')." a left join ".tname('wzapptype')." b on b.id=a.typeid  WHERE  a.status=1 order by a.viewcount desc LIMIT 0,6");
while ($value = $_SGLOBAL['db']->fetch_array($hotquery)) 
{
	$HotBooks[]=$value;
}
realname_get();
include_once template("movies/tpl/new");

?>