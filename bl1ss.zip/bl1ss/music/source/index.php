<?php

if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}
//������
$newmusic = array();
$query=$_SGLOBAL['db']->query("SELECT * from ".tname("music")." order by dateline desc LIMIT 0,6");
while ($value = $_SGLOBAL['db']->fetch_array($query)) 
{
	$value['pf'] = GetPF($value['mid'],'musicid');
	$value['tag'] = GetTag($value['mid'],'music');
	$newmusic[]=$value;
}

//��������
$hotmusic = array();
$query=$_SGLOBAL['db']->query("SELECT *  from ".tname("music")." order by viewnum desc LIMIT 0,6");
while ($value = $_SGLOBAL['db']->fetch_array($query)) 
{
	$value['pf'] = GetPF($value['mid'],'musicid');
	$value['tag'] = GetTag($value['mid'],'music');
	$hotmusic[]=$value;
}
//�߷�����
$hmusic = array();
$query=$_SGLOBAL['db']->query("SELECT *,(select AVG(fenshu) from ".tname('wzapp_pf')." where cid=m.mid and idtype='musicid') as wzpf from ".tname("music")." as m order by wzpf desc LIMIT 0,6");
while ($value = $_SGLOBAL['db']->fetch_array($query)) 
{
	$value['pf'] = GetPF($value['mid'],'musicid');
	$value['tag'] = GetTag($value['mid'],'music');
	$hmusic[]=$value;
}

$groommusic = array();
$query=$_SGLOBAL['db']->query("SELECT *,(select AVG(fenshu) from ".tname('wzapp_pf')." where cid=m.mid and idtype='musicid') as wzpf from ".tname("music")." as m where m.groom=1  LIMIT 0,4");
while ($value = $_SGLOBAL['db']->fetch_array($query)) 
{
	$value['pf'] = GetPF($value['mid'],'musicid');
	$value['tag'] = GetTag($value['mid'],'music');
	$groommusic[]=$value;
}
//��������
$hotcomment = array();
$query=$_SGLOBAL['db']->query("SELECT *,(select count(1) from ".tname("commentback")." where cid=c.cid ) as bcount from ".tname("comment")." as c where c.idtype='musicid' order by c.dsum desc LIMIT 0,5");
while ($value = $_SGLOBAL['db']->fetch_array($query)) 
{
	$value['avatar'] = avatar($value['authorid'],'small');
	$hotcomment[]=$value;
}

//���ű�ǩ
$taglist = array();
$query=$_SGLOBAL['db']->query("SELECT *,count(1) as c FROM ".tname('tag')." where  tagtype='music'  group by tagname order by c desc");
while ($value = $_SGLOBAL['db']->fetch_array($query)) 
{
	$taglist[]=$value;
}

//���Ⱥ��
$grouplist = array();
$query=$_SGLOBAL['db']->query("SELECT * FROM ".tname('mtag')." where  fieldid='3'  order by membernum  desc LIMIT 0,4");
while($row=$_SGLOBAL['db']->fetch_array($query))
{
	if(empty($row['pic'])) {
				$row['pic'] = 'image/nologo.jpg';
			}
	$grouplist[]=$row;
	
}

include_once template("music/tpl/index");

?>