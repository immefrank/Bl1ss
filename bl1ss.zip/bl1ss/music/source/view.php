<?php

if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}
$id = empty($_GET['id'])?0:intval($_GET['id']);
$query = $_SGLOBAL['db']->query("SELECT * from ".tname('music')." where mid=$id ");
$con = $_SGLOBAL['db']->fetch_array($query);
if(empty($con)) {
	showmessage('view_to_info_did_not_exist');
}

$tracks = array();
$query=$_SGLOBAL['db']->query("SELECT * FROM ".tname('music_tracks')."  WHERE mid=$id");
  while($row=$_SGLOBAL['db']->fetch_array($query))
  {
	$tracks[]=$row;
  }
 $pf = GetPF($id,'musicid');
$whoover = array();
$query=$_SGLOBAL['db']->query("SELECT * FROM ".tname('mymodstate')." as ms left join ".tname('member')." as m on ms.uid=m.uid  WHERE ms.idtype='musicid' and ms.appid=$id");
  while($row=$_SGLOBAL['db']->fetch_array($query))
  {
  	$row['avatar'] = avatar($row['uid'],'small');
	$whoover[]=$row;
  }
//���������
$_SGLOBAL['db']->query("update ".tname('music')." set viewnum=viewnum+1 WHERE mid=$id");	
include_once template("music/tpl/view");

?>