<?php

if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}
if(submitcheck('consubmit')) 
{
	$info=$_POST['info'];
	
	$bigimgdir='attachment/music/bigimg';//ͼƬ���·��
	$smallimgdir='attachment/music/smallimg';
	if(!empty($_FILES['upimgfile']['name']))
	{
		if(!is_dir(S_ROOT.$bigimgdir))
		{
			@mkdir(S_ROOT.$bigimgdir);
		}
		$coupic=explode('.',$_FILES['upimgfile']['name']);
		$imgtype=$coupic[(count($coupic)-1)];
		$imgfilename=$bigimgdir.'/'.mktime().'.'.$imgtype;
		move_uploaded_file($_FILES['upimgfile']['tmp_name'],$imgfilename);
		$info['pic']=$imgfilename;
	}
	$info['dateline']=mktime();
	$info['state']=0;
	$info['groom']= 0;
	$info['uid']=$_SGLOBAL['supe_uid'];
	$tagarr = array();
	$tagarr = explode(",",$info['tag']);
	$mid = inserttable('music',$info,1);
	foreach($tagarr as  $t)
	{
		$tag = array();
		$tag['tagname'] = $t;
		$tag['dateline'] = mktime();
		$tag['blognum'] = 0;
		$tag['close'] = 0;
		$tag['tagtype'] = 'music';
		$tag['id'] =$mid;
		inserttable('tag',$tag);
	}
	$tracks = $_POST['tracks'];
	foreach($tracks as  $t)
	{
		$mt = array();
		$mt['mid'] = $mid;
		$mt['mname'] = $t;
		$mt['filepath'] = '';
		inserttable('music_tracks',$mt);
	}
	
	showmessage('do_success','music.php', 2);
}
realname_get();
include_once template("music/tpl/create");

?>