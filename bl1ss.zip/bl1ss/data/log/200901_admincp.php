<?PHP exit;?>	2009-01-01 07:17:32		114.248.146.84	1	/admincp.php	
<?PHP exit;?>	2009-01-01 07:17:35		114.248.146.84	1	/admincp.php?ac=config	GET{ac=config;}
<?PHP exit;?>	2009-01-01 07:17:48		114.248.146.84	1	/admincp.php?ac=album	GET{ac=album;}
<?PHP exit;?>	2009-01-01 07:17:54		114.248.146.84	1	/admincp.php?ac=config	GET{ac=config;}
<?PHP exit;?>	2009-01-01 07:18:07		114.248.146.84	1	/admincp.php?ac=profilefield	GET{ac=profilefield;}
<?PHP exit;?>	2009-01-01 07:18:53		114.248.146.84	1	/admincp.php	
<?PHP exit;?>	2009-01-01 07:20:46		114.248.146.84	1	/admincp.php?ac=userapp	GET{ac=userapp;}
<?PHP exit;?>	2009-01-01 07:20:46		114.248.146.84	1	/admincp.php?ac=userapp&my_suffix=%2Fappadmin%2Flist	GET{ac=userapp;my_suffix=/appadmin/list;}
<?PHP exit;?>	2009-01-01 07:20:52		114.248.146.84	1	/admincp.php?ac=credit	GET{ac=credit;}
<?PHP exit;?>	2009-01-01 07:20:54		114.248.146.84	1	/admincp.php?ac=usergroup	GET{ac=usergroup;}
<?PHP exit;?>	2009-01-01 07:20:57		114.248.146.84	1	/admincp.php?ac=blog	GET{ac=blog;}
<?PHP exit;?>	2009-01-01 07:20:58		114.248.146.84	1	/admincp.php?ac=post	GET{ac=post;}
<?PHP exit;?>	2009-01-01 07:20:59		114.248.146.84	1	/admincp.php?ac=doing	GET{ac=doing;}
<?PHP exit;?>	2009-01-01 07:21:00		114.248.146.84	1	/admincp.php?ac=share	GET{ac=share;}
<?PHP exit;?>	2009-01-01 07:21:01		114.248.146.84	1	/admincp.php?ac=poll	GET{ac=poll;}
<?PHP exit;?>	2009-01-01 07:21:07		114.248.146.84	1	/admincp.php?ac=profilefield	GET{ac=profilefield;}
<?PHP exit;?>	2009-01-01 07:21:13		114.248.146.84	1	/admincp.php?ac=block	GET{ac=block;}
<?PHP exit;?>	2009-01-01 07:21:17		114.248.146.84	1	/admincp.php?ac=app	GET{ac=app;}
<?PHP exit;?>	2009-01-01 07:21:36		114.248.146.84	1	/admincp.php?ac=profilefield	GET{ac=profilefield;}
<?PHP exit;?>	2009-01-01 07:21:39		114.248.146.84	1	/admincp.php?ac=profilefield&op=add	GET{ac=profilefield;op=add;}
<?PHP exit;?>	2009-01-01 07:21:50		114.248.146.84	1	/admincp.php?ac=pic	GET{ac=pic;}
<?PHP exit;?>	2009-01-01 07:21:52		114.248.146.84	1	/admincp.php?ac=profilefield	GET{ac=profilefield;}
<?PHP exit;?>	2009-01-01 07:22:22		114.248.146.84	1	/admincp.php?ac=eventclass	GET{ac=eventclass;}
<?PHP exit;?>	2009-01-01 07:22:23		114.248.146.84	1	/admincp.php?ac=click	GET{ac=click;}
<?PHP exit;?>	2009-01-01 07:22:26		114.248.146.84	1	/admincp.php?ac=task	GET{ac=task;}
<?PHP exit;?>	2009-01-01 07:29:26		114.248.146.84	1	/admincp.php?ac=index	GET{ac=index;}
<?PHP exit;?>	2009-01-01 07:29:29		114.248.146.84	1	/admincp.php?ac=config	GET{ac=config;}
<?PHP exit;?>	2009-01-01 07:32:52		114.248.146.84	1	/admincp.php?ac=config	GET{ac=config;}
<?PHP exit;?>	2009-01-01 07:33:31		114.248.146.84	1	/admincp.php?ac=config	GET{ac=config;}POST{formhash=69d8d34a;config=a:85:{s:8:"sitename";s:12:"我的空间";s:10:"siteallurl";s:0:"";s:8:"template";s:8:"LiteBlue";s:10:"adminemail";s:23:"webmaster@121.52.210.65";s:10:"timeoffset";s:1:"8";s:8:"licensed";s:1:"0";s:9:"debuginfo";s:1:"0";s:8:"miibeian";s:0:"";s:13:"headercharset";s:1:"0";s:12:"allowrewrite";s:1:"0";s:10:"onlinehold";s:4:"1800";s:10:"updatestat";s:1:"1";s:10:"avatarreal";s:1:"0";s:6:"uc_dir";s:0:"";s:5:"my_ip";s:0:"";s:5:"close";s:1:"0";s:11:"closereason";s:0:"";s:13:"closeregister";s:1:"0";s:11:"closeinvite";s:1:"0";s:10:"checkemail";s:1:"0";s:9:"regipdate";s:0:"";s:7:"maxpage";s:3:"100";s:7:"feedday";s:1:"7";s:10:"feedmaxnum";s:3:"100";s:16:"showallfriendnum";s:2:"10";s:14:"feedhiddenicon";s:24:"friend,profile,task,wall";s:10:"feedhotnum";s:1:"3";s:11:"newspacenum";s:1:"3";s:10:"feedhotday";s:1:"2";s:10:"feedhotmin";s:1:"3";s:15:"feedtargetblank";s:1:"1";s:8:"feedread";s:1:"1";s:19:"my_closecheckupdate";s:1:"0";s:11:"my_showgift";s:1:"1";s:11:"networkpage";s:1:"1";s:12:"topcachetime";s:2:"60";s:9:"linkguide";s:1:"1";s:10:"starcredit";s:3:"100";s:12:"starlevelnum";s:1:"5";s:8:"groupnum";s:1:"8";s:9:"importnum";s:3:"100";s:9:"maxreward";s:2:"10";s:11:"sendmailday";s:1:"0";s:10:"openxmlrpc";s:1:"0";s:13:"uc_tagrelated";s:1:"1";s:17:"uc_tagrelatedtime";s:5:"86400";s:10:"allowcache";s:1:"1";s:9:"cachemode";s:8:"database";s:10:"cachegrade";s:1:"0";s:11:"allowdomain";s:1:"0";s:10:"holddomain";s:20:"www|*blog*|*space*|x";s:10:"domainroot";s:0:"";s:8:"realname";s:1:"0";s:9:"namecheck";s:1:"0";s:10:"namechange";s:1:"0";s:19:"name_allowviewspace";s:1:"1";s:16:"name_allowfriend";s:1:"1";s:14:"name_allowpoke";s:1:"1";s:15:"name_allowdoing";s:1:"1";s:14:"name_allowblog";s:1:"0";s:15:"name_allowalbum";s:1:"0";s:16:"name_allowthread";s:1:"0";s:14:"name_allowpoll";s:1:"0";s:15:"name_allowevent";s:1:"0";s:15:"name_allowshare";s:1:"0";s:17:"name_allowcomment";s:1:"0";s:14:"name_allowpost";s:1:"0";s:17:"name_allowuserapp";s:1:"0";s:20:"video_allowviewphoto";s:1:"0";s:17:"video_allowfriend";s:1:"0";s:15:"video_allowpoke";s:1:"0";s:15:"video_allowwall";s:1:"0";s:18:"video_allowcomment";s:1:"0";s:16:"video_allowdoing";s:1:"0";s:15:"video_allowblog";s:1:"0";s:16:"video_allowalbum";s:1:"0";s:17:"video_allowthread";s:1:"0";s:15:"video_allowpoll";s:1:"0";s:16:"video_allowevent";s:1:"0";s:16:"video_allowshare";s:1:"0";s:15:"video_allowpost";s:1:"0";s:18:"video_allowuserapp";s:1:"0";s:14:"allowwatermark";s:1:"0";s:8:"allowftp";s:1:"0";s:6:"ftpurl";s:0:"";};dataset=a:2:{s:6:"reason";s:0:"";s:12:"registerrule";s:0:"";};data=a:14:{s:10:"thumbwidth";s:3:"100";s:11:"thumbheight";s:3:"100";s:13:"maxthumbwidth";s:0:"";s:14:"maxthumbheight";s:0:"";s:13:"watermarkfile";s:0:"";s:12:"watermarkpos";s:1:"4";s:6:"ftpssl";s:1:"0";s:7:"ftphost";s:0:"";s:7:"ftpport";s:0:"";s:7:"ftpuser";s:0:"";s:11:"ftppassword";s:0:"";s:7:"ftppasv";s:1:"0";s:6:"ftpdir";s:0:"";s:10:"ftptimeout";s:0:"";};mail=a:9:{s:8:"mailsend";s:1:"1";s:13:"maildelimiter";s:1:"0";s:12:"mailusername";s:1:"1";s:6:"server";s:0:"";s:4:"port";s:0:"";s:4:"auth";s:1:"0";s:4:"from";s:0:"";s:13:"auth_username";s:0:"";s:13:"auth_password";s:0:"";};thevaluesubmit=提交;}
<?PHP exit;?>	2009-01-01 07:33:32		114.248.146.84	1	/admincp.php?ac=config	GET{ac=config;}
<?PHP exit;?>	2009-01-01 07:33:42		114.248.146.84	1	/admincp.php?ac=cache	GET{ac=cache;}
<?PHP exit;?>	2009-01-01 07:33:44		114.248.146.84	1	/admincp.php?ac=cache	GET{ac=cache;}POST{formhash=69d8d34a;cachetype=a:4:{i:0;s:3:"tpl";i:1;s:5:"block";i:2;s:8:"database";i:3;s:7:"network";};cachesubmit=缓存更新;}
<?PHP exit;?>	2009-01-01 07:33:46		114.248.146.84	1	/admincp.php?ac=cache	GET{ac=cache;}
<?PHP exit;?>	2009-01-01 07:38:40		114.248.146.84	1	/admincp.php	
<?PHP exit;?>	2009-01-01 07:38:45		114.248.146.84	1	/admincp.php?ac=cache	GET{ac=cache;}
<?PHP exit;?>	2009-01-01 07:38:46		114.248.146.84	1	/admincp.php?ac=cache	GET{ac=cache;}POST{formhash=69d8d34a;cachetype=a:4:{i:0;s:3:"tpl";i:1;s:5:"block";i:2;s:8:"database";i:3;s:7:"network";};cachesubmit=缓存更新;}
<?PHP exit;?>	2009-01-01 07:38:48		114.248.146.84	1	/admincp.php?ac=cache	GET{ac=cache;}
<?PHP exit;?>	2009-01-01 07:56:20		114.248.146.84	1	/admincp.php	
<?PHP exit;?>	2009-01-01 07:56:23		114.248.146.84	1	/admincp.php?ac=cache	GET{ac=cache;}
<?PHP exit;?>	2009-01-01 07:56:25		114.248.146.84	1	/admincp.php?ac=cache	GET{ac=cache;}POST{formhash=69d8d34a;cachetype=a:4:{i:0;s:3:"tpl";i:1;s:5:"block";i:2;s:8:"database";i:3;s:7:"network";};cachesubmit=缓存更新;}
<?PHP exit;?>	2009-01-01 07:56:26		114.248.146.84	1	/admincp.php?ac=cache	GET{ac=cache;}
<?PHP exit;?>	2009-01-01 08:55:34		114.248.146.84	1	/admincp.php	
<?PHP exit;?>	2009-01-01 08:55:36		114.248.146.84	1	/admincp.php?ac=cache	GET{ac=cache;}
<?PHP exit;?>	2009-01-01 08:55:38		114.248.146.84	1	/admincp.php?ac=cache	GET{ac=cache;}POST{formhash=69d8d34a;cachetype=a:4:{i:0;s:3:"tpl";i:1;s:5:"block";i:2;s:8:"database";i:3;s:7:"network";};cachesubmit=缓存更新;}
<?PHP exit;?>	2009-01-01 08:55:40		114.248.146.84	1	/admincp.php?ac=cache	GET{ac=cache;}
<?PHP exit;?>	2009-01-01 08:55:40		114.248.146.84	1	/admincp.php?ac=cache	GET{ac=cache;}
<?PHP exit;?>	2009-01-01 08:59:35		114.248.146.84	1	/admincp.php	
<?PHP exit;?>	2009-01-01 08:59:37		114.248.146.84	1	/admincp.php?ac=cache	GET{ac=cache;}
<?PHP exit;?>	2009-01-01 08:59:39		114.248.146.84	1	/admincp.php?ac=cache	GET{ac=cache;}POST{formhash=69d8d34a;cachetype=a:4:{i:0;s:3:"tpl";i:1;s:5:"block";i:2;s:8:"database";i:3;s:7:"network";};cachesubmit=缓存更新;}
