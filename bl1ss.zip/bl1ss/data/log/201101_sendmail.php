<?PHP exit;?>	2011-01-16 23:06:06		114.246.125.160	0	/do.php?ac=sendmail&rand=1295190365	sotime@163.com sendmail failed.
<?PHP exit;?>	2011-01-21 15:29:28		124.64.17.65	31	/do.php?ac=sendmail&rand=1295594968	ausgdyst@EC.com sendmail failed.
<?PHP exit;?>	2011-01-22 00:07:29		114.248.135.58	32	/do.php?ac=sendmail&rand=1295626049	kjahkjah@qq.com sendmail failed.
<?PHP exit;?>	2011-01-23 02:24:55		60.195.13.155	0	/do.php?ac=sendmail&rand=1295720695	jhgsau@qq.com sendmail failed.
<?PHP exit;?>	2011-01-28 14:14:34		124.115.0.156	0	/do.php?ac=sendmail&rand=1296195264	jxqpwd1@163.com sendmail failed.
<?PHP exit;?>	2011-01-28 15:21:29		124.115.0.110	0	/do.php?ac=sendmail&rand=1296199279	laohu000@163.com sendmail failed.
