<?PHP exit;?>	2011-03-16 17:08:39		114.246.125.145	38	/do.php?ac=sendmail&rand=1300266518	anyone@qq.com sendmail failed.
<?PHP exit;?>	2011-03-22 17:51:09		114.248.145.178	39	/do.php?ac=sendmail&rand=1300787469	akjugsadyu@qq.com sendmail failed.
