<?PHP exit;?>	2011-02-11 19:06:04		168.7.238.131	36	/do.php?ac=sendmail&rand=1297451163	frankzhang93@163.com sendmail failed.
<?PHP exit;?>	2011-02-18 03:16:25		114.246.131.202	37	/do.php?ac=sendmail&rand=1297970184	bl1ss@163.com sendmail failed.
