<?php
if(!defined('IN_UCHOME')) exit('Access Denied');
$_SGLOBAL['profield']=Array
	(
	1 => Array
		(
		'fieldid' => 1,
		'title' => 'Book Group',
		'formtype' => 'text',
		'inputnum' => 100,
		'mtagminnum' => '0',
		'manualmoderator' => '0',
		'manualmember' => 1
		),
	2 => Array
		(
		'fieldid' => 2,
		'title' => 'Movie Group',
		'formtype' => 'text',
		'inputnum' => 100,
		'mtagminnum' => '0',
		'manualmoderator' => '0',
		'manualmember' => 1
		),
	3 => Array
		(
		'fieldid' => 3,
		'title' => 'Music Group',
		'formtype' => 'text',
		'inputnum' => 100,
		'mtagminnum' => '0',
		'manualmoderator' => '0',
		'manualmember' => 1
		),
	4 => Array
		(
		'fieldid' => 4,
		'title' => 'Arts Group',
		'formtype' => 'text',
		'inputnum' => 100,
		'mtagminnum' => '0',
		'manualmoderator' => '0',
		'manualmember' => '0'
		)
	)
?>