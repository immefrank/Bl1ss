<?php
if(!defined('IN_UCHOME')) exit('Access Denied');
$_SGLOBAL['grouptitle']=Array
	(
	7 => Array
		(
		'grouptitle' => '高级会员',
		'color' => '',
		'icon' => ''
		),
	6 => Array
		(
		'grouptitle' => '中级会员',
		'color' => '',
		'icon' => ''
		),
	1 => Array
		(
		'grouptitle' => '站点管理员',
		'color' => 'red',
		'icon' => 'image/group/admin.gif'
		),
	2 => Array
		(
		'grouptitle' => '信息管理员',
		'color' => 'blue',
		'icon' => 'image/group/infor.gif'
		),
	3 => Array
		(
		'grouptitle' => '贵宾VIP',
		'color' => 'green',
		'icon' => 'image/group/vip.gif'
		),
	5 => Array
		(
		'grouptitle' => '普通会员',
		'color' => '',
		'icon' => ''
		),
	8 => Array
		(
		'grouptitle' => '禁止发言',
		'color' => '',
		'icon' => ''
		),
	9 => Array
		(
		'grouptitle' => '禁止访问',
		'color' => '',
		'icon' => ''
		),
	4 => Array
		(
		'grouptitle' => '受限会员',
		'color' => '',
		'icon' => ''
		)
	)
?>