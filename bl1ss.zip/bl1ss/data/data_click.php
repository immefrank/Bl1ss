<?php
if(!defined('IN_UCHOME')) exit('Access Denied');
$_SGLOBAL['click']=Array
	(
	'blogid' => Array
		(
		1 => Array
			(
			'clickid' => 1,
			'name' => '路过',
			'icon' => 'luguo.gif',
			'idtype' => 'blogid',
			'displayorder' => '0'
			),
		5 => Array
			(
			'clickid' => 5,
			'name' => '鸡蛋',
			'icon' => 'jidan.gif',
			'idtype' => 'blogid',
			'displayorder' => '0'
			),
		4 => Array
			(
			'clickid' => 4,
			'name' => '鲜花',
			'icon' => 'xianhua.gif',
			'idtype' => 'blogid',
			'displayorder' => '0'
			),
		3 => Array
			(
			'clickid' => 3,
			'name' => '握手',
			'icon' => 'woshou.gif',
			'idtype' => 'blogid',
			'displayorder' => '0'
			),
		2 => Array
			(
			'clickid' => 2,
			'name' => '雷人',
			'icon' => 'leiren.gif',
			'idtype' => 'blogid',
			'displayorder' => '0'
			)
		),
	'tid' => Array
		(
		14 => Array
			(
			'clickid' => 14,
			'name' => '鲜花',
			'icon' => 'xianhua.gif',
			'idtype' => 'tid',
			'displayorder' => '0'
			),
		13 => Array
			(
			'clickid' => 13,
			'name' => '雷人',
			'icon' => 'leiren.gif',
			'idtype' => 'tid',
			'displayorder' => '0'
			),
		12 => Array
			(
			'clickid' => 12,
			'name' => '迷惑',
			'icon' => 'mihuo.gif',
			'idtype' => 'tid',
			'displayorder' => '0'
			),
		11 => Array
			(
			'clickid' => 11,
			'name' => '搞笑',
			'icon' => 'gaoxiao.gif',
			'idtype' => 'tid',
			'displayorder' => '0'
			),
		15 => Array
			(
			'clickid' => 15,
			'name' => '鸡蛋',
			'icon' => 'jidan.gif',
			'idtype' => 'tid',
			'displayorder' => '0'
			)
		),
	'picid' => Array
		(
		10 => Array
			(
			'clickid' => 10,
			'name' => '鸡蛋',
			'icon' => 'jidan.gif',
			'idtype' => 'picid',
			'displayorder' => '0'
			),
		9 => Array
			(
			'clickid' => 9,
			'name' => '鲜花',
			'icon' => 'xianhua.gif',
			'idtype' => 'picid',
			'displayorder' => '0'
			),
		8 => Array
			(
			'clickid' => 8,
			'name' => '雷人',
			'icon' => 'leiren.gif',
			'idtype' => 'picid',
			'displayorder' => '0'
			),
		7 => Array
			(
			'clickid' => 7,
			'name' => '酷毙',
			'icon' => 'kubi.gif',
			'idtype' => 'picid',
			'displayorder' => '0'
			),
		6 => Array
			(
			'clickid' => 6,
			'name' => '漂亮',
			'icon' => 'piaoliang.gif',
			'idtype' => 'picid',
			'displayorder' => '0'
			)
		)
	)
?>