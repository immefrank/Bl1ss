<?php
if(!defined('IN_UCHOME')) exit('Access Denied');
$_SGLOBAL['setting']=Array
	(
	'thumbwidth' => 100,
	'thumbheight' => 100,
	'maxthumbwidth' => '',
	'maxthumbheight' => '',
	'watermarkfile' => '',
	'watermarkpos' => 4,
	'ftpssl' => '0',
	'ftphost' => '',
	'ftpport' => '',
	'ftpuser' => '',
	'ftppassword' => '',
	'ftppasv' => '0',
	'ftpdir' => '',
	'ftptimeout' => ''
	)
?>