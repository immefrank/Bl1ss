<?php
if(!defined('IN_UCHOME')) exit('Access Denied');
$_SGLOBAL['app']=Array
	(
	1 => Array
		(
		'name' => '个人家园',
		'url' => 'http://121.52.210.65',
		'type' => 'UCHOME',
		'open' => '0',
		'icon' => 'uchome'
		)
	)
?>