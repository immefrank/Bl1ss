<?php
if(!defined('IN_UCHOME')) exit('Access Denied');
$_SGLOBAL['spam']=Array
	(

	)
?>