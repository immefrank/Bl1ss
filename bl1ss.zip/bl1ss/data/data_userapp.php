<?php
if(!defined('IN_UCHOME')) exit('Access Denied');
$_SGLOBAL['userapp']=Array
	(
	1058412 => Array
		(
		'appid' => 1058412,
		'appname' => '热血球球',
		'narrow' => '0',
		'flag' => 1,
		'version' => 1,
		'displaymethod' => '0',
		'displayorder' => 1
		)
	)
?>