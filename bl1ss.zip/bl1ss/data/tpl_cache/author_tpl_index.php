<?php if(!defined('IN_UCHOME')) exit('Access Denied');?><?php subtplcheck('author/tpl/index', '1303230046', 'author/tpl/index');?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?=$con['authorname']?> - bl1ss Space</title>
<style type="text/css">
body ul,li{ padding:0; margin:0; list-style-type:none}
a img{ border:none}
.wrapper { width:950px;margin:0 auto; position:relative }
.bg { position:absolute;top:0;left:0;z-index:-1;width:100%;height:300px;background:#d0c6db; }
.bg { background: #b5c2c9 url(img/bg.png) no-repeat left bottom }
.nav-items { clear:both;*display:inline-block; }
.nav-items li { float:left;position:relative;height:28px;line-height:28px;*line-height:25px;background:#d0c6db;margin-right:2px;margin-top:2px; }
.nav-items li a { display:block;padding:0 15px 0;color:#fff;outline:none;*padding-top:3px; }
.nav-items li a:link,.nav-items li a:visited { color:#fff; } 
.nav-items li a:hover,.nav-items li a:active { background-color:transparent; }
.nav-items li.on { border:1px solid #ddd;padding-bottom:1px;margin-top:0;border-bottom:none;background:#fff; }
.nav-items li.on a:hover { background-color:#fff; }
.nav-items li.on a, .nav-items li.on a:link,.nav-items li.on a:visited { color:#4e4e4e; padding:1px 14px 0;*padding-top:3px; }
.nav-items li.on em { display: inline-block; *display: inline; zoom: 1;vertical-align:middle;line-height: 20em;overflow: hidden; width: 14px; height: 26px;*height:25px; margin: 0 -5px 0 5px; background:url(http://site.douban.com/pics/site/sp_all_4.png) no-repeat 0 -70px;cursor:pointer; }
.nav-items li.on a:hover em,
.nav-items li.on em.current { background-position: 0 -95px; }
.nav-items li.opt { position:relative; z-index: 888; }
.nav-items li.opt a { padding: 0 8px 0;*padding-top:3px; }
.nav-items li.opt ul { display: none; position: absolute; z-index: 999; width: 150px; border: 1px solid #bbc5be; margin: -1px 0 0; padding: 5px 0; *padding: 5px 0 2px; background: #fff; }
.nav-items li.opt li { float: none; margin: 0; padding: 0; height: 25px; line-height: 25px; width: auto; background: none }
.nav-items li.opt li a:link,.nav-items li.opt li a:visited { display: block; color: #5c6a6e; padding: 0 8px }
.nav-items li.opt li a:hover { background: #eceaea }
.sp-logo { margin-bottom:15px; }
.sp-nav:after, .sp-logo:after { content:'\0020';clear:both;display:block; }
.sp-logo .logo { float:left; }
.sp-logo .sigture { float:left;padding-top:14px;color:#ddd; }
.sp-logo img { vertical-align:middle;margin-right:12px;margin-bottom:5px;-moz-border-radius:5px;-webkit-border-radius:5px;border-radius:5px; }
.sp-logo a,
.sp-logo a:link, .sp-logo a:visited { font-size:25px;color:#fff;font-family:Georgia;outline:none; }
.sp-logo a:hover, .sp-logo a:active { background-color:transparent; }


/* system theme only */
.sp-logo a:link,
.sp-logo a:visited,
.sp-logo a:active,
.sp-logo a:hover { color: #333 }
.mod h2 { color: #2b4e5a }

/* site backgound */
.bg { background: #b5c2c9 url(http://site.douban.com/pics/site/theme/4/bg.png) no-repeat left bottom }

/* top banner */
.sp-nav { background-color: #e3ecf0 }

/* tab */
.nav-items li { background: #94becb }
.nav-items li a:link,
.nav-items li a:visited { color: #fff }
.nav-items li.on { border-color: #94becb }

/* global link */
.content-nav a,
.mod a,
.type-nav a,
.top-nav a:link,
.top-nav a:visited,
.top-nav a:hover,
.top-nav a:active,
#footer a { color: #3c859c }
.content-nav a:hover,
.mod a:hover, 
.type-nav .on a,
.type-nav a:hover,
.top-nav .top-nav-info a:hover,
#footer a:hover { color: #fff; background-color: #3c859c }

/* for colorPicker */
#theme-bg { background-color: #b5c2c9 }
#theme-banner { background-color: #e3ecf0 }
#theme-tag-bg { background-color: #94becb }
#theme-tag-link { background-color: #fff }
#theme-link { background-color: #3c859c }

.cl{clear:both; height:0; overflow:hidden;}
#zplb li{ float:left; width:20%; margin-bottom:20px;}
#zplb li p{ margin:0; padding:0; line-height:24px; white-space:nowrap; overflow:hidden}
</style>
</head>

<body>
<div class="wrapper">
<div style="position:absolute; right:95px; top:20px"><img src="<?=$con['pic']?>" /></div>
<div id="header">
<div style="height:40px;"></div>
<div style="  padding:20px 20px 0 20px ;background:#e3ecf0; ">
<div class="sp-nav">
                <div class="sp-logo">
                  <a href="http://site.douban.com/thumbgirl/" class="logo"><img src="<?=$con['pic']?>" style="background:url(http://img3.douban.com/view/site/small/public/eeb9d112c5dcc82.jpg) no-repeat 0 0;" width="48" height="48"><?=$con['authorname']?></a>
                </div>
                
 
 
 
<div class="nav-items">
 
    <ul>
        <li class="on">
            <a href="author.php?do=index&id=<?=$con['id']?>" hidefocus="true">
                
                
                <span>作品</span>
            </a>
        </li>
        <li>
            <a href="#" hidefocus="true">
                
                
                <span>日志</span>
            </a>
        </li>
        <li>
            <a href="#" hidefocus="true">
                
                
                <span>交流</span>
            </a>
        </li>
        <li>
            <a href="#" hidefocus="true">
                
                
                <span>图片</span>
            </a>
        </li>
    </ul>
</div>
 
            </div>
</div>
<div class="cl"></div>
</div>

<div style="background:#fff; height:500px; padding:20px">
<h2>作品列表</h2>
<div id="zplb">
<ul>
<?php if(is_array($list)) { foreach($list as $v) { ?>
<li><a href="books.php?do=view&id=<?=$v['id']?>" title="<?=$v['conname']?>"><img src="<?=$v['smallimg']?>" width="105" height="145" /></a></li>
<?php } } ?>
</ul>
</div>
</div>
<div style="text-align:center; line-height:22px; border-top:1px solid #b5c2c9">
Bl1ss CopyRight 2011
</div>
</div>
<div class="bg"></div>

</body>
</html>
<?php ob_out();?>