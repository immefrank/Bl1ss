<?php if(!defined('IN_UCHOME')) exit('Access Denied');?><?php subtplcheck('template/default/space_blog_view|template/default/header|template/default/space_menu|template/default/space_click|template/default/space_comment_li|template/default/footer', '1303361183', 'template/default/space_blog_view');?>﻿<?php $_TPL['titles'] = array($blog['subject'], '日志'); ?>
<?php $friendsname = array(1 => '仅好友可见',2 => '指定好友可见',3 => '仅自己可见',4 => '凭密码可见'); ?>
﻿<?php if(empty($_SGLOBAL['inajax'])) { ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=<?=$_SC['charset']?>" />
<meta http-equiv="x-ua-compatible" content="ie=7" />
<title><?php if($_TPL['titles']) { ?><?php if(is_array($_TPL['titles'])) { foreach($_TPL['titles'] as $value) { ?><?php if($value) { ?><?=$value?> - <?php } ?><?php } } ?><?php } ?><?php if($_SN[$space['uid']]) { ?><?=$_SN[$space['uid']]?> - <?php } ?><?=$_SCONFIG['sitename']?></title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<script language="javascript" type="text/javascript" src="source/script_jquery.js"></script>
<script language="javascript" type="text/javascript" src="source/script_cookie.js"></script>
<script language="javascript" type="text/javascript" src="source/script_common.js"></script>
<script language="javascript" type="text/javascript" src="source/script_menu.js"></script>
<script language="javascript" type="text/javascript" src="source/script_ajax.js"></script>
<script language="javascript" type="text/javascript" src="source/script_face.js"></script>
<script language="javascript" type="text/javascript" src="source/script_manage.js"></script>
<link id="skinc" href="/template/default/style.css" rel="stylesheet" type="text/css" />
<?php if($_TPL['css']) { ?>
<link id="skinc" href="/template/default/<?=$_TPL['css']?>.css" rel="stylesheet" type="text/css" />
<?php } ?>
<?php if(!empty($_SGLOBAL['space_theme'])) { ?>
<link id="skinc" href="/theme/<?=$_SGLOBAL['space_theme']?>/style.css" rel="stylesheet" type="text/css" />
<?php } elseif($_SCONFIG['template'] != 'default') { ?>
<link id="skinc" href="/template/<?=$_SCONFIG['template']?>/style.css" rel="stylesheet" type="text/css" />
<?php } ?>

<style type="text/css">
<?php if(!empty($_SGLOBAL['space_css'])) { ?>
<?=$_SGLOBAL['space_css']?> 
<?php } ?>
</style>
<link rel="shortcut icon" href="image/favicon.ico" />
<link rel="edituri" type="application/rsd+xml" title="rsd" href="xmlrpc.php?rsd=<?=$space['uid']?>" />

</head>
<body>
<div id="append_parent"></div>
<div id="ajaxwaitid"></div>
<div id="header">
<div class="wp">
<div id="logo"></div>

<div id="nav">
<div>
<?php if($_SGLOBAL['supe_uid']) { ?>
<a href="space.php">myspace</a>
<a href="cp.php?ac=common&op=logout&uhash=<?=$_SGLOBAL['uhash']?>">logout</a>
<?php } else { ?>
<a href="do.php?ac=<?=$_SCONFIG['login_action']?>">Share</a> | 
<a href="do.php?ac=<?=$_SCONFIG['login_action']?>">Login</a> | 
<a href="do.php?ac=<?=$_SCONFIG['register_action']?>">Register</a>
<?php } ?>
</div>
<div id="navitem">
<a href="network.php"><img src="/template/default/i/nav_home.jpg" /></a>
<a href="space.php?act=home&view=all"><img src="/template/default/i/nav_comm.jpg" /></a>
<a href="books.php"><img src="/template/default/i/nav_books.jpg" /></a>
<a href="movies.php"><img src="/template/default/i/nav_mov.jpg" /></a>
<a href="music.php"><img src="/template/default/i/nav_mus.jpg" /></a>
<a href="arts.php"><img src="/template/default/i/nav_art.jpg" /></a>
</div>
</div>
<div class="cl"></div>
</div>
</div>

<div id="wrap">

<?php if(empty($_TPL['nosidebar'])) { ?>
<div id="main">
<div id="app_sidebar">
<?php if($_SGLOBAL['supe_uid']) { ?>
    <h2>Personal Center</h2>
<ul class="app_list" id="default_userapp">
<li><a href="space.php?do=doing"><span class="icon i-app24 i-app24-status"></span>Fresh things</a></li>
<li><a href="space.php?do=album"><span class="icon i-app24 i-app24-album"></span>Albums</a><em><a href="cp.php?ac=upload" class="gray">upload</a></em></li>
<li><a href="space.php?do=blog"><span class="icon i-app24 i-app24-blog"></span>WebLog</a><em><a href="cp.php?ac=blog" class="gray">issue</a></em></li>
</ul>

            <h2>互动中心</h2>
<ul class="app_list" id="default_userapp">
<li><a href="space.php?do=poll"><span class="icon i-app24 i-app24-vote"></span>投票</a><em><a href="cp.php?ac=poll" class="gray">发起</a></em></li>
<li><a href="space.php?do=mtag"><span class="icon i-app24 i-app24-thread"></span>群组</a><em><a href="cp.php?ac=thread" class="gray">话题</a></em></li>
<li><a href="space.php?do=event"><span class="icon i-app24 i-app24-event"></span>活动</a><em><a href="cp.php?ac=event" class="gray">发起</a></em></li>
<li><a href="space.php?do=share"><span class="icon i-app24 i-app24-share"></span>分享</a></li>
<li><a href="space.php?do=topic"><span class="icon i-app24 i-app24-hot"></span>专题</a></li>
</ul>

           

<div id="appbarActions">
<?php if($_SCONFIG['my_status']) { ?><a class="act a-manage" href="cp.php?ac=userapp&op=menu" >设置</a>&nbsp;<?php } ?><?php if($_SGLOBAL['my_menu_more']) { ?><a href="javascript:;" id="a_app_more" onclick="userapp_open();" class="off">展开</a><?php } ?>
            </div>

<?php } else { ?>
<div class="bar_text">
<form id="loginform" name="loginform" action="do.php?ac=<?=$_SCONFIG['login_action']?>&ref" method="post">
<input type="hidden" name="formhash" value="<?php echo formhash(); ?>" />
<p><h2>登陆更精彩...</h2></p>
<p>账号:</p>
<p><input type="text" name="username" id="username" class="t_input" size="15" value="" /></p>
<p>密码:</p>
<p><input type="password" name="password" id="password" class="t_input" size="15" value="" /></p>
<p ><input type="checkbox" id="cookietime" name="cookietime" value="315360000" checked /><label for="cookietime">记住我</label></p>
<p>
<input type="submit" id="loginsubmit" name="loginsubmit" value="登录" class="submit" />
<input type="button" name="regbutton" value="注册" class="button" onclick="urlto('do.php?ac=<?=$_SCONFIG['register_action']?>');">
</p>
</form>

</div>
<?php } ?>
</div>

<div id="mainarea">

<?php if($_SGLOBAL['ad']['contenttop']) { ?><div id="ad_contenttop"><?php adshow('contenttop'); ?></div><?php } ?>
<?php } ?>

<?php } ?>


<div class="appHead">
<?php if($space['self']) { ?>
<h2><span title="日志" class="icon i-app24 i-app24-blog"></span>日志</h2>
<?php } else { ?>
<?php $_TPL['spacetitle'] = "日志";
	$_TPL['spacemenus'][] = "<a href=\"space.php?uid=$space[uid]&do=$do&view=me\">TA的所有日志</a>";
	$_TPL['spacemenus'][] = "<a href=\"space.php?uid=$space[uid]&do=blog&id=$blog[blogid]\">查看日志</a>"; ?>
﻿<div class="c_header a_header">
<div class="avatar-48"><a href="space.php?uid=<?=$space['uid']?>"><?php echo avatar($space[uid],small); ?></a></div>
<?php if($_SGLOBAL['refer']) { ?>
<a class="r_option" href="<?=$_SGLOBAL['refer']?>">&laquo; 返回上一页</a>
<?php } ?>
<p style="font-size:14px"><?=$_SN[$space['uid']]?>的<?=$_TPL['spacetitle']?></p>
<a href="space.php?uid=<?=$space['uid']?>" class="spacelink"><?=$_SN[$space['uid']]?>的主页</a>
<?php if($_TPL['spacemenus']) { ?>
<?php if(is_array($_TPL['spacemenus'])) { foreach($_TPL['spacemenus'] as $value) { ?> <span class="pipe">&raquo;</span> <?=$value?><?php } } ?>
<?php } ?>
</div>

<?php } ?>
</div>

<div class="appBody">
<?php if($space['self']) { ?>
<div class="tabs">
<ul>
<?php if($space['friendnum']) { ?><li<?=$actives['we']?>><a href="space.php?uid=<?=$space['uid']?>&do=<?=$do?>&view=we"><span>好友最新日志</span></a></li><?php } ?>
<li class="active"><a href="space.php?uid=<?=$space['uid']?>&do=<?=$do?>&view=me"><span>我的日志</span></a></li>
<li><a href="space.php?uid=<?=$space['uid']?>&do=<?=$do?>&view=click"><span>我踩过的日志</span></a></li>
<li><a href="space.php?uid=<?=$space['uid']?>&do=<?=$do?>&view=all"><span>大家的日志</span></a></li>
<li class="orphan"><a href="cp.php?ac=blog"><span><font class="act a-add">发表新日志</font></span></a></li>

</ul>
<?php if($_SGLOBAL['refer']) { ?>

<div style="padding-left: 8px;" class="option shareOption"><a  href="<?=$_SGLOBAL['refer']?>">&laquo; 返回上一页</a></div>

<?php } ?>
</div>
<?php } ?>

<script type="text/javascript" charset="<?=$_SC['charset']?>" src="source/script_calendar.js"></script>

 <div class="appContent entry" style="margin:0">
<!--列表 begin-->
<div class="diaryView">
<div class="diaryTitle fix">
 <h3 style="width: 75%;" <?php if($blog['magiccolor']) { ?> class="magiccolor<?=$blog['magiccolor']?>"<?php } ?>><?=$blog['subject']?><span class="meta"><?php echo sgmdate('Y-m-d H:i',$blog[dateline],1); ?></span><?php if($blog['friend']) { ?><span class="meta"><a href="space.php?uid=<?=$space['uid']?>&do=<?=$do?>&view=me&friend=<?=$blog['friend']?>" class="gray"><?=$friendsname[$value['friend']]?></a></span><?php } ?><?php if($blog['viewnum']) { ?><span class="meta">阅读(<?=$blog['viewnum']?>)</span><?php } ?></h3>
 <div class="shareBox"><a href="cp.php?ac=share&type=blog&id=<?=$blog['blogid']?>" id="a_share" onclick="ajaxmenu(event, this.id, 1)" class="a_share">分享</a></div>

 <div class="tool"><?php if($_SGLOBAL['supe_uid'] == $blog['uid'] || checkperm('manageblog')) { ?><a href="cp.php?ac=blog&blogid=<?=$blog['blogid']?>&op=edit" title="编辑" class="act a-edit">编辑</a><a href="cp.php?ac=blog&blogid=<?=$blog['blogid']?>&op=delete" id="blog_delete_<?=$blog['blogid']?>" onclick="ajaxmenu(event, this.id)" title="删除" class="act a-del">删除</a><?php } ?></div>
 <div class="date"/>
 </div>
</div>
<div id="blog_article" class="diaryViewC <?php if($blog['magicpaper']) { ?> magicpaper<?=$blog['magicpaper']?><?php } ?>">
<div class="resizeimg">
<div class="resizeimg2">
<div class="resizeimg3">
<div class="resizeimg4">
<?php if($_SGLOBAL['ad']['rightside']) { ?>
<div style="float: right; padding:5px;"><?php adshow('rightside'); ?></div>
<?php } ?>
<?=$blog['message']?>
</div>
</div>
</div>
    </div>
</div>

<div class="aboutFriend"><?php if($blog['friend']) { ?><span class="gray">(本文<?=$friendsname[$blog['friend']]?>)</span><?php } ?>&nbsp;<span class="gray"><?php if($blog['tag']) { ?><a href="space.php?uid=<?=$blog['uid']?>&do=tag">标签</a>:&nbsp;<?php if(is_array($blog['tag'])) { foreach($blog['tag'] as $tagid => $tagname) { ?><a href="space.php?uid=<?=$blog['uid']?>&do=tag&id=<?=$tagid?>"><?=$tagname?></a>&nbsp;<?php } } ?><?php } ?></span>
                                     <?php if($_SGLOBAL['supe_uid'] == $blog['uid']) { ?>
<?php if($_SGLOBAL['magic']['bgimage']) { ?>
<a class="icon i-bgimage"></a>
<?php if($blog['magicpaper']) { ?>
<a href="cp.php?ac=magic&op=cancelbgimage&idtype=blogid&id=<?=$blog['blogid']?>" id="a_magic_bgimage" onclick="ajaxmenu(event,this.id, 1)">取消<?=$_SGLOBAL['magic']['bgimage']?></a>
<?php } else { ?>
<a href="magic.php?mid=bgimage&idtype=blogid&id=<?=$blog['blogid']?>" id="a_magic_bgimage" onclick="ajaxmenu(event,this.id, 1)"><?=$_SGLOBAL['magic']['bgimage']?></a>	
<?php } ?>
<?php } ?>
<?php if($_SGLOBAL['magic']['call']) { ?>
<a class="icon i-call"></a>
<a href="magic.php?mid=call&idtype=blogid&id=<?=$blog['blogid']?>" id="a_magic_call" onclick="ajaxmenu(event,this.id, 1)"><?=$_SGLOBAL['magic']['call']?></a>
<?php } ?>
<?php if($_SGLOBAL['magic']['updateline']) { ?>
<a class="icon i-updateline"></a>
<a href="magic.php?mid=updateline&idtype=blogid&id=<?=$blog['blogid']?>" id="a_magic_updateline" onclick="ajaxmenu(event,this.id, 1)"><?=$_SGLOBAL['magic']['updateline']?></a>
<?php } ?>
<?php if($_SGLOBAL['magic']['downdateline']) { ?>
<a class="icon i-downdateline"></a>
<a href="magic.php?mid=downdateline&idtype=blogid&id=<?=$blog['blogid']?>" id="a_magic_downdateline" onclick="ajaxmenu(event,this.id, 1)"><?=$_SGLOBAL['magic']['downdateline']?></a>
<?php } ?>
<?php if($_SGLOBAL['magic']['color']) { ?>
<a class="icon i-color"></a>
<?php if($blog['magiccolor']) { ?>
<a href="cp.php?ac=magic&op=cancelcolor&idtype=blogid&id=<?=$blog['blogid']?>" id="a_magic_color" onclick="ajaxmenu(event,this.id)">取消<?=$_SGLOBAL['magic']['color']?></a>
<?php } else { ?>
<a href="magic.php?mid=color&idtype=blogid&id=<?=$blog['blogid']?>" id="a_magic_color" onclick="ajaxmenu(event,this.id, 1)"><?=$_SGLOBAL['magic']['color']?></a>
<?php } ?>
<?php } ?>
<?php if($_SGLOBAL['magic']['hot']) { ?>
<a class="icon i-hot"></a>
<a href="magic.php?mid=hot&idtype=blogid&id=<?=$blog['blogid']?>" id="a_magic_hot" onclick="ajaxmenu(event,this.id, 1)"><?=$_SGLOBAL['magic']['hot']?></a>
<?php } ?>
<span class="pipe">|</span>
<?php } ?>

<?php if($_SGLOBAL['supe_uid'] == $blog['uid'] || checkperm('manageblog')) { ?>
<a href="cp.php?ac=topic&op=join&id=<?=$blog['blogid']?>&idtype=blogid" id="a_topicjoin_<?=$blog['blogid']?>" onclick="ajaxmenu(event, this.id)">凑热闹</a><span class="pipe">|</span>
<?php } ?>
<?php if(checkperm('manageblog')) { ?>
<a href="cp.php?ac=blog&blogid=<?=$blog['blogid']?>&op=edithot" id="blog_hot_<?=$blog['blogid']?>" onclick="ajaxmenu(event, this.id)">热度</a><span class="pipe">|</span>
<?php } ?>
<a href="cp.php?ac=common&op=report&idtype=blogid&id=<?=$blog['blogid']?>" id="a_report" onclick="ajaxmenu(event, this.id, 1)">举报</a>
</div>

<div class="blogComment" id="div_main_content">
<div id="content" style="width:510px">
 <div class="click_div" id="click_div">
﻿
<div class="digc">
<table>
<tr>
<?php $clicknum = 0; ?>
<?php if(is_array($clicks)) { foreach($clicks as $value) { ?>
<?php $clicknum = $clicknum + $value['clicknum']; ?>

<td valign="bottom"><div class="digface"><a class="click_pic" href="cp.php?ac=click&op=add&clickid=<?=$value['clickid']?>&idtype=<?=$idtype?>&id=<?=$id?>&hash=<?=$hash?>" id="click_<?=$idtype?>_<?=$id?>_<?=$value['clickid']?>" onclick="ajaxmenu(event, this.id, 0, 2000, 'show_click')"><img src="image/click/<?=$value['icon']?>" <?php if($value['clicknum']) { ?>alt="<?=$value['clicknum']?>次" title="<?=$value['clicknum']?>次"<?php } ?> /><sup class="click_ok" id="click_<?=$value['clickid']?>">OK</sup></a><p><?=$value['name']?></p></div></td>
<?php } } ?>
</tr>
</table>
</div>

<?php if($clickuserlist) { ?>
<div class="trace" style="padding-bottom: 10px;">

<div>
<h2>
共有 <a href="javascript:;" onclick="show_click('click_<?=$idtype?>_<?=$id?>_<?=$value['clickid']?>')"><?=$clicknum?> 人</a>  参与表态
<?php if($_SGLOBAL['magic']['anonymous']) { ?>
<a id="a_magic_anonymous" href="magic.php?mid=anonymous&idtype=<?=$idtype?>&id=<?=$id?>" onclick="ajaxmenu(event,this.id, 1)" class="gray"><?=$_SGLOBAL['magic']['anonymous']?></a>
<?php } ?>					
</h2>
</div>
<div id="trace_div">
<ul class="avatar_list" id="trace_ul">
<?php if(is_array($clickuserlist)) { foreach($clickuserlist as $value) { ?>
<li>
<?php if($value['username']) { ?>
<a class="user_img_4" href="space.php?uid=<?=$value['uid']?>" target="_blank" title="<?=$value['clickname']?>"><?php echo avatar($value[uid], 'small'); ?></a>
<p><a class="c_1" href="space.php?uid=<?=$value['uid']?>"  title="<?=$_SN[$value['uid']]?>" target="_blank"><?=$_SN[$value['uid']]?></a></p>
<?php } else { ?>
<span class="user_img_4"><img src="image/magic/hidden.gif" alt="<?=$value['clickname']?>" /></span>
<p class="c_1">匿名</p>
<?php } ?>
</li>
<?php } } ?>
</ul>
</div>
</div>
<?php } ?>

<?php if($click_multi) { ?><div class="page"><?=$click_multi?></div><?php } ?>

 </div>
                                     <div class="comment_div">
 <div><a href="javascript:void(0)">评论 (<span id="comment_replynum"><?=$blog['replynum']?></span>)</a></div>
 <!--评论开始-->
 <div class="commentBox commentBox-large" id="comment">
    <?php if($cid) { ?>
<div class="notice">
当前只显示与你操作相关的单个评论，<a href="space.php?uid=<?=$blog['uid']?>&do=blog&id=<?=$blog['blogid']?>">点击此处查看全部评论</a>
</div>
<?php } ?>
<ul id="comment_ul">
<?php if(is_array($list)) { foreach($list as $value) { ?>
﻿
<?php if(empty($ajax_edit)) { ?><li class="commentC" id="comment_<?=$value['cid']?>_li"><?php } ?>		
<div class="commentAvatar">
<?php if($value['author']) { ?>
<a href="space.php?uid=<?=$value['authorid']?>" title="<?=$_SN[$value['authorid']]?>"><span class="avatar-32"><?php echo avatar($value[authorid],small); ?></span></a>		
            <?php } else { ?>
    <a href="javascript:void(0);" title="匿名用户"><span class="avatar-32"><img src="image/magic/hidden.gif"/></span></a>
<?php } ?>
</div>

<div class="commentOption">
    <?php if($value['authorid']==$_SGLOBAL['supe_uid'] || $value['uid']==$_SGLOBAL['supe_uid'] || checkperm('managecomment')) { ?>
<a href="cp.php?ac=comment&op=delete&cid=<?=$value['cid']?>" id="c_<?=$value['cid']?>_delete" onclick="ajaxmenu(event, this.id)" class="icon i-del" title="删除">删除</a>
    <?php } ?>
</div>
<div class="commentInfo">
<h4>
                    <?php if($value['author']) { ?>
<a href="space.php?uid=<?=$value['authorid']?>" id="author_<?=$value['cid']?>"><?=$_SN[$value['authorid']]?></a><?php } else { ?>匿名<?php } ?> <span class="meta"><?php echo sgmdate('Y-m-d H:i',$value[dateline],1); ?></span>

<?php if($value['authorid']==$_SGLOBAL['supe_uid']) { ?>
<?php if($_SGLOBAL['magic']['anonymous']) { ?>
<a class="icon i-anonymous"></a><a id="a_magic_anonymous_<?=$value['cid']?>" href="magic.php?mid=anonymous&idtype=cid&id=<?=$value['cid']?>" onclick="ajaxmenu(event,this.id, 1)"><?=$_SGLOBAL['magic']['anonymous']?></a>
<span class="meta">-</span>
<?php } ?>
<a href="cp.php?ac=comment&op=edit&cid=<?=$value['cid']?>" id="c_<?=$value['cid']?>_edit" onclick="ajaxmenu(event, this.id, 1)">编辑</a>
    <?php } ?>

<?php if($value['authorid']!=$_SGLOBAL['supe_uid'] && ($value['idtype'] != 'uid' || $space['self'])) { ?><span class="meta">-</span> <a href="cp.php?ac=comment&op=reply&cid=<?=$value['cid']?>&feedid=<?=$feedid?>" id="c_<?=$value['cid']?>_reply" onclick="ajaxmenu(event, this.id, 1)">回复</a><?php } ?><span class="meta">-</span> <a href="cp.php?ac=common&op=report&idtype=comment&id=<?=$value['cid']?>" id="a_report_<?=$value['cid']?>" onclick="ajaxmenu(event, this.id, 1)">举报</a>
</h4>
<div class="detail<?php if($value['magicflicker']) { ?> magicflicker<?php } ?>" id="comment_<?=$value['cid']?>"><?=$value['message']?></div>
</div>
<?php if(empty($ajax_edit)) { ?></li><?php } ?>

<?php } } ?>
<?php if($multi) { ?><li class="commentMore"><p class="pager-simple"><?=$multi?></p></li><?php } ?>
</ul>
<?php if(!$blog['noreply']) { ?>
                                    <form id="quickcommentform_<?=$id?>" name="quickcommentform_<?=$id?>" action="cp.php?ac=comment" method="post" class="quickpost">
<div class="clickComment">

<div class="addComBox" >
<div class="commentAvatar">
<a href="space.php?uid=<?=$_SGLOBAL['supe_uid']?>" title="<?=$_SGLOBAL['supe_uid']?>"><span class="avatar-32"><?php echo avatar($_SGLOBAL[supe_uid],middle); ?></span></a>
</div>
<div class="commentRight">
<textarea class="addComment text" id="comment_message" onkeydown="ctrlEnter(event, 'commentsubmit_btn');" name="message"></textarea>
<div class="commentEmot"><span class="emot e-base-1"><a href="###" id="comment_face" title="插入表情" onclick="showFace(this.id, 'comment_message');return false;"><img src="image/facelist.gif" align="absmiddle" /></a></span>
<?php if($_SGLOBAL['magic']['doodle']) { ?>
                                <a class="icon i-doodle"></a><a id="a_magic_doodle" href="magic.php?mid=doodle&showid=comment_doodle&target=comment_message" onclick="ajaxmenu(event, this.id, 1)">涂鸦板</a>
                                <?php } ?>
</div>
<div class="commentBtn"><input type="hidden" name="refer" value="space.php?uid=<?=$blog['uid']?>&do=<?=$do?>&id=<?=$id?>" />
<input type="hidden" name="id" value="<?=$id?>">
<input type="hidden" name="idtype" value="blogid">
<input type="hidden" name="commentsubmit" value="true" />
<span class="button button-main"><span>
<button class="button" type="button" id="commentsubmit_btn" name="commentsubmit_btn" onclick="ajaxpost('quickcommentform_<?=$id?>', 'comment_add')">评论</button></span></span><div id="__quickcommentform_<?=$id?>"></div>
</div>
</div>
</div>
</div>
<input type="hidden" name="formhash" value="<?php echo formhash(); ?>" /></form><?php } ?>
<span class="corner"></span>
</div>
 <!--评论结束-->
</div></div>
<?php if($otherlist) { ?>
<div class="blogRecommend">
 <h3>作者其他日志</h3>
 <ul> 
<?php if(is_array($otherlist)) { foreach($otherlist as $value) { ?>
<li><a href="space.php?uid=<?=$value['uid']?>&do=blog&id=<?=$value['blogid']?>"><?=$value['subject']?></a></li>
<?php } } ?>
 </ul>
</div>
<?php } ?>

<?php if($newlist) { ?>
<div class="blogRecommend">
 <h3>热门日志导读</h3>
 <ul> 
<?php if(is_array($newlist)) { foreach($newlist as $value) { ?>
<li><a href="space.php?uid=<?=$value['uid']?>&do=blog&id=<?=$value['blogid']?>"><?=$value['subject']?></a></li>
<?php } } ?>
 </ul>
</div>
<?php } ?>

<?php if($blog['related']) { ?>
                                <?php if(is_array($blog['related'])) { foreach($blog['related'] as $appid => $values) { ?>
<div class="blogRecommend">
 <h3>您可能感兴趣的<?php if($_SGLOBAL['app'][$appid]['name']) { ?>(<?=$_SGLOBAL['app'][$appid]['name']?>)<?php } ?></h3>
 <ul> 
<?php if(is_array($values['data'])) { foreach($values['data'] as $value) { ?>
<li><?=$value['html']?></li>
<?php } } ?>
 </ul>
</div>
<?php } } ?>
<?php } ?>
<!--结束-->
</div>

<!--列表 end-->
 </div>
 </div>
<script type="text/javascript">
<!--
function closeSide2(oo) {
if($('sidebar').style.display == 'none'){
$('content').style.cssText = '';
$('sidebar').style.display = 'block';
oo.innerHTML = '&raquo; 关闭侧边栏';
}
else{
$('content').style.cssText = 'margin: 0pt; width: 810px;';
$('sidebar').style.display = 'none';
oo.innerHTML = '&laquo; 打开侧边栏';
}
}
function addFriendCall(){
var el = $('friendinput');
if(!el || el.value == "")	return;
var s = '<input type="checkbox" name="fusername[]" value="'+el.value+'" id="'+el.value+'" checked>';
s += '<label for="'+el.value+'">'+el.value+'</label>';
s += '<br />';
$('friends').innerHTML += s;
el.value = '';
}
resizeImg('blog_article','700');
resizeImg('div_main_content','450');

//彩虹炫
var elems = selector('div[class~=magicflicker]'); 
for(var i=0; i<elems.length; i++){
magicColor(elems[i]);
}

-->
</script>
</div>
﻿<?php if(empty($_SGLOBAL['inajax'])) { ?>
<?php if(empty($_TPL['nosidebar'])) { ?>
<?php if($_SGLOBAL['ad']['contentbottom']) { ?><br style="line-height:0;clear:both;"/><div id="ad_contentbottom"><?php adshow('contentbottom'); ?></div><?php } ?>
</div>

<!--/mainarea-->
<div id="bottom"></div>
</div>
<!--/main-->
<?php } ?>

<div id="footer">

<p class="r_option">
<a href="javascript:;" onclick="window.scrollTo(0,0);" id="a_top" title="TOP"><img src="image/top.gif" alt="" style="padding: 5px 6px 6px;" /></a>
</p>

<?php if($_SGLOBAL['ad']['footer']) { ?>
<p style="padding:5px 0 10px 0;"><?php adshow('footer'); ?></p>
<?php } ?>

<?php if($_SCONFIG['close']) { ?>
<p style="color:blue;font-weight:bold;">
提醒：当前站点处于关闭状态
</p>
<?php } ?>
<p>
<?=$_SCONFIG['sitename']?> - 
<a href="mailto:<?=$_SCONFIG['adminemail']?>">联系我们</a>
<?php if($_SCONFIG['miibeian']) { ?> - <a  href="http://www.miibeian.gov.cn" target="_blank"><?=$_SCONFIG['miibeian']?></a><?php } ?>
</p>
<p>
Powered by <a  href="http://u.discuz.net" target="_blank"><strong>UCenter Home</strong></a> <span title="<?php echo X_RELEASE; ?>"><?php echo X_VER; ?></span>
<?php if(!empty($_SCONFIG['licensed'])) { ?><a  href="http://license.comsenz.com/?pid=7&host=<?=$_SERVER['HTTP_HOST']?>" target="_blank">Licensed</a><?php } ?>
&copy; 2001-2011 <a  href="http://www.comsenz.com" target="_blank">Comsenz Inc.</a>
</p>
<?php if($_SCONFIG['debuginfo']) { ?>
<p><?php echo debuginfo(); ?></p>
<?php } ?>
</div>
</div>
<!--/wrap-->

<?php if($_SGLOBAL['appmenu']) { ?>
<ul id="ucappmenu_menu" class="dropmenu_drop" style="display:none;">
<li><a href="<?=$_SGLOBAL['appmenu']['url']?>" title="<?=$_SGLOBAL['appmenu']['name']?>" target="_blank"><?=$_SGLOBAL['appmenu']['name']?></a></li>
<?php if(is_array($_SGLOBAL['appmenus'])) { foreach($_SGLOBAL['appmenus'] as $value) { ?>
<li><a href="<?=$value['url']?>" title="<?=$value['name']?>" target="_blank"><?=$value['name']?></a></li>
<?php } } ?>
</ul>
<?php } ?>


<?php if($_SGLOBAL['supe_uid']) { ?>
<?php if(!isset($_SCOOKIE['checkpm'])) { ?>
<script language="javascript"  type="text/javascript" src="cp.php?ac=pm&op=checknewpm&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>
<?php if(!isset($_SCOOKIE['synfriend'])) { ?>
<script language="javascript"  type="text/javascript" src="cp.php?ac=friend&op=syn&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>
<?php } ?>
<?php if(!isset($_SCOOKIE['sendmail'])) { ?>
<script language="javascript"  type="text/javascript" src="do.php?ac=sendmail&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>

<?php if($_SGLOBAL['ad']['couplet']) { ?>
<script language="javascript" type="text/javascript" src="source/script_couplet.js"></script>
<div id="uch_couplet" style="z-index: 10; position: absolute; display:none">
<div id="couplet_left" style="position: absolute; left: 2px; top: 60px; overflow: hidden;">
<div style="position: relative; top: 25px; margin:0.5em;" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('uch_couplet');"><img src="image/advclose.gif"></div>
<?php adshow('couplet'); ?>
</div>
<div id="couplet_rigth" style="position: absolute; right: 2px; top: 60px; overflow: hidden;">
<div style="position: relative; top: 25px; margin:0.5em;" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('uch_couplet');"><img src="image/advclose.gif"></div>
<?php adshow('couplet'); ?>
</div>
<script type="text/javascript">
lsfloatdiv('uch_couplet', 0, 0, '', 0).floatIt();
</script>
</div>
<?php } ?>
<?php if($_SCOOKIE['reward_log']) { ?>
<script type="text/javascript">
showreward();
</script>
<?php } ?>
</body>
</html>
<?php } ?>
<?php ob_out();?>