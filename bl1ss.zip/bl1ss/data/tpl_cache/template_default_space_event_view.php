<?php if(!defined('IN_UCHOME')) exit('Access Denied');?><?php subtplcheck('template/default/space_event_view|template/default/header|template/default/space_pic|template/default/space_comment_li|template/default/space_comment_li|template/default/footer|template/default/space_click|template/default/space_comment_li', '1303345400', 'template/default/space_event_view');?>﻿<?php $_TPL['titles'] = array($event['title'], '活动'); ?>
﻿<?php if(empty($_SGLOBAL['inajax'])) { ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=<?=$_SC['charset']?>" />
<meta http-equiv="x-ua-compatible" content="ie=7" />
<title><?php if($_TPL['titles']) { ?><?php if(is_array($_TPL['titles'])) { foreach($_TPL['titles'] as $value) { ?><?php if($value) { ?><?=$value?> - <?php } ?><?php } } ?><?php } ?><?php if($_SN[$space['uid']]) { ?><?=$_SN[$space['uid']]?> - <?php } ?><?=$_SCONFIG['sitename']?></title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<script language="javascript" type="text/javascript" src="source/script_jquery.js"></script>
<script language="javascript" type="text/javascript" src="source/script_cookie.js"></script>
<script language="javascript" type="text/javascript" src="source/script_common.js"></script>
<script language="javascript" type="text/javascript" src="source/script_menu.js"></script>
<script language="javascript" type="text/javascript" src="source/script_ajax.js"></script>
<script language="javascript" type="text/javascript" src="source/script_face.js"></script>
<script language="javascript" type="text/javascript" src="source/script_manage.js"></script>
<link id="skinc" href="/template/default/style.css" rel="stylesheet" type="text/css" />
<?php if($_TPL['css']) { ?>
<link id="skinc" href="/template/default/<?=$_TPL['css']?>.css" rel="stylesheet" type="text/css" />
<?php } ?>
<?php if(!empty($_SGLOBAL['space_theme'])) { ?>
<link id="skinc" href="/theme/<?=$_SGLOBAL['space_theme']?>/style.css" rel="stylesheet" type="text/css" />
<?php } elseif($_SCONFIG['template'] != 'default') { ?>
<link id="skinc" href="/template/<?=$_SCONFIG['template']?>/style.css" rel="stylesheet" type="text/css" />
<?php } ?>

<style type="text/css">
<?php if(!empty($_SGLOBAL['space_css'])) { ?>
<?=$_SGLOBAL['space_css']?> 
<?php } ?>
</style>
<link rel="shortcut icon" href="image/favicon.ico" />
<link rel="edituri" type="application/rsd+xml" title="rsd" href="xmlrpc.php?rsd=<?=$space['uid']?>" />

</head>
<body>
<div id="append_parent"></div>
<div id="ajaxwaitid"></div>
<div id="header">
<div class="wp">
<div id="logo"></div>

<div id="nav">
<div>
<?php if($_SGLOBAL['supe_uid']) { ?>
<a href="space.php">myspace</a>
<a href="cp.php?ac=common&op=logout&uhash=<?=$_SGLOBAL['uhash']?>">logout</a>
<?php } else { ?>
<a href="do.php?ac=<?=$_SCONFIG['login_action']?>">Share</a> | 
<a href="do.php?ac=<?=$_SCONFIG['login_action']?>">Login</a> | 
<a href="do.php?ac=<?=$_SCONFIG['register_action']?>">Register</a>
<?php } ?>
</div>
<div id="navitem">
<a href="network.php"><img src="/template/default/i/nav_home.jpg" /></a>
<a href="space.php?act=home&view=all"><img src="/template/default/i/nav_comm.jpg" /></a>
<a href="books.php"><img src="/template/default/i/nav_books.jpg" /></a>
<a href="movies.php"><img src="/template/default/i/nav_mov.jpg" /></a>
<a href="music.php"><img src="/template/default/i/nav_mus.jpg" /></a>
<a href="arts.php"><img src="/template/default/i/nav_art.jpg" /></a>
</div>
</div>
<div class="cl"></div>
</div>
</div>

<div id="wrap">

<?php if(empty($_TPL['nosidebar'])) { ?>
<div id="main">
<div id="app_sidebar">
<?php if($_SGLOBAL['supe_uid']) { ?>
    <h2>Personal Center</h2>
<ul class="app_list" id="default_userapp">
<li><a href="space.php?do=doing"><span class="icon i-app24 i-app24-status"></span>Fresh things</a></li>
<li><a href="space.php?do=album"><span class="icon i-app24 i-app24-album"></span>Albums</a><em><a href="cp.php?ac=upload" class="gray">upload</a></em></li>
<li><a href="space.php?do=blog"><span class="icon i-app24 i-app24-blog"></span>WebLog</a><em><a href="cp.php?ac=blog" class="gray">issue</a></em></li>
</ul>

            <h2>互动中心</h2>
<ul class="app_list" id="default_userapp">
<li><a href="space.php?do=poll"><span class="icon i-app24 i-app24-vote"></span>投票</a><em><a href="cp.php?ac=poll" class="gray">发起</a></em></li>
<li><a href="space.php?do=mtag"><span class="icon i-app24 i-app24-thread"></span>群组</a><em><a href="cp.php?ac=thread" class="gray">话题</a></em></li>
<li><a href="space.php?do=event"><span class="icon i-app24 i-app24-event"></span>活动</a><em><a href="cp.php?ac=event" class="gray">发起</a></em></li>
<li><a href="space.php?do=share"><span class="icon i-app24 i-app24-share"></span>分享</a></li>
<li><a href="space.php?do=topic"><span class="icon i-app24 i-app24-hot"></span>专题</a></li>
</ul>

           

<div id="appbarActions">
<?php if($_SCONFIG['my_status']) { ?><a class="act a-manage" href="cp.php?ac=userapp&op=menu" >设置</a>&nbsp;<?php } ?><?php if($_SGLOBAL['my_menu_more']) { ?><a href="javascript:;" id="a_app_more" onclick="userapp_open();" class="off">展开</a><?php } ?>
            </div>

<?php } else { ?>
<div class="bar_text">
<form id="loginform" name="loginform" action="do.php?ac=<?=$_SCONFIG['login_action']?>&ref" method="post">
<input type="hidden" name="formhash" value="<?php echo formhash(); ?>" />
<p><h2>登陆更精彩...</h2></p>
<p>账号:</p>
<p><input type="text" name="username" id="username" class="t_input" size="15" value="" /></p>
<p>密码:</p>
<p><input type="password" name="password" id="password" class="t_input" size="15" value="" /></p>
<p ><input type="checkbox" id="cookietime" name="cookietime" value="315360000" checked /><label for="cookietime">记住我</label></p>
<p>
<input type="submit" id="loginsubmit" name="loginsubmit" value="登录" class="submit" />
<input type="button" name="regbutton" value="注册" class="button" onclick="urlto('do.php?ac=<?=$_SCONFIG['register_action']?>');">
</p>
</form>

</div>
<?php } ?>
</div>

<div id="mainarea">

<?php if($_SGLOBAL['ad']['contenttop']) { ?><div id="ad_contenttop"><?php adshow('contenttop'); ?></div><?php } ?>
<?php } ?>

<?php } ?>


<div class="appHead">							
 <h2><span title="活动" class="icon i-app24 i-app24-impression"></span><a href="space.php?do=event">活动</a> - <a href="space.php?do=event&id=<?=$event['eventid']?>"><?=$event['title']?></a><?php if($event['grade']==-2) { ?><span style="color:#f00"> 已关闭</span><?php } elseif($event['grade']<=0) { ?><span style="color:#f00"> 待审核</span><?php } ?></h2>
</div>
<div class="appBody">
<div class="tabs">
<div style="padding-left: 8px;" class="option shareOption">  
<?php if($_SGLOBAL['supe_uid'] == $event['uid'] || checkperm('manageevent')) { ?>
<a href="cp.php?ac=topic&op=join&id=<?=$event['eventid']?>&idtype=eventid" id="a_topicjoin_<?=$event['eventid']?>" onclick="ajaxmenu(event, this.id)">凑热闹</a><span class="pipe">|</span>
<?php } ?>
<?php if(checkperm('manageevent')) { ?>
<a href="admincp.php?ac=event&eventid=<?=$event['eventid']?>" target="_blank">审核管理</a><span class="pipe">|</span>
<a href="cp.php?ac=event&id=<?=$event['eventid']?>&op=edithot" id="a_hot_<?=$event['eventid']?>" onclick="ajaxmenu(event, this.id)">热度</a><span class="pipe">|</span>
<?php } ?>
<a href="cp.php?ac=common&op=report&idtype=eventid&id=<?=$event['eventid']?>" id="a_report" onclick="ajaxmenu(event, this.id, 1)">举报</a><span class="pipe">|</span>
<a href="cp.php?ac=share&type=event&id=<?=$eventid?>" id="a_share" onclick="ajaxmenu(event, this.id, 1)" class="tab_share">分享</a>
</div>

<ul>
<li <?=$menu['all']?>><a href="space.php?do=event&id=<?=$event['eventid']?>"><span>活动</span></a></li>
            <li <?=$menu['member']?>><a href="space.php?do=event&id=<?=$event['eventid']?>&view=member&status=2"><span>成员</span></a></li>
<li <?=$menu['pic']?>><a href="space.php?do=event&id=<?=$event['eventid']?>&view=pic"><span>照片</span></a></li>
<?php if($event['tagid']) { ?>
<li <?=$menu['thread']?>><a href="space.php?do=event&id=<?=$event['eventid']?>&view=thread"><span>话题</span></a></li>
<?php } ?>
<li <?=$menu['comment']?>><a href="space.php?do=event&id=<?=$event['eventid']?>&view=comment"><span>留言</span></a></li>
</ul>
</div>
<div class="disContent">
<?php if($view=="member") { ?>

<div class="sub_menu">
<div style="width:790px;">
<form name="searchform" id="searchform" method="get" action="space.php" style=" float: right;">
<table cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td style="padding: 4px 0 0 0;"><input type="text" style="border-right: medium none; width: 160px;" tabindex="1" class="t_input" onfocus="if(this.value=='搜索成员')this.value='';" value="搜索成员" name="key" id="key"/></td>
<td style="padding: 4px 0 0 0;"><a href="javascript:$('searchform').submit();" style="padding:0; margin:0;"><img alt="搜索" src="image/search_btn.gif"/></a></td>
</tr>
</tbody>
</table>
<input type="hidden" name="do" value="event">
<input type="hidden" name="id" value="<?=$eventid?>">
<input type="hidden" name="view" value="member">
<input type="hidden" name="status" value="<?=$status?>">
<input type="hidden" name="formhash" value="<?php echo formhash(); ?>" />
</form>
<a <?=$submenus['member']?> href="space.php?do=event&id=<?=$event['eventid']?>&view=member&status=2"><?=$event['membernum']?> 人参加</a>
<a <?=$submenus['follow']?> href="space.php?do=event&id=<?=$event['eventid']?>&view=member&status=1"><?=$event['follownum']?> 人关注</a><?php if($_SGLOBAL['supe_userevent']['status'] >= 3) { ?>
<a <?=$submenus['verify']?> href="space.php?do=event&id=<?=$event['eventid']?>&view=member&status=0"><?=$verifynum?> 人待审核</a><?php } ?>
</div>
</div>

<div class="thumb_list">
<?php if($members) { ?>
<table cellspacing="6" cellpadding="0">
<?php if(is_array($members)) { foreach($members as $key => $value) { ?>
<tr>
<td class="thumb <?php if($ols[$value['uid']]) { ?>online<?php } ?>">
<table cellpadding="4" cellspacing="4">
<tr>
<td width=60>
<div class="avatar-48">
<a href="space.php?uid=<?=$value['uid']?>"><?php echo avatar($value[uid],'small'); ?></a>
</div>
</td>
<td>
<h6>
<a href="space.php?uid=<?=$value['uid']?>"><?=$_SN[$value['uid']]?></a>
<?php if($ols[$value['uid']]) { ?>
<span class="gray online_icon_p" title="当前在线" style="font-size:12px; font-weight:normal;">(<?php echo sgmdate('H:i',$ols[$value[uid]],1); ?>)</span>
<?php } ?>
<span class="gray" style="font-size:12px; font-weight:normal;">&nbsp;&nbsp;
<a href="cp.php?ac=friend&op=add&uid=<?=$value['uid']?>" id="a_friend_<?=$key?>" onclick="ajaxmenu(event, this.id, 1)">加为好友</a>
<span class="pipe">|</span><a href="cp.php?ac=pm&uid=<?=$value['uid']?>" id="a_pm_<?=$key?>" onclick="ajaxmenu(event, this.id, 1)">发短消息</a>
<span class="pipe">|</span><a href="cp.php?ac=poke&op=send&uid=<?=$value['uid']?>" id="a_poke_<?=$key?>" onclick="ajaxmenu(event, this.id, 1)">打招呼</a>
</span>
</h6>

<p class="l_status">
<?php if($value['status'] != 1 && $_SGLOBAL['supe_userevent']['status']>=3 && $event['uid'] != $value['uid']) { ?>
<a href="cp.php?ac=event&id=<?=$eventid?>&op=member&uid=<?=$value['uid']?>" id="a_mod_<?=$key?>" onclick="ajaxmenu(event, this.id)" class="r_option" style="padding-left:0.5em;">管理该成员</a>
<?php } ?>
<span class="r_option gray" id="mtag_member_<?=$value['uid']?>" style="padding-top:5px">
<?php if($value['status']==4) { ?>发起人
<?php } elseif($value['status']==3) { ?>组织者
<?php } elseif($value['status']==2) { ?>成员
<?php } elseif($value['status']==0) { ?>待审核
<?php } ?>
</span>

</p>

<p>
<span class="gray">性别：</span><?php if($value['sex']==2) { ?>美女<?php } elseif($value['sex']==1) { ?>帅哥<?php } else { ?>保密<?php } ?>
<?php if($value['resideprovince'] || $value['residecity']) { ?>
&nbsp;&nbsp;<span class="gray">地区：</span><a href="cp.php?ac=friend&op=search&resideprovince=<?=$value['resideprovince']?>&residecity=&searchmode=1"><?=$value['resideprovince']?></a> <a href="cp.php?ac=friend&op=search&resideprovince=<?=$value['resideprovince']?>&residecity=<?=$value['residecity']?>&searchmode=1"><?=$value['residecity']?></a>
<?php } ?>
<?php if($value['fellow']) { ?>
&nbsp;&nbsp;<span class="gray">携带好友数：</span><?=$value['fellow']?>
<?php } ?>
<?php if($event['template'] && $_SGLOBAL['supe_userevent']['status']>=3) { ?>
&nbsp;&nbsp;<?php echo nl2br(getstr($value[template], 255, 1, 0)) ?> 
<?php } ?></p>
</td>
</tr>
</table>
</td>
</tr>
<?php } } ?>
</table>
<?php } else { ?>
<div class="listEmpty">没有找到可浏览的成员信息。</div>
<?php } ?>
</div>

<div class="page"><?=$multi?></div>


<?php } elseif($view=="pic") { ?>

<?php if($picid) { ?>

﻿<div class="turn_pages clearfix"><img class="icon_arrow_l" src="image/b.gif"/><a href="<?=$theurl?>&goto=up">上一张</a> <?php if($album['picnum']) { ?><span>第 <?=$sequence?> 张</span> <span>共 <?=$album['picnum']?> 张</span><?php } ?> <a href="<?=$theurl?>&goto=down">下一张</a><img class="icon_arrow_r" src="image/b.gif"/></div>

<div class="photobox">

<div id="photo_pic" class="<?php if($pic['magicframe']) { ?> magicframe magicframe<?=$pic['magicframe']?><?php } ?>">
<?php if($pic['magicframe']) { ?>
<div class="pic_lb1">
<table cellpadding="0" cellspacing="0" class="">
<tr>
<td class="frame_jiao frame_top_left"></td>
<td class="frame_x frame_top_middle"></td>
<td class="frame_jiao frame_top_right"></td>
</tr>
<tr>
<td class="frame_y frame_middle_left"></td>
<td class="frame_middle_middle"><?php } ?><a href="<?=$theurl?>&goto=down"><img src="<?=$pic['pic']?>" alt="" /></a><?php if($pic['magicframe']) { ?></td>
<td class="frame_y frame_middle_right"></td>
</tr>
<tr>
<td class="frame_jiao frame_bottom_left"></td>
<td class="frame_x frame_bottom_middle"></td>
<td class="frame_jiao frame_bottom_right"></td>
</tr>
</table>
</div><?php } ?>

</div>
<div class="photo_name">
<p class="info_name"><span title="照片标题" style="cursor: pointer;"><?=$pic['title']?></span>  <?php if($_SGLOBAL['supe_uid'] == $pic['uid'] || checkperm('managealbum')) { ?><a href="cp.php?ac=album&op=edittitle&albumid=<?=$pic['albumid']?>&picid=<?=$pic['picid']?>" id="a_set_title" onclick="ajaxmenu(event, this.id)">编辑</a><?php } ?></p> 
<p class="info_fun"> <a href="<?=$pic['pic']?>" target="_blank">查看原图</a>   <?php if(!isset($_GET['exif'])) { ?><a href="<?=$theurl?>&exif">查看EXIF信息</a>   <?php } ?><?php if($_GET['play']) { ?>
<a href="javascript:;" id="playid" onclick="playNextPic(false);">停止播放</a>
<?php } else { ?>
<a href="javascript:;" id="playid" onclick="playNextPic(true);">幻灯播放</a>
<?php } ?><span id="displayNum"></span>
</p>
<?php if(isset($_GET['exif'])) { ?>
<?php if($exifs) { ?>
<?php if(is_array($exifs)) { foreach($exifs as $key => $value) { ?>
<?php if($value) { ?><p><?=$key?> : <?=$value?></p><?php } ?>
<?php } } ?>
<?php } else { ?>
<p>无EXIF信息</p>
<?php } ?>
<?php } ?>
        <?php if($topic) { ?>
<p>
<a class="icon i-topic" title="凑热闹"></a>
凑个热闹：<a href="space.php?do=topic&topicid=<?=$topic['topicid']?>"><?=$topic['subject']?></a></p>
<?php } ?>

<?php if($do!='event' && $event['title']) { ?>
<p>来自活动：<a href="space.php?do=event&id=<?=$event['eventid']?>&view=pic"><?=$event['title']?></a></p>
<?php } ?>
<?php if($album['friend']) { ?>
    <span class="locked gray"><?=$friendsname[$value['friend']]?></span>
    <?php } ?>
</div>
</div>

<div class="info_photo_wrap">
<div class="info_photo_l clearfix">
<p class="gray">
<?php if($pic['hot']) { ?><span class="hot"><em>热</em><?=$pic['hot']?></span><?php } ?>
<?php if($do=='event') { ?><a href="space.php?uid=<?=$pic['uid']?>" target="_blank"><?=$_SN[$pic['uid']]?></a><?php } ?>
上传于 <?php echo sgmdate('Y-m-d H:i',$pic[dateline]); ?> (<?=$pic['size']?>)
</p>
</div>
<div class="info_photo_r">
<?php if($pic['uid'] == $_SGLOBAL['supe_uid']) { ?>
<?php if($_SGLOBAL['magic']['frame']) { ?>
<?php if($pic['magicframe']) { ?>
<a id="a_magic_frame" class="opt opt-photoEdit" href="cp.php?ac=magic&op=cancelframe&idtype=picid&id=<?=$pic['picid']?>" onclick="ajaxmenu(event,this.id)">取消相框</a>
<?php } else { ?>
<a id="a_magic_frame" class="opt opt-photoEdit" href="magic.php?mid=frame&idtype=picid&id=<?=$pic['picid']?>" onclick="ajaxmenu(event,this.id, 1)">加相框</a>
<?php } ?>

<?php } ?>
<a class="opt opt-edit" href="cp.php?ac=album&op=editpic&albumid=<?=$pic['albumid']?>&picid=<?=$pic['picid']?>">管理图片</a>
<?php } ?>

<?php if($_SGLOBAL['supe_uid'] == $pic['uid'] || checkperm('managealbum')) { ?>
<a class="opt opt-setAvatar" href="cp.php?ac=topic&op=join&id=<?=$pic['picid']?>&idtype=picid" id="a_topicjoin_<?=$pic['picid']?>" onclick="ajaxmenu(event, this.id)">凑热闹</a>
<a class="opt opt-del" href="admincp.php?ac=pic&picid=<?=$pic['picid']?>" target="_blank">删除</a>
<?php } ?>

<?php if(checkperm('managealbum')) { ?>
<a class="opt opt-reverse" href="cp.php?ac=album&picid=<?=$pic['picid']?>&op=edithot" id="a_hot_<?=$pic['picid']?>" onclick="ajaxmenu(event, this.id)">热度</a>
<?php } ?>
<a class="opt opt-tag" href="cp.php?ac=common&op=report&idtype=picid&id=<?=$pic['picid']?>" id="a_report" onclick="ajaxmenu(event, this.id, 1)">举报</a>
<a class="opt opt-share" href="cp.php?ac=share&type=pic&id=<?=$pic['picid']?>" id="a_share_<?=$pic['picid']?>" onclick="ajaxmenu(event, this.id, 1)">分享</a>
</div>
</div>

<div id="click_div">
﻿
<div class="digc">
<table>
<tr>
<?php $clicknum = 0; ?>
<?php if(is_array($clicks)) { foreach($clicks as $value) { ?>
<?php $clicknum = $clicknum + $value['clicknum']; ?>

<td valign="bottom"><div class="digface"><a class="click_pic" href="cp.php?ac=click&op=add&clickid=<?=$value['clickid']?>&idtype=<?=$idtype?>&id=<?=$id?>&hash=<?=$hash?>" id="click_<?=$idtype?>_<?=$id?>_<?=$value['clickid']?>" onclick="ajaxmenu(event, this.id, 0, 2000, 'show_click')"><img src="image/click/<?=$value['icon']?>" <?php if($value['clicknum']) { ?>alt="<?=$value['clicknum']?>次" title="<?=$value['clicknum']?>次"<?php } ?> /><sup class="click_ok" id="click_<?=$value['clickid']?>">OK</sup></a><p><?=$value['name']?></p></div></td>
<?php } } ?>
</tr>
</table>
</div>

<?php if($clickuserlist) { ?>
<div class="trace" style="padding-bottom: 10px;">

<div>
<h2>
共有 <a href="javascript:;" onclick="show_click('click_<?=$idtype?>_<?=$id?>_<?=$value['clickid']?>')"><?=$clicknum?> 人</a>  参与表态
<?php if($_SGLOBAL['magic']['anonymous']) { ?>
<a id="a_magic_anonymous" href="magic.php?mid=anonymous&idtype=<?=$idtype?>&id=<?=$id?>" onclick="ajaxmenu(event,this.id, 1)" class="gray"><?=$_SGLOBAL['magic']['anonymous']?></a>
<?php } ?>					
</h2>
</div>
<div id="trace_div">
<ul class="avatar_list" id="trace_ul">
<?php if(is_array($clickuserlist)) { foreach($clickuserlist as $value) { ?>
<li>
<?php if($value['username']) { ?>
<a class="user_img_4" href="space.php?uid=<?=$value['uid']?>" target="_blank" title="<?=$value['clickname']?>"><?php echo avatar($value[uid], 'small'); ?></a>
<p><a class="c_1" href="space.php?uid=<?=$value['uid']?>"  title="<?=$_SN[$value['uid']]?>" target="_blank"><?=$_SN[$value['uid']]?></a></p>
<?php } else { ?>
<span class="user_img_4"><img src="image/magic/hidden.gif" alt="<?=$value['clickname']?>" /></span>
<p class="c_1">匿名</p>
<?php } ?>
</li>
<?php } } ?>
</ul>
</div>
</div>
<?php } ?>

<?php if($click_multi) { ?><div class="page"><?=$click_multi?></div><?php } ?>

</div>

<div class="albumComment" id="pic_comment">
 <div>
    <a href="javascript:void(0)">评论</a> 
</div>
<div class="commentBox commentBox-large" id="comment">
    <?php if($cid) { ?>
<div class="notice">
当前只显示与你操作相关的单个评论，<a href="<?=$theurl?>#comment">点击此处查看全部评论</a>
</div>
<?php } ?>
<ul id="comment_ul">
<?php if(is_array($list)) { foreach($list as $value) { ?>
﻿
<?php if(empty($ajax_edit)) { ?><li class="commentC" id="comment_<?=$value['cid']?>_li"><?php } ?>		
<div class="commentAvatar">
<?php if($value['author']) { ?>
<a href="space.php?uid=<?=$value['authorid']?>" title="<?=$_SN[$value['authorid']]?>"><span class="avatar-32"><?php echo avatar($value[authorid],small); ?></span></a>		
            <?php } else { ?>
    <a href="javascript:void(0);" title="匿名用户"><span class="avatar-32"><img src="image/magic/hidden.gif"/></span></a>
<?php } ?>
</div>

<div class="commentOption">
    <?php if($value['authorid']==$_SGLOBAL['supe_uid'] || $value['uid']==$_SGLOBAL['supe_uid'] || checkperm('managecomment')) { ?>
<a href="cp.php?ac=comment&op=delete&cid=<?=$value['cid']?>" id="c_<?=$value['cid']?>_delete" onclick="ajaxmenu(event, this.id)" class="icon i-del" title="删除">删除</a>
    <?php } ?>
</div>
<div class="commentInfo">
<h4>
                    <?php if($value['author']) { ?>
<a href="space.php?uid=<?=$value['authorid']?>" id="author_<?=$value['cid']?>"><?=$_SN[$value['authorid']]?></a><?php } else { ?>匿名<?php } ?> <span class="meta"><?php echo sgmdate('Y-m-d H:i',$value[dateline],1); ?></span>

<?php if($value['authorid']==$_SGLOBAL['supe_uid']) { ?>
<?php if($_SGLOBAL['magic']['anonymous']) { ?>
<a class="icon i-anonymous"></a><a id="a_magic_anonymous_<?=$value['cid']?>" href="magic.php?mid=anonymous&idtype=cid&id=<?=$value['cid']?>" onclick="ajaxmenu(event,this.id, 1)"><?=$_SGLOBAL['magic']['anonymous']?></a>
<span class="meta">-</span>
<?php } ?>
<a href="cp.php?ac=comment&op=edit&cid=<?=$value['cid']?>" id="c_<?=$value['cid']?>_edit" onclick="ajaxmenu(event, this.id, 1)">编辑</a>
    <?php } ?>

<?php if($value['authorid']!=$_SGLOBAL['supe_uid'] && ($value['idtype'] != 'uid' || $space['self'])) { ?><span class="meta">-</span> <a href="cp.php?ac=comment&op=reply&cid=<?=$value['cid']?>&feedid=<?=$feedid?>" id="c_<?=$value['cid']?>_reply" onclick="ajaxmenu(event, this.id, 1)">回复</a><?php } ?><span class="meta">-</span> <a href="cp.php?ac=common&op=report&idtype=comment&id=<?=$value['cid']?>" id="a_report_<?=$value['cid']?>" onclick="ajaxmenu(event, this.id, 1)">举报</a>
</h4>
<div class="detail<?php if($value['magicflicker']) { ?> magicflicker<?php } ?>" id="comment_<?=$value['cid']?>"><?=$value['message']?></div>
</div>
<?php if(empty($ajax_edit)) { ?></li><?php } ?>

<?php } } ?>
<?php if($multi) { ?><li class="commentMore"><p class="pager-simple"><?=$multi?></p></li><?php } ?>
</ul>
<form id="quickcommentform_<?=$picid?>" name="quickcommentform_<?=$picid?>" action="cp.php?ac=comment" method="post" class="quickpost" style="padding-bottom: 1em;">
    <div class="clickComment">
        <div class="addComBox">
            <div class="commentAvatar">
<a href="space.php?uid=<?=$_SGLOBAL['supe_uid']?>" title="<?=$_SGLOBAL['supe_uid']?>"><span class="avatar-32"><?php echo avatar($_SGLOBAL[supe_uid],middle); ?></span></a>
</div>
            <div class="commentRight">
               <textarea class="addComment text" id="comment_message" onkeydown="ctrlEnter(event, 'commentsubmit_btn');" name="message"></textarea>
                <div class="commentEmot"><span class="emot e-base-1"><a href="###" id="comment_face" title="插入表情" onclick="showFace(this.id, 'comment_message');return false;"><img src="image/facelist.gif" align="absmiddle" /></a></span>
<?php if($_SGLOBAL['magic']['doodle']) { ?>
<a class="icon i-doodle"></a><a id="a_magic_doodle" href="magic.php?mid=doodle&showid=comment_doodle&target=comment_message" onclick="ajaxmenu(event, this.id, 1)">涂鸦板</a>
<?php } ?></div>
                <div class="commentBtn">
<input type="hidden" name="refer" value="<?=$theurl?>" />
<input type="hidden" name="id" value="<?=$picid?>">
<input type="hidden" name="idtype" value="picid">
<input type="hidden" name="commentsubmit" value="true">
                <span class="button button-main" ><span><button class="button" type="button" id="commentsubmit_btn" name="commentsubmit_btn" onclick="ajaxpost('quickcommentform_<?=$picid?>', 'comment_add')" >评论</button></span></span><span id="__quickcommentform_<?=$picid?>"></span>
                </div>
            </div>
        </div>
    </div><input type="hidden" name="formhash" value="<?php echo formhash(); ?>" />
</form>
    <span class="corner"></span>
</div>
<script>
    window.onload = function() {
        var reg = /commentid=\d*$/gi;
        if (reg.test(location.href)) {
            document.documentElement.scrollTop = document.documentElement.scrollHeight;
            document.body.scrollTop = document.documentElement.scrollHeight;
        }
    }
</script>

 </div>

<script type="text/javascript">
<!--
var interval = 5000;
var timerId = -1;
var derId = -1;
var replay = false;
var num = 0;
var endPlay = false;
function forward() {
window.location.href = '<?=$theurl?>&goto=down&play=1';
}
function derivativeNum() {
num++;
$('displayNum').innerHTML = '[' + (interval/1000 - num) + ']';
}
function playNextPic(stat) {
if(stat || replay) {
derId = window.setInterval('derivativeNum();', 1000);
$('displayNum').innerHTML = '[' + (interval/1000 - num) + ']';
$('playid').innerHTML = '停止播放';
timerId = window.setInterval('forward();', interval);
} else {
replay = true;
num = 0;
if(endPlay) {
$('playid').innerHTML = '重新播放';
} else {
$('playid').innerHTML = '幻灯播放';
}
$('displayNum').innerHTML = '';
window.clearInterval(timerId);
window.clearInterval(derId);
}
}
<?php if($_GET['play']) { ?>
<?php if($sequence && $album['picnum']) { ?>
if(<?=$sequence?> == <?=$album['picnum']?>) {
endPlay = true;
playNextPic(false);
} else {
playNextPic(true);
}
<?php } else { ?>
playNextPic(true);
<?php } ?>
<?php } ?>

function update_title() {
$('title_form').style.display='';
}

//彩虹炫
var elems = selector('div[class~=magicflicker]'); 
for(var i=0; i<elems.length; i++){
magicColor(elems[i]);
}

//-->
</script>


<?php } else { ?>
<div class="h_status">
<div class="r_option">
<?php if($_SGLOBAL['supe_userevent']['status'] >= 3) { ?>
<a href="cp.php?ac=event&op=pic&id=<?=$eventid?>">照片管理</a>
<?php } ?>
<?php if($event['grade']>0 && (($event['allowpic'] && $_SGLOBAL['supe_userevent']['status']>1) || $_SGLOBAL['supe_userevent']['status']>=3)) { ?>
<a href="cp.php?ac=upload&eventid=<?=$eventid?>" ><font class="act a-add">上传新照片</font></a>
<?php } ?>
</div>
<span>活动相册 - 共 <?=$piccount?> 张照片</span>
</div>

<?php if($photolist) { ?>
<div class="photoList" style="margin:0 12px 10px 12px;padding:0;">
<table cellspacing="6" cellpadding="0" width="100%" class="photo_list">
<tr>
<?php if(is_array($photolist)) { foreach($photolist as $key => $value) { ?>
<td>
<a title="<?=$value['title']?>" href="space.php?do=event&id=<?=$eventid?>&view=pic&picid=<?=$value['picid']?>">
<img class="photo-130" alt="<?=$value['title']?>" src="<?=$value['pic']?>"/>
</a>
<p>
<span class="gray">来自</span> <a href="space.php?uid=<?=$value['uid']?>" style="display:inline;width:auto;height:auto;"><?=$_SN[$value['uid']]?></a>
</p>
</td>
<?php if($key%4==3) { ?></tr><tr><?php } ?>
<?php } } ?>
</tr>
</table>
</div>
<div class="pager"><?=$multi?></div>
<?php } else { ?>
<div class="listEmpty">
<p >还没有活动照片<?php if($event['grade']>0 && (($event['allowpic'] && $_SGLOBAL['supe_userevent']['status']>1) || $_SGLOBAL['supe_userevent']['status']>=3)) { ?>，我来<a href="cp.php?ac=upload&eventid=<?=$eventid?>">上传</a> <?php } ?></p>
</div>
<?php } ?>
<?php } ?>

<?php } elseif($view == "thread") { ?>
<div class="m_box">
<h2 class="h_status" style="border-bottom:none;margin-bottom:0px">
<div class="r_option">
<?php if($_SGLOBAL['supe_userevent']['status'] >= 3) { ?>
<a href="cp.php?ac=event&op=thread&id=<?=$eventid?>">话题管理</a>
<?php } ?>
<?php if($event['grade']>0 && $_SGLOBAL['supe_userevent']['status']>=2) { ?>
<a href="cp.php?ac=thread&tagid=<?=$event['tagid']?>&eventid=<?=$eventid?>"><font class="act a-add">发表新话题</font></a>
<?php } ?>
</div>
话题
</h2>
<?php if($threadlist) { ?>
<div class="disList">
<table cellspacing="0" cellpadding="0">
<tbody>
 <tr>
 <th width="70%" class="t1">主题</th>
 <th width="10%">回复/阅读</th>
 <th width="17%">作者</th>
 </tr>
<?php if(is_array($threadlist)) { foreach($threadlist as $key => $value) { ?>
<?php $magicegg = "" ?>
<?php if($value[magicegg]) for($i=0; $i<$value[magicegg]; $i++) $magicegg .= '<img src="image/magic/egg/'.mt_rand(1,6).'.gif" />'; ?>
<tr <?php if($key%2==1) { ?>class="alt"<?php } ?>>
<td class="t1"><span class="icon"></span>
<?=$magicegg?>
<a href="space.php?uid=<?=$value['uid']?>&do=thread&id=<?=$value['tid']?>&eventid=<?=$eventid?>" <?php if($value['magiccolor']) { ?> class="magiccolor<?=$value['magiccolor']?>"<?php } ?>><?=$value['subject']?></a>
<span class="time">回复：<?php echo sgmdate('m-d H:i',$value[lastpost],1); ?></span><span class="rUser"><a href="space.php?uid=<?=$value['lastauthorid']?>" title="<?=$_SN[$value['lastauthorid']]?>"><?=$_SN[$value['lastauthorid']]?></a></span>
</td>
<td class="t2"><span class="fontBlue"><?=$value['replynum']?></span>/<?=$value['viewnum']?></td>
<td class="t3">
<a href="space.php?uid=<?=$value['uid']?>" title="<?=$_SN[$value['uid']]?>"><span class="avatar-20"><?php echo avatar($value[uid],small); ?></span></a>
<a href="space.php?uid=<?=$value['uid']?>"><?=$_SN[$value['uid']]?></a>
</td>
</tr>
<?php } } ?>
</tbody>
</table>
</div>
<div class="page"><?=$multi?></div>
<?php } else { ?>
<div class="listEmpty">还没有相关话题。
<?php if($event['grade']>0 && $_SGLOBAL['supe_userevent']['status']>=2) { ?>
<a href="cp.php?ac=thread&tagid=<?=$event['tagid']?>&eventid=<?=$eventid?>">我来发表</a><?php } ?>
</div>
<?php } ?>
</div>

<?php } elseif($view=="comment") { ?>

<div class="m_box">
<div class="h_status">
<span>活动留言</span>
</div>
<div class="commentBox commentBox-large" id="comment">
<input type="hidden" value="1" name="comment_prepend" id="comment_prepend" />
<ul id="comment_ul">
<?php if(is_array($comments)) { foreach($comments as $value) { ?>
﻿
<?php if(empty($ajax_edit)) { ?><li class="commentC" id="comment_<?=$value['cid']?>_li"><?php } ?>		
<div class="commentAvatar">
<?php if($value['author']) { ?>
<a href="space.php?uid=<?=$value['authorid']?>" title="<?=$_SN[$value['authorid']]?>"><span class="avatar-32"><?php echo avatar($value[authorid],small); ?></span></a>		
            <?php } else { ?>
    <a href="javascript:void(0);" title="匿名用户"><span class="avatar-32"><img src="image/magic/hidden.gif"/></span></a>
<?php } ?>
</div>

<div class="commentOption">
    <?php if($value['authorid']==$_SGLOBAL['supe_uid'] || $value['uid']==$_SGLOBAL['supe_uid'] || checkperm('managecomment')) { ?>
<a href="cp.php?ac=comment&op=delete&cid=<?=$value['cid']?>" id="c_<?=$value['cid']?>_delete" onclick="ajaxmenu(event, this.id)" class="icon i-del" title="删除">删除</a>
    <?php } ?>
</div>
<div class="commentInfo">
<h4>
                    <?php if($value['author']) { ?>
<a href="space.php?uid=<?=$value['authorid']?>" id="author_<?=$value['cid']?>"><?=$_SN[$value['authorid']]?></a><?php } else { ?>匿名<?php } ?> <span class="meta"><?php echo sgmdate('Y-m-d H:i',$value[dateline],1); ?></span>

<?php if($value['authorid']==$_SGLOBAL['supe_uid']) { ?>
<?php if($_SGLOBAL['magic']['anonymous']) { ?>
<a class="icon i-anonymous"></a><a id="a_magic_anonymous_<?=$value['cid']?>" href="magic.php?mid=anonymous&idtype=cid&id=<?=$value['cid']?>" onclick="ajaxmenu(event,this.id, 1)"><?=$_SGLOBAL['magic']['anonymous']?></a>
<span class="meta">-</span>
<?php } ?>
<a href="cp.php?ac=comment&op=edit&cid=<?=$value['cid']?>" id="c_<?=$value['cid']?>_edit" onclick="ajaxmenu(event, this.id, 1)">编辑</a>
    <?php } ?>

<?php if($value['authorid']!=$_SGLOBAL['supe_uid'] && ($value['idtype'] != 'uid' || $space['self'])) { ?><span class="meta">-</span> <a href="cp.php?ac=comment&op=reply&cid=<?=$value['cid']?>&feedid=<?=$feedid?>" id="c_<?=$value['cid']?>_reply" onclick="ajaxmenu(event, this.id, 1)">回复</a><?php } ?><span class="meta">-</span> <a href="cp.php?ac=common&op=report&idtype=comment&id=<?=$value['cid']?>" id="a_report_<?=$value['cid']?>" onclick="ajaxmenu(event, this.id, 1)">举报</a>
</h4>
<div class="detail<?php if($value['magicflicker']) { ?> magicflicker<?php } ?>" id="comment_<?=$value['cid']?>"><?=$value['message']?></div>
</div>
<?php if(empty($ajax_edit)) { ?></li><?php } ?>

<?php } } ?>
<?php if($comments && count($comments) >= 20) { ?>
<li class="commentMore"><a href="javascript:void(0)" onclick="<?=$call?>(function(){sohu.comment.init({type:'all',appid:'10',itemid:'f76822259',allow:'true'})}, 'sohu.comment.*')">显示更多留言...</a></li>
<?php } ?>
</ul>
<?php if($multi) { ?><div class="pager"><?=$multi?></div><?php } ?>
<form action="cp.php?ac=comment" id="commentform_<?=$space['uid']?>" name="commentform_<?=$space['uid']?>" method="post">
<div class="clickComment">
<div class="addComBox">
<div class="commentAvatar">
<a href="space.php?uid=<?=$_SGLOBAL['supe_uid']?>" title="<?=$_SGLOBAL['supe_uid']?>"><span class="avatar-32"><?php echo avatar($_SGLOBAL[supe_uid],middle); ?></span></a>
</div>
<div class="commentRight">
<?php if($event['grade']>0 && ($event['allowpost'] || $_SGLOBAL['supe_userevent']['status'] > 1)) { ?>
    <textarea name="message" id="comment_message" onkeydown="ctrlEnter(event, 'commentsubmit_btn');" class="addComment text"></textarea>
<div class="commentEmot"><span class="emot e-base-1"><a href="###" id="message_face" onclick="showFace(this.id, 'comment_message');return false;"><img src="image/facelist.gif" align="absmiddle" /></a></span>
<?php if($_SGLOBAL['magic']['doodle']) { ?>
<a class="icon i-doodle"></a><a id="a_magic_doodle" href="magic.php?mid=doodle&showid=comment_doodle&target=comment_message" onclick="ajaxmenu(event, this.id, 1)">涂鸦板</a>
<?php } ?>
</div>
<div class="commentBtn">
<input type="hidden" name="refer" value="space.php?do=event&id=<?=$eventid?>" />
<input type="hidden" name="id" value="<?=$eventid?>" />
<input type="hidden" name="idtype" value="eventid" />
<input type="hidden" name="commentsubmit" value="true" />
<span class="button button-main"><span><input type="button" id="commentsubmit_btn" name="commentsubmit_btn" value="留言" onclick="ajaxpost('commentform_<?=$space['uid']?>', 'wall_add')" /></span></span><span id="__commentform_<?=$space['uid']?>"></span>
</div>
<?php } elseif($event['grade']>0) { ?>
<textarea name="message" id="comment_message" class="text" rows="3"  cols="60" readonly="">只有活动成员才能发布留言</textarea>
<?php } ?>
</div>
</div>
</div>
<input type="hidden" name="formhash" value="<?php echo formhash(); ?>" />
</form>
   </div>
</div>

<script type="text/javascript">
//彩虹炫
var elems = selector('div[class~=magicflicker]'); 
for(var i=0; i<elems.length; i++){
magicColor(elems[i]);
}
</script>

<?php } else { ?>

<div class="colmain" style="width:610px;padding:0 10px">
<div class="m_box">
<div class="event">

<div class="event_icon">
<a href="<?=$event['pic']?>" target="_blank"><img class="poster_pre" src="<?=$event['pic']?>" alt="<?=$event['title']?>" onerror="this.src='<?=$_SGLOBAL['eventclass'][$event['classid']]['poster']?>'"></a>
</div>
<div class="event_content">
<ul class="info_title bor_b_2">
<li><h2><?=$event['title']?></h2></li>
<li>
<?php if($event['hot']) { ?><span class="hot"><em>热</em><?=$event['hot']?></span><?php } ?>
<?php if(!empty($_SGLOBAL['supe_userevent']) && $_SGLOBAL['supe_userevent']['status'] == 0 && $_SGLOBAL['timestamp']<$event['endtime']) { ?>
您的报名正在审核中
<?php } elseif($_SGLOBAL['supe_userevent']['status'] == 1) { ?>
您关注了此活动
<?php } elseif($_SGLOBAL['supe_userevent']['status'] >= 2) { ?>
您参加了此活动
<?php } ?>

<?php if($event['starttime'] > $_SGLOBAL['timestamp']) { ?>
<?php if($countdown) { ?>
距活动开始还有 <?=$countdown?> 天
<?php } else { ?>
活动今天开始
<?php } ?>
<?php } elseif($event['starttime'] <= $_SGLOBAL['timestamp'] && $event['endtime'] >= $_SGLOBAL['timestamp']) { ?>
此活动正在进行中
<?php } else { ?>
活动已经结束
<?php } ?>
</li>
</ul>
<dl>

<dt class="gray">活动类型:</dt>
<dd><?=$_SGLOBAL['eventclass'][$event['classid']]['classname']?></dd>
<dt class="gray">活动地点:</dt>
<dd><?=$event['province']?> <?=$event['city']?> <?=$event['location']?></dd>
<dt class="gray">活动时间:</dt>
<dd><?php echo sgmdate("m月d日 H:i", $event[starttime]) ?> - <?php echo sgmdate("m月d日 H:i", $event[endtime]) ?></dd>
<dt class="gray">截止报名:</dt>
<dd>
<?php if($event['deadline']>=$_SGLOBAL['timestamp']) { ?>
<?php echo sgmdate("m月d日 H:i", $event[deadline]) ?>
<?php } else { ?>
报名结束
<?php } ?>
</dd>
<dt class="gray">活动人数:</dt>
<dd><?php if($event['limitnum']) { ?><?=$event['limitnum']?> （还剩 <?php echo $event[limitnum] - $event[membernum] ?> 个名额）<?php } else { ?>不限<?php } ?></dd>
<dt class="gray">需要审核:</dt>
<dd><?php if($event['verify'] == 0) { ?>不<?php } ?>需要</dd>
</dl>
<ul>
<li><?=$event['viewnum']?> 次查看</li>
<li><?=$event['membernum']?> 人参加</li>
<li><?=$event['follownum']?> 人关注</li>
<?php if($verifynum && $_SGLOBAL['supe_userevent']['status']>=3) { ?><li><b><a href="cp.php?ac=event&id=<?=$eventid?>&op=members&status=0"><?=$verifynum?></a></b> 人待审核</li><?php } ?>
</ul>
<?php if($event['grade']>0 && $_SGLOBAL['timestamp']<=$event['endtime']) { ?>
<ul >
<?php if(empty($_SGLOBAL['supe_userevent']) && $event['deadline'] > $_SGLOBAL['timestamp']) { ?>
<?php if($event['limitnum']==0 || $event['membernum']<$event['limitnum']) { ?>
<li><span class="button button-main"><span><a id="a_join" href="cp.php?ac=event&op=join&id=<?=$eventid?>" onclick="ajaxmenu(event, this.id)">我要参加</a></span></span></li>
<?php } ?>
<li><span class="button button-main"><span><a id="a_follow" href="cp.php?ac=event&op=follow&id=<?=$eventid?>" onclick="ajaxmenu(event, this.id)">我要关注</a></span></span></li>
<?php } elseif(!empty($_SGLOBAL['supe_userevent']) && $_SGLOBAL['supe_userevent']['status'] == 0) { ?>
<?php if($event['deadline'] > $_SGLOBAL['timestamp'] && ($event['template'] || $event['allowfellow'])) { ?>
<li><span class="button button-main"><span><a id="a_join" href="cp.php?ac=event&id=<?=$eventid?>&op=join" onclick="ajaxmenu(event, this.id)" >修改报名信息</a></span></span></li>
<?php } ?>
<li><span class="button button-main"><span><a id="a_quit" href="cp.php?ac=event&id=<?=$eventid?>&op=quit" onclick="ajaxmenu(event, this.id)" >不参加了</a></span></span></li>
<?php } elseif($_SGLOBAL['supe_userevent']['status'] == 1) { ?>
<?php if($event['deadline'] > $_SGLOBAL['timestamp'] && ($event['limitnum']==0 || $event['membernum']<$event['limitnum'])) { ?>
<li><span class="button button-main"><span><a id="a_join" href="cp.php?ac=event&op=join&id=<?=$eventid?>" onclick="ajaxmenu(event, this.id)" >我要参加</a></span></span></li>
<?php } ?>
<li><span class="button button-main"><span><a id="a_cancelfollow" href="cp.php?ac=event&id=<?=$eventid?>&op=cancelfollow" onclick="ajaxmenu(event, this.id)" >取消关注</a></span></span></li>
<?php } elseif($_SGLOBAL['supe_userevent']['status'] > 1) { ?>
<?php if($event['grade']>0 && $_SGLOBAL['timestamp']<= $event['deadline'] && ($event['limitnum'] <= 0 || $event['membernum'] < $event['limitnum']) && ($_SGLOBAL['supe_userevent']['status'] >= 3 || $event['allowinvite'])) { ?>
<li><span class="button button-main"><span><a href="cp.php?ac=event&id=<?=$eventid?>&op=invite" >邀请好友</a></span></span></li>
<?php } ?>
<?php if($_SGLOBAL['supe_uid'] != $event['uid']) { ?>
<li><span class="button button-main"><span><a id="a_quit" href="cp.php?ac=event&id=<?=$eventid?>&op=quit" onclick="ajaxmenu(event, this.id)">不参加了</a></span></span></li>
<?php } ?>
<?php } ?>
</ul>
<?php } ?>
</div>
</div>
</div>

<div class="m_box">
<h3 class="feed_header">活动介绍</h3>
<div class="event_article">
<?=$event['detail']?>
</div>
</div>

<div class="m_box">
<h3 class="feed_header">
<div class="r_option"><a href="space.php?do=event&id=<?=$eventid?>&view=member&status=2">全部</a></div>
活动成员
</h3>
<?php if($members) { ?>
<ul class="avatar_list">
<?php if(is_array($members)) { foreach($members as $key => $userevent) { ?>
<li>
<div class="avatar-48"><a title="<?=$_SN[$userevent['uid']]?>" href="space.php?uid=<?=$userevent['uid']?>"><?php echo avatar($userevent[uid]); ?></a></div>
<p>
<a href="space.php?uid=<?=$userevent['uid']?>"><?=$_SN[$userevent['uid']]?></a>
</p>
<?php if($event['allowfellow']) { ?>
<p><?php if($userevent['fellow']) { ?>携带 <?=$userevent['fellow']?> 人<?php } ?></p>
<?php } ?>
</li>
<?php } } ?>
</ul>
<?php } else { ?>
<p style="text-align:center; padding:20px">还没有活动成员。
<?php if($event['grade']>0 && $_SGLOBAL['timestamp']<= $event['deadline'] && ($event['limitnum'] <= 0 || $event['membernum'] < $event['limitnum']) && ($_SGLOBAL['supe_userevent']['status'] >= 3 || ($event['allowinvite'] && $_SGLOBAL['supe_userevent']['status']==2))) { ?>
<a href="cp.php?ac=event&id=<?=$eventid?>&op=invite">邀请好友参加</a>
<?php } ?>
</p>
<?php } ?>
</div>

<div class="m_box">
<div class="ye_l_b">
<h2 class="atitle">
<div class="r_option">
<?php if($event['grade']>0 && (($event['allowpic'] && $_SGLOBAL['supe_userevent']['status']>1) || $_SGLOBAL['supe_userevent']['status']>=3)) { ?>
<a href="cp.php?ac=upload&eventid=<?=$eventid?>">上传</a> | <?php } ?>
<a href="space.php?do=event&id=<?=$eventid?>&view=pic">全部</a>
</div>
相册<?php if($event['picnum']) { ?> <span style="font-weight:normal">(共 <?=$event['picnum']?> 张照片)</span><?php } ?>
</h2>
<?php if($photolist) { ?>
<ul class="albs2">
<?php if(is_array($photolist)) { foreach($photolist as $key => $value) { ?>
<li>
<a title="<?=$value['title']?>" href="space.php?do=event&id=<?=$eventid?>&view=pic&picid=<?=$value['picid']?>">
<img style="width: 75px; height: 75px;" alt="<?=$value['title']?>" src="<?=$value['pic']?>"/></a>
<p style="text-align:left;">
<span class="gray">来自</span> <a href="space.php?uid=<?=$value['uid']?>" style="display:inline;width:auto;height:auto;"><?=$_SN[$value['uid']]?></a>
</p>
</li>
<?php } } ?>
</ul>
<?php } else { ?>
<p class="event_albs_p">还没有活动照片。<?php if($event['grade']>0 && (($event['allowpic'] && $_SGLOBAL['supe_userevent']['status']>1) || $_SGLOBAL['supe_userevent']['status']>=3)) { ?><a href="cp.php?ac=upload&eventid=<?=$eventid?>">我来上传</a> <?php } ?></p>
<?php } ?>
</div>
</div>

<?php if($event['tagid']) { ?>
<div class="m_box">
<h2 class="feed_header">
<div class="r_option">
<?php if($event['grade']>0 && $_SGLOBAL['supe_userevent']['status']>=2) { ?>
<a href="cp.php?ac=thread&tagid=<?=$event['tagid']?>&eventid=<?=$eventid?>">发表</a> | <?php } ?>
<a href="space.php?do=event&id=<?=$eventid?>&view=thread">全部</a>
</div>
话题<?php if($event['threadnum']) { ?> <span style="font-weight:normal">(共 <?=$event['threadnum']?> 个话题)</span><?php } ?>
</h2>
<?php if($threadlist) { ?>
<div class="disList">
<table cellspacing="0" cellpadding="0">
<thead>
<tr>
<td class="t1" width="60%"><b>主题</b></td>
<td width="20%"><b>回应/阅读</b></td>
<td width="17%"><b>最后更新</b></td>
</tr>
</thead>
<tbody>
<?php if(is_array($threadlist)) { foreach($threadlist as $key => $value) { ?>
<tr <?php if($key%2==1) { ?>class="alt"<?php } ?>>
<td class="t1"><span class="icon"></span>
<a href="space.php?uid=<?=$value['uid']?>&do=thread&id=<?=$value['tid']?>&eventid=<?=$eventid?>"><?=$value['subject']?></a>
</td>
<td class="t2"><span class="fontBlue"><?=$value['replynum']?></span>/<?=$value['viewnum']?></td>
<td class="t3"><a href="space.php?uid=<?=$value['uid']?>" title="<?=$_SN[$value['uid']]?>"><span class="avatar-20"><?php echo avatar($value[uid],small); ?></span></a> <a href="space.php?uid=<?=$value['uid']?>"><?=$_SN[$value['uid']]?></a> </td>
</tr>
<?php } } ?>
</tbody>
</table>
</div>
<?php } else { ?>
<p style="text-align:center; padding:20px">还没有相关话题。
<?php if($event['grade']>0 && $_SGLOBAL['supe_userevent']['status']>=2) { ?>
<a href="cp.php?ac=thread&tagid=<?=$event['tagid']?>&eventid=<?=$eventid?>">我来发表</a><?php } ?>
</p>
<?php } ?>
</div>
<?php } ?>

<div class="m_box">
<h2 class="feed_header" style="margin-bottom:10px">
<div class="r_option">
<a href="space.php?do=event&id=<?=$eventid?>&view=comment">全部</a>
</div>
留言
</h2>
<div class="commentBox commentBox-large" id="comment">
<input type="hidden" value="1" name="comment_prepend" id="comment_prepend" />
<ul id="comment_ul">
<?php if(is_array($comments)) { foreach($comments as $value) { ?>
﻿
<?php if(empty($ajax_edit)) { ?><li class="commentC" id="comment_<?=$value['cid']?>_li"><?php } ?>		
<div class="commentAvatar">
<?php if($value['author']) { ?>
<a href="space.php?uid=<?=$value['authorid']?>" title="<?=$_SN[$value['authorid']]?>"><span class="avatar-32"><?php echo avatar($value[authorid],small); ?></span></a>		
            <?php } else { ?>
    <a href="javascript:void(0);" title="匿名用户"><span class="avatar-32"><img src="image/magic/hidden.gif"/></span></a>
<?php } ?>
</div>

<div class="commentOption">
    <?php if($value['authorid']==$_SGLOBAL['supe_uid'] || $value['uid']==$_SGLOBAL['supe_uid'] || checkperm('managecomment')) { ?>
<a href="cp.php?ac=comment&op=delete&cid=<?=$value['cid']?>" id="c_<?=$value['cid']?>_delete" onclick="ajaxmenu(event, this.id)" class="icon i-del" title="删除">删除</a>
    <?php } ?>
</div>
<div class="commentInfo">
<h4>
                    <?php if($value['author']) { ?>
<a href="space.php?uid=<?=$value['authorid']?>" id="author_<?=$value['cid']?>"><?=$_SN[$value['authorid']]?></a><?php } else { ?>匿名<?php } ?> <span class="meta"><?php echo sgmdate('Y-m-d H:i',$value[dateline],1); ?></span>

<?php if($value['authorid']==$_SGLOBAL['supe_uid']) { ?>
<?php if($_SGLOBAL['magic']['anonymous']) { ?>
<a class="icon i-anonymous"></a><a id="a_magic_anonymous_<?=$value['cid']?>" href="magic.php?mid=anonymous&idtype=cid&id=<?=$value['cid']?>" onclick="ajaxmenu(event,this.id, 1)"><?=$_SGLOBAL['magic']['anonymous']?></a>
<span class="meta">-</span>
<?php } ?>
<a href="cp.php?ac=comment&op=edit&cid=<?=$value['cid']?>" id="c_<?=$value['cid']?>_edit" onclick="ajaxmenu(event, this.id, 1)">编辑</a>
    <?php } ?>

<?php if($value['authorid']!=$_SGLOBAL['supe_uid'] && ($value['idtype'] != 'uid' || $space['self'])) { ?><span class="meta">-</span> <a href="cp.php?ac=comment&op=reply&cid=<?=$value['cid']?>&feedid=<?=$feedid?>" id="c_<?=$value['cid']?>_reply" onclick="ajaxmenu(event, this.id, 1)">回复</a><?php } ?><span class="meta">-</span> <a href="cp.php?ac=common&op=report&idtype=comment&id=<?=$value['cid']?>" id="a_report_<?=$value['cid']?>" onclick="ajaxmenu(event, this.id, 1)">举报</a>
</h4>
<div class="detail<?php if($value['magicflicker']) { ?> magicflicker<?php } ?>" id="comment_<?=$value['cid']?>"><?=$value['message']?></div>
</div>
<?php if(empty($ajax_edit)) { ?></li><?php } ?>

<?php } } ?>
<?php if($comments && count($comments) >= 20) { ?>
<li class="commentMore"><a href="javascript:void(0)" onclick="<?=$call?>(function(){sohu.comment.init({type:'all',appid:'10',itemid:'f76822259',allow:'true'})}, 'sohu.comment.*')">显示更多留言...</a></li>
<?php } ?>
</ul>
<form action="cp.php?ac=comment" id="commentform_<?=$space['uid']?>" name="commentform_<?=$space['uid']?>" method="post">
<div class="clickComment">
<div class="addComBox">
<div class="commentAvatar">
<a href="space.php?uid=<?=$_SGLOBAL['supe_uid']?>" title="<?=$_SGLOBAL['supe_uid']?>"><span class="avatar-32"><?php echo avatar($_SGLOBAL[supe_uid],middle); ?></span></a>
</div>
<div class="commentRight">
<?php if($event['grade']>0 && ($event['allowpost'] || $_SGLOBAL['supe_userevent']['status'] > 1)) { ?>
    <textarea name="message" id="comment_message" onkeydown="ctrlEnter(event, 'commentsubmit_btn');" class="addComment text"></textarea>
<div class="commentEmot"><span class="emot e-base-1"><a href="###" id="message_face" onclick="showFace(this.id, 'comment_message');return false;"><img src="image/facelist.gif" align="absmiddle" /></a></span>
<?php if($_SGLOBAL['magic']['doodle']) { ?>
<a class="icon i-doodle"></a><a id="a_magic_doodle" href="magic.php?mid=doodle&showid=comment_doodle&target=comment_message" onclick="ajaxmenu(event, this.id, 1)">涂鸦板</a>
<?php } ?>
</div>
<div class="commentBtn">
<input type="hidden" name="refer" value="space.php?do=event&id=<?=$eventid?>" />
<input type="hidden" name="id" value="<?=$eventid?>" />
<input type="hidden" name="idtype" value="eventid" />
<input type="hidden" name="commentsubmit" value="true" />
<span class="button button-main"><span><input type="button" id="commentsubmit_btn" name="commentsubmit_btn" value="留言" onclick="ajaxpost('commentform_<?=$space['uid']?>', 'wall_add')" /></span></span><span id="__commentform_<?=$space['uid']?>"></span>
</div>
<?php } elseif($event['grade']>0) { ?>
<textarea name="message" id="comment_message" class="text" rows="3"  cols="60" readonly="">只有活动成员才能发布留言</textarea>
<?php } ?>
</div>
</div>
</div>
<input type="hidden" name="formhash" value="<?php echo formhash(); ?>" />
</form>
   </div>
</div>

</div>

<div class="colSub" style="width:200px">

<?php if($topic) { ?>
<div class="affiche5">
<img src="image/app/topic.gif" align="absmiddle">
<strong>凑个热闹</strong>：<a href="space.php?do=topic&topicid=<?=$topic['topicid']?>"><?=$topic['subject']?></a>
</div>
<?php } ?>

<?php if($_SGLOBAL['supe_userevent']['status'] > 1) { ?>
<div class="sidebox">
<h2 class="title">活动菜单</h2>
<ul class="menu_list" style="width:180px">
<?php if($_SGLOBAL['supe_userevent']['status'] >= 3) { ?>
<?php if($event['grade']>0 || $event['grade']==-2) { ?>
<li><a href="cp.php?ac=event&id=<?=$eventid?>&op=members">成员管理</a></li>
<?php } ?>
<li><a href="cp.php?ac=event&id=<?=$eventid?>&op=edit">活动管理</a></li>
<?php if($event['grade']>0 || $event['grade']==-2) { ?>
<li><a href="cp.php?ac=event&id=<?=$eventid?>&op=pic">相册管理</a></li>
<?php if($event['tagid']) { ?>
<li><a href="cp.php?ac=event&id=<?=$eventid?>&op=thread">话题管理</a></li>
<?php } ?>
<?php } ?>
<?php } ?>
<?php if($event['grade']>0 && $_SGLOBAL['timestamp']<= $event['deadline'] && ($event['limitnum'] <= 0 || $event['membernum'] < $event['limitnum']) && ($_SGLOBAL['supe_userevent']['status'] >= 3 || $event['allowinvite'])) { ?>
<li><a href="cp.php?ac=event&id=<?=$eventid?>&op=invite">邀请好友</a></li>
<?php } ?>
<?php if($event['grade']>0 && $_SGLOBAL['timestamp']<= $event['deadline'] && ($event['template'] || $event['allowfellow'])) { ?>
<li><a id="a_join" href="cp.php?ac=event&id=<?=$eventid?>&op=join" onclick="ajaxmenu(event, this.id)">报名信息</a></li>
<?php } ?>
<?php if($_SGLOBAL['supe_userevent']['status'] >= 3 && $event['endtime'] >= $_SGLOBAL['timestamp']) { ?>
<li><a id="a_print" href="cp.php?ac=event&id=<?=$eventid?>&op=print" onclick="ajaxmenu(event, this.id)">打签到表</a></li>
<?php } ?>
<?php if($_SGLOBAL['supe_userevent']['uid'] == $event['uid']) { ?>
<?php if($event['grade']>0 && $_SGLOBAL['timestamp']>$event['endtime']) { ?>
<li><a id="a_close" onclick="ajaxmenu(event, this.id)" href="cp.php?ac=event&id=<?=$eventid?>&op=close">关闭活动</a></li>
<?php } ?>
<?php if($event['grade']==-2 && $_SGLOBAL['timestamp']>$event['endtime']) { ?>
<li><a id="a_open" onclick="ajaxmenu(event, this.id)" href="cp.php?ac=event&id=<?=$eventid?>&op=open">开启活动</a></li>
<?php } ?>
<li><a id="a_delete" onclick="ajaxmenu(event, this.id)" href="cp.php?ac=event&id=<?=$eventid?>&op=delete">取消活动</a></li>
<?php } elseif($_SGLOBAL['endtime']<= $_SGLOBAL['timestamp']) { ?>
<li><a id="a_quit2" onclick="ajaxmenu(event, this.id)" href="cp.php?ac=event&id=<?=$eventid?>&op=quit">退出活动</a></li>
<?php } ?>
</ul>
</div>
<?php } ?>

<div class="sidebox">
<h2 class="title">
组织者
</h2>
<ul class="avatar_list">
<?php if(is_array($admins)) { foreach($admins as $key => $userevent) { ?>
<li>
<div class="avatar-48"><a title="<?=$_SN[$userevent['uid']]?>" href="space.php?uid=<?=$userevent['uid']?>"><?php echo avatar($userevent[uid]); ?></a></div>
<p><a href="space.php?uid=<?=$userevent['uid']?>"><?=$_SN[$userevent['uid']]?></a></p>
</li>
<?php } } ?>
</ul>
</div>

<?php if($follows) { ?>
<div class="sidebox">
<h2 class="title">
<p class="r_option">
<a href="space.php?do=event&id=<?=$eventid?>&view=member&status=1">全部</a>
</p>
关注的人
</h2>
<ul class="avatar_list">
<?php if(is_array($follows)) { foreach($follows as $key => $userevent) { ?>
<li>
<div class="avatar-48"><a title="<?=$_SN[$userevent['uid']]?>" href="space.php?uid=<?=$userevent['uid']?>"><?php echo avatar($userevent[uid]); ?></a></div>
<p><a href="space.php?uid=<?=$userevent['uid']?>"><?=$_SN[$userevent['uid']]?></a></p>
</li>
<?php } } ?>
</ul>
</div>
<?php } ?>

<?php if(!empty($relatedevents)) { ?>
<div class="sidebox">
<h2 class="title">
参加这个活动的人也参加了
</h2>
<ul class="attention">
<?php if(is_array($relatedevents)) { foreach($relatedevents as $value) { ?>
<li>
<p>
<a target="_blank" href="space.php?do=event&id=<?=$value['eventid']?>"><?=$value['title']?></a>
</p>
<p class="gray" style="text-align: left">
<?php if($_SGLOBAL['timestamp'] > $value['endtime']) { ?>
已结束
<?php } else { ?>
<?php echo sgmdate("n月j日",$value[starttime]) ?>
<?php } ?>&nbsp;
<?=$value['membernum']?> 人参加 /
<?=$value['follownum']?> 人关注
</p>
<p>
<?php if($value['threadnum']) { ?>
<a href="space.php?do=event&id=<?=$value['eventid']?>&view=thread">
<?=$value['threadnum']?> 个话题
</a> &nbsp;
<?php } ?>
<?php if($value['picnum']) { ?>
<a href="space.php?do=event&id=<?=$value['eventid']?>&view=pic">
<?=$value['picnum']?> 张照片
</a>
<?php } ?>
</p>
</li>
<?php } } ?>
</ul>
</div>
<?php } ?>
</div>

<script type="text/javascript">
//彩虹炫
var elems = selector('div[class~=magicflicker]'); 
for(var i=0; i<elems.length; i++){
magicColor(elems[i]);
}	
</script>

<?php } ?>
</div></div>
﻿<?php if(empty($_SGLOBAL['inajax'])) { ?>
<?php if(empty($_TPL['nosidebar'])) { ?>
<?php if($_SGLOBAL['ad']['contentbottom']) { ?><br style="line-height:0;clear:both;"/><div id="ad_contentbottom"><?php adshow('contentbottom'); ?></div><?php } ?>
</div>

<!--/mainarea-->
<div id="bottom"></div>
</div>
<!--/main-->
<?php } ?>

<div id="footer">

<p class="r_option">
<a href="javascript:;" onclick="window.scrollTo(0,0);" id="a_top" title="TOP"><img src="image/top.gif" alt="" style="padding: 5px 6px 6px;" /></a>
</p>

<?php if($_SGLOBAL['ad']['footer']) { ?>
<p style="padding:5px 0 10px 0;"><?php adshow('footer'); ?></p>
<?php } ?>

<?php if($_SCONFIG['close']) { ?>
<p style="color:blue;font-weight:bold;">
提醒：当前站点处于关闭状态
</p>
<?php } ?>
<p>
<?=$_SCONFIG['sitename']?> - 
<a href="mailto:<?=$_SCONFIG['adminemail']?>">联系我们</a>
<?php if($_SCONFIG['miibeian']) { ?> - <a  href="http://www.miibeian.gov.cn" target="_blank"><?=$_SCONFIG['miibeian']?></a><?php } ?>
</p>
<p>
Powered by <a  href="http://u.discuz.net" target="_blank"><strong>UCenter Home</strong></a> <span title="<?php echo X_RELEASE; ?>"><?php echo X_VER; ?></span>
<?php if(!empty($_SCONFIG['licensed'])) { ?><a  href="http://license.comsenz.com/?pid=7&host=<?=$_SERVER['HTTP_HOST']?>" target="_blank">Licensed</a><?php } ?>
&copy; 2001-2011 <a  href="http://www.comsenz.com" target="_blank">Comsenz Inc.</a>
</p>
<?php if($_SCONFIG['debuginfo']) { ?>
<p><?php echo debuginfo(); ?></p>
<?php } ?>
</div>
</div>
<!--/wrap-->

<?php if($_SGLOBAL['appmenu']) { ?>
<ul id="ucappmenu_menu" class="dropmenu_drop" style="display:none;">
<li><a href="<?=$_SGLOBAL['appmenu']['url']?>" title="<?=$_SGLOBAL['appmenu']['name']?>" target="_blank"><?=$_SGLOBAL['appmenu']['name']?></a></li>
<?php if(is_array($_SGLOBAL['appmenus'])) { foreach($_SGLOBAL['appmenus'] as $value) { ?>
<li><a href="<?=$value['url']?>" title="<?=$value['name']?>" target="_blank"><?=$value['name']?></a></li>
<?php } } ?>
</ul>
<?php } ?>


<?php if($_SGLOBAL['supe_uid']) { ?>
<?php if(!isset($_SCOOKIE['checkpm'])) { ?>
<script language="javascript"  type="text/javascript" src="cp.php?ac=pm&op=checknewpm&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>
<?php if(!isset($_SCOOKIE['synfriend'])) { ?>
<script language="javascript"  type="text/javascript" src="cp.php?ac=friend&op=syn&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>
<?php } ?>
<?php if(!isset($_SCOOKIE['sendmail'])) { ?>
<script language="javascript"  type="text/javascript" src="do.php?ac=sendmail&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>

<?php if($_SGLOBAL['ad']['couplet']) { ?>
<script language="javascript" type="text/javascript" src="source/script_couplet.js"></script>
<div id="uch_couplet" style="z-index: 10; position: absolute; display:none">
<div id="couplet_left" style="position: absolute; left: 2px; top: 60px; overflow: hidden;">
<div style="position: relative; top: 25px; margin:0.5em;" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('uch_couplet');"><img src="image/advclose.gif"></div>
<?php adshow('couplet'); ?>
</div>
<div id="couplet_rigth" style="position: absolute; right: 2px; top: 60px; overflow: hidden;">
<div style="position: relative; top: 25px; margin:0.5em;" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('uch_couplet');"><img src="image/advclose.gif"></div>
<?php adshow('couplet'); ?>
</div>
<script type="text/javascript">
lsfloatdiv('uch_couplet', 0, 0, '', 0).floatIt();
</script>
</div>
<?php } ?>
<?php if($_SCOOKIE['reward_log']) { ?>
<script type="text/javascript">
showreward();
</script>
<?php } ?>
</body>
</html>
<?php } ?><?php ob_out();?>