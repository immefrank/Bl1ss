<?php if(!defined('IN_UCHOME')) exit('Access Denied');?><?php subtplcheck('arts/tpl/view|template/default/header|template/default/footer', '1303322069', 'arts/tpl/view');?><?php $_TPL['titles'] = array($con[artsname]); ?>
<?php $_TPL['nosidebar']=1; ?>
﻿<?php if(empty($_SGLOBAL['inajax'])) { ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=<?=$_SC['charset']?>" />
<meta http-equiv="x-ua-compatible" content="ie=7" />
<title><?php if($_TPL['titles']) { ?><?php if(is_array($_TPL['titles'])) { foreach($_TPL['titles'] as $value) { ?><?php if($value) { ?><?=$value?> - <?php } ?><?php } } ?><?php } ?><?php if($_SN[$space['uid']]) { ?><?=$_SN[$space['uid']]?> - <?php } ?><?=$_SCONFIG['sitename']?></title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<script language="javascript" type="text/javascript" src="source/script_jquery.js"></script>
<script language="javascript" type="text/javascript" src="source/script_cookie.js"></script>
<script language="javascript" type="text/javascript" src="source/script_common.js"></script>
<script language="javascript" type="text/javascript" src="source/script_menu.js"></script>
<script language="javascript" type="text/javascript" src="source/script_ajax.js"></script>
<script language="javascript" type="text/javascript" src="source/script_face.js"></script>
<script language="javascript" type="text/javascript" src="source/script_manage.js"></script>
<link id="skinc" href="/template/default/style.css" rel="stylesheet" type="text/css" />
<?php if($_TPL['css']) { ?>
<link id="skinc" href="/template/default/<?=$_TPL['css']?>.css" rel="stylesheet" type="text/css" />
<?php } ?>
<?php if(!empty($_SGLOBAL['space_theme'])) { ?>
<link id="skinc" href="/theme/<?=$_SGLOBAL['space_theme']?>/style.css" rel="stylesheet" type="text/css" />
<?php } elseif($_SCONFIG['template'] != 'default') { ?>
<link id="skinc" href="/template/<?=$_SCONFIG['template']?>/style.css" rel="stylesheet" type="text/css" />
<?php } ?>

<style type="text/css">
<?php if(!empty($_SGLOBAL['space_css'])) { ?>
<?=$_SGLOBAL['space_css']?> 
<?php } ?>
</style>
<link rel="shortcut icon" href="image/favicon.ico" />
<link rel="edituri" type="application/rsd+xml" title="rsd" href="xmlrpc.php?rsd=<?=$space['uid']?>" />

</head>
<body>
<div id="append_parent"></div>
<div id="ajaxwaitid"></div>
<div id="header">
<div class="wp">
<div id="logo"></div>

<div id="nav">
<div>
<?php if($_SGLOBAL['supe_uid']) { ?>
<a href="space.php">myspace</a>
<a href="cp.php?ac=common&op=logout&uhash=<?=$_SGLOBAL['uhash']?>">logout</a>
<?php } else { ?>
<a href="do.php?ac=<?=$_SCONFIG['login_action']?>">Share</a> | 
<a href="do.php?ac=<?=$_SCONFIG['login_action']?>">Login</a> | 
<a href="do.php?ac=<?=$_SCONFIG['register_action']?>">Register</a>
<?php } ?>
</div>
<div id="navitem">
<a href="network.php"><img src="/template/default/i/nav_home.jpg" /></a>
<a href="space.php?act=home&view=all"><img src="/template/default/i/nav_comm.jpg" /></a>
<a href="books.php"><img src="/template/default/i/nav_books.jpg" /></a>
<a href="movies.php"><img src="/template/default/i/nav_mov.jpg" /></a>
<a href="music.php"><img src="/template/default/i/nav_mus.jpg" /></a>
<a href="arts.php"><img src="/template/default/i/nav_art.jpg" /></a>
</div>
</div>
<div class="cl"></div>
</div>
</div>

<div id="wrap">

<?php if(empty($_TPL['nosidebar'])) { ?>
<div id="main">
<div id="app_sidebar">
<?php if($_SGLOBAL['supe_uid']) { ?>
    <h2>Personal Center</h2>
<ul class="app_list" id="default_userapp">
<li><a href="space.php?do=doing"><span class="icon i-app24 i-app24-status"></span>Fresh things</a></li>
<li><a href="space.php?do=album"><span class="icon i-app24 i-app24-album"></span>Albums</a><em><a href="cp.php?ac=upload" class="gray">upload</a></em></li>
<li><a href="space.php?do=blog"><span class="icon i-app24 i-app24-blog"></span>WebLog</a><em><a href="cp.php?ac=blog" class="gray">issue</a></em></li>
</ul>

            <h2>互动中心</h2>
<ul class="app_list" id="default_userapp">
<li><a href="space.php?do=poll"><span class="icon i-app24 i-app24-vote"></span>投票</a><em><a href="cp.php?ac=poll" class="gray">发起</a></em></li>
<li><a href="space.php?do=mtag"><span class="icon i-app24 i-app24-thread"></span>群组</a><em><a href="cp.php?ac=thread" class="gray">话题</a></em></li>
<li><a href="space.php?do=event"><span class="icon i-app24 i-app24-event"></span>活动</a><em><a href="cp.php?ac=event" class="gray">发起</a></em></li>
<li><a href="space.php?do=share"><span class="icon i-app24 i-app24-share"></span>分享</a></li>
<li><a href="space.php?do=topic"><span class="icon i-app24 i-app24-hot"></span>专题</a></li>
</ul>

           

<div id="appbarActions">
<?php if($_SCONFIG['my_status']) { ?><a class="act a-manage" href="cp.php?ac=userapp&op=menu" >设置</a>&nbsp;<?php } ?><?php if($_SGLOBAL['my_menu_more']) { ?><a href="javascript:;" id="a_app_more" onclick="userapp_open();" class="off">展开</a><?php } ?>
            </div>

<?php } else { ?>
<div class="bar_text">
<form id="loginform" name="loginform" action="do.php?ac=<?=$_SCONFIG['login_action']?>&ref" method="post">
<input type="hidden" name="formhash" value="<?php echo formhash(); ?>" />
<p><h2>登陆更精彩...</h2></p>
<p>账号:</p>
<p><input type="text" name="username" id="username" class="t_input" size="15" value="" /></p>
<p>密码:</p>
<p><input type="password" name="password" id="password" class="t_input" size="15" value="" /></p>
<p ><input type="checkbox" id="cookietime" name="cookietime" value="315360000" checked /><label for="cookietime">记住我</label></p>
<p>
<input type="submit" id="loginsubmit" name="loginsubmit" value="登录" class="submit" />
<input type="button" name="regbutton" value="注册" class="button" onclick="urlto('do.php?ac=<?=$_SCONFIG['register_action']?>');">
</p>
</form>

</div>
<?php } ?>
</div>

<div id="mainarea">

<?php if($_SGLOBAL['ad']['contenttop']) { ?><div id="ad_contenttop"><?php adshow('contenttop'); ?></div><?php } ?>
<?php } ?>

<?php } ?>

<script type="text/javascript" language="javascript" src="/script/comment.js"></script>
<script type="text/javascript" language="javascript">
function modelLike(id,tp)
{
jQ.get('/plus/modellike.php',{
idtype:tp,
id:id,
act:'add'
},function(data){
if(data == 'ok')
{
jQ("#butlike_"+id).val('u like this').attr('disabled','disabled');
}
})

}
function shownewcommentlist()
{
jQ.get("/comment.php?do=list",{
id:<?=$con['id']?>,
idtype:'artsid',
by:'new',
ajax:1,
t:Math.random()
},function(data){
jQ("#commentList").html(data);
});
}
function showfcommentlist()
{
jQ.get("/comment.php?do=list",{
id:<?=$con['id']?>,
idtype:'artsid',
by:'new',
xhp:true,
ajax:1,
t:Math.random()
},function(data){
jQ("#commentList").html(data);
});
}
function showhotcommentlist()
{
jQ.get("/comment.php?do=list",{
id:<?=$con['id']?>,
idtype:'artsid',
by:'like',
ajax:1,
t:Math.random()
},function(data){
jQ("#commentList").html(data);
});
}
jQ(document).ready(function(){
showhotcommentlist()
getmystate(<?=$con['id']?>,'artsid');
})
</script>
<div class="bgc" id="Navigation">Location &gt;<a href="/">Home</a> &gt;<a href="Arts.php">Arts</a> &gt;Item</div>
<div id="body">
<div id="bodyleft">
<div>
<h1 id="itemname"><?=$con['artname']?></h1>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="150">
<img src="<?=$con['pic']?>" width="100"/>
</td>
    <td>
<ul>
<li>author:<?=$con['author']?></li>
<li>owner:<?=$con['whohave']?></li>
<li>type:<?=$con['sect']?></li>
<li>dateline:<?=$con['addtime']?></li>
<li>money:<?=$con['money']?></li>
</ul>
</td>
    <td valign="top">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="72"><strong>平均评分：</strong></td>
    <td width="120"><span id="pjpf" class="start<?=$pf['num']?>" ></span></td>
    <td><font color="#FF0000" id="pjfs"><?=$pf['pjf']?></font>分 <?=$pf['rs']?>人参与</td>
  </tr>
</table>
</td>
  </tr>
  <tr>
    <td colspan="3"><span id="nowmystate">
   <a href="javascript:;" onclick="mystate('want','artsid',<?=$con['id']?>)">想听</a>&nbsp;&nbsp;<a href="javascript:;" onclick="mystate('over','artsid',<?=$con['id']?>)">听过</a></span>
       评分：<div id="pingfen">
      <a name="star1[]" title="差" onmouseover="star_onmouse_over(this.name,1,'show_msg')" onmouseout="star_onmouse_out(this.name,'score','show_msg')" onclick="star_onclick(<?=$con['id']?>,1,'artsid')"></a>
      <a name="star1[]" title="一般" onmouseover="star_onmouse_over(this.name,2,'show_msg')" onmouseout="star_onmouse_out(this.name,'score','show_msg')" onclick="star_onclick(<?=$con['id']?>,2,'artsid')"></a>
      <a name="star1[]" title="好" onmouseover="star_onmouse_over(this.name,3,'show_msg')" onmouseout="star_onmouse_out(this.name,'score','show_msg')" onclick="star_onclick(<?=$con['id']?>,3,'artsid')"></a>
      <a name="star1[]" title="很好" onmouseover="star_onmouse_over(this.name,4,'show_msg')" onmouseout="star_onmouse_out(this.name,'score','show_msg')" onclick="star_onclick(<?=$con['id']?>,4,'artsid')"></a>
      <a name="star1[]" title="非常好" onmouseover="star_onmouse_over(this.name,5,'show_msg')" onmouseout="star_onmouse_out(this.name,'score','show_msg')" onclick="star_onclick(<?=$con['id']?>,5,'artsid')"></a>
   <span id="show_msg"><font color="red">欢迎评分</font></span><input id="score" name="score" type="hidden" value="0"></div></td>
    </tr>
  <tr>
    <td colspan="3"><a href="comment.php?idtype=artsid&id=<?=$con['id']?>">Write My Comment</a>    <a href="#">like</a>   <a href="#">Share</a>  </td>
    </tr>
</table>

</div>
<div class="btitle">Art Summary</div>
<div>
<?php if(strlen($con['summary']) > 580) { ?>
<pre id="happtext_<?=$con['id']?>" style="display:none"><?=$con['summary']?></pre>
<pre id="sapptext_<?=$con['id']?>"><?php echo getstr($con['summary'], 580, 0, 0, 0, 0, -1) ?>..<a href="javascript:;" onclick="showtext('happtext_<?=$con['id']?>','sapptext_<?=$con['id']?>')">[Show All]</a></pre>
<?php } else { ?>
<pre>
<?=$con['summary']?>
</pre>
<?php } ?>
</div>
<div class="btitle">Author Summary</div>
<div>
<?php if(strlen($con['authortext']) > 580) { ?>
<pre id="hahtext_<?=$con['id']?>" style="display:none"><?=$con['authortext']?></pre>
<pre id="sahtext_<?=$con['id']?>"><?php echo getstr($con['authortext'], 580, 0, 0, 0, 0, -1) ?>..<a href="javascript:;" onclick="showtext('hahtext_<?=$con['id']?>','sahtext_<?=$con['id']?>')">[Show All]</a></pre>
<?php } else { ?>
<pre>
<?=$con['summary']?>
</pre>
<?php } ?>
</div>
<div class="btitle">Like "<?=$con['artsname']?>" and like....</div>
<div class="btitle">Art Comment  <span class="mylink" > <a href="comment.php?idtype=artsid&id=<?=$con['id']?>">Write My Comment</a></span></div>
 <div id="commentList" class="commentList cl" style="padding:10px 0;">
</div>
 <a href="comment.php?do=list&id=<?=$con['id']?>&idtype=booksid">ALL Comments &gt; &gt;</a>
</div>
<div id="bodyright">
<div class="btitle">Where sell "<?=$con['artsname']?>"?</div>
<div class="btitle">Who heard this arts?</div>
<ul>
<?php if(is_array($whoover)) { foreach($whoover as $v) { ?>
<li>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="60" rowspan="2"><a href="space.php?uid=<?=$v['uid']?>"><?=$v['avatar']?></a></td>
    <td><a href="space.php?uid=<?=$v['uid']?>"><?=$v['username']?></a></td>
  </tr>
  <tr>
    <td> <?php echo sgmdate('m-d H:i',$v[dateline],1); ?></td>
  </tr>
</table>
</li>
<?php } } ?>
</ul>
<div class="btitle">artsians and other arts</div>
<div style="padding:10px 0">

</div>
<a class="mylink" href="arts.php?do=create">arts publishing applications</a>
</div>
</div>
﻿<?php if(empty($_SGLOBAL['inajax'])) { ?>
<?php if(empty($_TPL['nosidebar'])) { ?>
<?php if($_SGLOBAL['ad']['contentbottom']) { ?><br style="line-height:0;clear:both;"/><div id="ad_contentbottom"><?php adshow('contentbottom'); ?></div><?php } ?>
</div>

<!--/mainarea-->
<div id="bottom"></div>
</div>
<!--/main-->
<?php } ?>

<div id="footer">

<p class="r_option">
<a href="javascript:;" onclick="window.scrollTo(0,0);" id="a_top" title="TOP"><img src="image/top.gif" alt="" style="padding: 5px 6px 6px;" /></a>
</p>

<?php if($_SGLOBAL['ad']['footer']) { ?>
<p style="padding:5px 0 10px 0;"><?php adshow('footer'); ?></p>
<?php } ?>

<?php if($_SCONFIG['close']) { ?>
<p style="color:blue;font-weight:bold;">
提醒：当前站点处于关闭状态
</p>
<?php } ?>
<p>
<?=$_SCONFIG['sitename']?> - 
<a href="mailto:<?=$_SCONFIG['adminemail']?>">联系我们</a>
<?php if($_SCONFIG['miibeian']) { ?> - <a  href="http://www.miibeian.gov.cn" target="_blank"><?=$_SCONFIG['miibeian']?></a><?php } ?>
</p>
<p>
Powered by <a  href="http://u.discuz.net" target="_blank"><strong>UCenter Home</strong></a> <span title="<?php echo X_RELEASE; ?>"><?php echo X_VER; ?></span>
<?php if(!empty($_SCONFIG['licensed'])) { ?><a  href="http://license.comsenz.com/?pid=7&host=<?=$_SERVER['HTTP_HOST']?>" target="_blank">Licensed</a><?php } ?>
&copy; 2001-2011 <a  href="http://www.comsenz.com" target="_blank">Comsenz Inc.</a>
</p>
<?php if($_SCONFIG['debuginfo']) { ?>
<p><?php echo debuginfo(); ?></p>
<?php } ?>
</div>
</div>
<!--/wrap-->

<?php if($_SGLOBAL['appmenu']) { ?>
<ul id="ucappmenu_menu" class="dropmenu_drop" style="display:none;">
<li><a href="<?=$_SGLOBAL['appmenu']['url']?>" title="<?=$_SGLOBAL['appmenu']['name']?>" target="_blank"><?=$_SGLOBAL['appmenu']['name']?></a></li>
<?php if(is_array($_SGLOBAL['appmenus'])) { foreach($_SGLOBAL['appmenus'] as $value) { ?>
<li><a href="<?=$value['url']?>" title="<?=$value['name']?>" target="_blank"><?=$value['name']?></a></li>
<?php } } ?>
</ul>
<?php } ?>


<?php if($_SGLOBAL['supe_uid']) { ?>
<?php if(!isset($_SCOOKIE['checkpm'])) { ?>
<script language="javascript"  type="text/javascript" src="cp.php?ac=pm&op=checknewpm&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>
<?php if(!isset($_SCOOKIE['synfriend'])) { ?>
<script language="javascript"  type="text/javascript" src="cp.php?ac=friend&op=syn&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>
<?php } ?>
<?php if(!isset($_SCOOKIE['sendmail'])) { ?>
<script language="javascript"  type="text/javascript" src="do.php?ac=sendmail&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>

<?php if($_SGLOBAL['ad']['couplet']) { ?>
<script language="javascript" type="text/javascript" src="source/script_couplet.js"></script>
<div id="uch_couplet" style="z-index: 10; position: absolute; display:none">
<div id="couplet_left" style="position: absolute; left: 2px; top: 60px; overflow: hidden;">
<div style="position: relative; top: 25px; margin:0.5em;" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('uch_couplet');"><img src="image/advclose.gif"></div>
<?php adshow('couplet'); ?>
</div>
<div id="couplet_rigth" style="position: absolute; right: 2px; top: 60px; overflow: hidden;">
<div style="position: relative; top: 25px; margin:0.5em;" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('uch_couplet');"><img src="image/advclose.gif"></div>
<?php adshow('couplet'); ?>
</div>
<script type="text/javascript">
lsfloatdiv('uch_couplet', 0, 0, '', 0).floatIt();
</script>
</div>
<?php } ?>
<?php if($_SCOOKIE['reward_log']) { ?>
<script type="text/javascript">
showreward();
</script>
<?php } ?>
</body>
</html>
<?php } ?><?php ob_out();?>