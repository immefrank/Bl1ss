<?php if(!defined('IN_UCHOME')) exit('Access Denied');?><?php subtplcheck('movies/tpl/create|template/default/header|template/default/footer', '1303270622', 'movies/tpl/create');?><?php $_TPL['titles'] = array('发布新电影'); ?>
<?php $_TPL['nosidebar']=1; ?>
﻿<?php if(empty($_SGLOBAL['inajax'])) { ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=<?=$_SC['charset']?>" />
<meta http-equiv="x-ua-compatible" content="ie=7" />
<title><?php if($_TPL['titles']) { ?><?php if(is_array($_TPL['titles'])) { foreach($_TPL['titles'] as $value) { ?><?php if($value) { ?><?=$value?> - <?php } ?><?php } } ?><?php } ?><?php if($_SN[$space['uid']]) { ?><?=$_SN[$space['uid']]?> - <?php } ?><?=$_SCONFIG['sitename']?></title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<script language="javascript" type="text/javascript" src="source/script_jquery.js"></script>
<script language="javascript" type="text/javascript" src="source/script_cookie.js"></script>
<script language="javascript" type="text/javascript" src="source/script_common.js"></script>
<script language="javascript" type="text/javascript" src="source/script_menu.js"></script>
<script language="javascript" type="text/javascript" src="source/script_ajax.js"></script>
<script language="javascript" type="text/javascript" src="source/script_face.js"></script>
<script language="javascript" type="text/javascript" src="source/script_manage.js"></script>
<link id="skinc" href="/template/default/style.css" rel="stylesheet" type="text/css" />
<?php if($_TPL['css']) { ?>
<link id="skinc" href="/template/default/<?=$_TPL['css']?>.css" rel="stylesheet" type="text/css" />
<?php } ?>
<?php if(!empty($_SGLOBAL['space_theme'])) { ?>
<link id="skinc" href="/theme/<?=$_SGLOBAL['space_theme']?>/style.css" rel="stylesheet" type="text/css" />
<?php } elseif($_SCONFIG['template'] != 'default') { ?>
<link id="skinc" href="/template/<?=$_SCONFIG['template']?>/style.css" rel="stylesheet" type="text/css" />
<?php } ?>

<style type="text/css">
<?php if(!empty($_SGLOBAL['space_css'])) { ?>
<?=$_SGLOBAL['space_css']?> 
<?php } ?>
</style>
<link rel="shortcut icon" href="image/favicon.ico" />
<link rel="edituri" type="application/rsd+xml" title="rsd" href="xmlrpc.php?rsd=<?=$space['uid']?>" />

</head>
<body>
<div id="append_parent"></div>
<div id="ajaxwaitid"></div>
<div id="header">
<div class="wp">
<div id="logo"></div>

<div id="nav">
<div>
<?php if($_SGLOBAL['supe_uid']) { ?>
<a href="space.php">myspace</a>
<a href="cp.php?ac=common&op=logout&uhash=<?=$_SGLOBAL['uhash']?>">logout</a>
<?php } else { ?>
<a href="do.php?ac=<?=$_SCONFIG['login_action']?>">Share</a> | 
<a href="do.php?ac=<?=$_SCONFIG['login_action']?>">Login</a> | 
<a href="do.php?ac=<?=$_SCONFIG['register_action']?>">Register</a>
<?php } ?>
</div>
<div id="navitem">
<a href="network.php"><img src="/template/default/i/nav_home.jpg" /></a>
<a href="space.php?act=home&view=all"><img src="/template/default/i/nav_comm.jpg" /></a>
<a href="books.php"><img src="/template/default/i/nav_books.jpg" /></a>
<a href="movies.php"><img src="/template/default/i/nav_mov.jpg" /></a>
<a href="music.php"><img src="/template/default/i/nav_mus.jpg" /></a>
<a href="arts.php"><img src="/template/default/i/nav_art.jpg" /></a>
</div>
</div>
<div class="cl"></div>
</div>
</div>

<div id="wrap">

<?php if(empty($_TPL['nosidebar'])) { ?>
<div id="main">
<div id="app_sidebar">
<?php if($_SGLOBAL['supe_uid']) { ?>
    <h2>Personal Center</h2>
<ul class="app_list" id="default_userapp">
<li><a href="space.php?do=doing"><span class="icon i-app24 i-app24-status"></span>Fresh things</a></li>
<li><a href="space.php?do=album"><span class="icon i-app24 i-app24-album"></span>Albums</a><em><a href="cp.php?ac=upload" class="gray">upload</a></em></li>
<li><a href="space.php?do=blog"><span class="icon i-app24 i-app24-blog"></span>WebLog</a><em><a href="cp.php?ac=blog" class="gray">issue</a></em></li>
</ul>

            <h2>互动中心</h2>
<ul class="app_list" id="default_userapp">
<li><a href="space.php?do=poll"><span class="icon i-app24 i-app24-vote"></span>投票</a><em><a href="cp.php?ac=poll" class="gray">发起</a></em></li>
<li><a href="space.php?do=mtag"><span class="icon i-app24 i-app24-thread"></span>群组</a><em><a href="cp.php?ac=thread" class="gray">话题</a></em></li>
<li><a href="space.php?do=event"><span class="icon i-app24 i-app24-event"></span>活动</a><em><a href="cp.php?ac=event" class="gray">发起</a></em></li>
<li><a href="space.php?do=share"><span class="icon i-app24 i-app24-share"></span>分享</a></li>
<li><a href="space.php?do=topic"><span class="icon i-app24 i-app24-hot"></span>专题</a></li>
</ul>

           

<div id="appbarActions">
<?php if($_SCONFIG['my_status']) { ?><a class="act a-manage" href="cp.php?ac=userapp&op=menu" >设置</a>&nbsp;<?php } ?><?php if($_SGLOBAL['my_menu_more']) { ?><a href="javascript:;" id="a_app_more" onclick="userapp_open();" class="off">展开</a><?php } ?>
            </div>

<?php } else { ?>
<div class="bar_text">
<form id="loginform" name="loginform" action="do.php?ac=<?=$_SCONFIG['login_action']?>&ref" method="post">
<input type="hidden" name="formhash" value="<?php echo formhash(); ?>" />
<p><h2>登陆更精彩...</h2></p>
<p>账号:</p>
<p><input type="text" name="username" id="username" class="t_input" size="15" value="" /></p>
<p>密码:</p>
<p><input type="password" name="password" id="password" class="t_input" size="15" value="" /></p>
<p ><input type="checkbox" id="cookietime" name="cookietime" value="315360000" checked /><label for="cookietime">记住我</label></p>
<p>
<input type="submit" id="loginsubmit" name="loginsubmit" value="登录" class="submit" />
<input type="button" name="regbutton" value="注册" class="button" onclick="urlto('do.php?ac=<?=$_SCONFIG['register_action']?>');">
</p>
</form>

</div>
<?php } ?>
</div>

<div id="mainarea">

<?php if($_SGLOBAL['ad']['contenttop']) { ?><div id="ad_contenttop"><?php adshow('contenttop'); ?></div><?php } ?>
<?php } ?>

<?php } ?>



<div id="body">
<div id="bodyleft">
<div class="Msgtitle">发布新电影</div>
<div class="CreateForm">
<form action="movies.php?do=create" method="post" enctype="multipart/form-data" >

<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="120" class="llab">电影名称</td>
    <td><input type="text" name="info[videoname]" id="videoname" class="common_input"style="width:200px;" /><span id="connamemsg"></span></td>
  </tr>
  <tr>
    <td class="llab">影片类别</td>
    <td><input type="checkbox" name="typeid" value="1" />科幻&nbsp;&nbsp;<input name="typeid" type="checkbox" value="2" />恐怖&nbsp;&nbsp;<input name="typeid" type="checkbox"value="3" />搞笑&nbsp;&nbsp;<inputname="typeid" type="checkbox" value="4" />悬疑&nbsp;&nbsp;<input name="typeid" type="checkbox" value="5" />纪录片&nbsp;&nbsp;<input type="checkbox" name="typeid" value="6" />爱情&nbsp;&nbsp;<input name="typeid" type="checkbox" value="7" />战争</td>
  </tr>
  <tr>
    <td class="llab">电影海报封面</td>
    <td>
<input type="file" class="t_input" name="upimgfile" size="50" />
</td>
  </tr>
  <tr>
    <td class="llab">导演</td>
    <td><input type="text" name="info[director]" id="tag" class="common_input" style="width:200px;" /></td>
  </tr>
  <tr>
    <td class="llab">编剧</td>
    <td><input type="text" name="info[screenwriter]" id="tag" class="common_input" style="width:200px;" />(使用,分隔)</td>
  </tr>
  <tr>
    <td class="llab">主演</td>
    <td><input type="text" name="info[starring]" id="tag" class="common_input" style="width:400px;" />(使用,分隔)</td>
  </tr>
 
  <tr>
    <td class="llab">上映时间</td>
    <td><input type="text" name="info[playtime]" id="update" class="common_input" style="width:200px;" /></td>
  </tr>
  <tr>
    <td class="llab">制片国家</td>
    <td><input type="text" name="info[fromnation]" id="tag" class="common_input" style="width:200px;" /></td>
  </tr>
  <tr>
    <td class="llab">影片语言</td>
    <td><select name="lang">
<option value="中文">中文</option>
<option value="英语">英语</option>
<option value="法语">法语</option>
<option value="德语">德语</option>
</select></td>
  </tr>
  <tr>
    <td class="llab">剧情简介</td>
    <td><textarea name="info[summary]" id="summary" class="common_input" style="width:400px; height:80px;"></textarea></td>
  </tr>
  <tr>
    <td class="llab">推荐理由</td>
    <td><textarea name="info[whygroom]" id="summary" class="common_input" style="width:400px; height:80px;"></textarea></td>
  </tr>
   <tr>
    <td class="llab">标签</td>
    <td><input type="text" name="info[tag]" id="tag" class="common_input" style="width:200px;" />(使用,分隔)</td>
  </tr>
</table>

<input type="hidden" name="consubmit" value="true" />
<input type="hidden" name="formhash" value="<?php echo formhash(); ?>" />
<div style="text-align:center;">
<input type="submit" value="提交影片" /> <input type="button" value="取消" onclick="javascript:history.go(-1);" />
</div>
</form>
</div>
</div>
<div id="bodyright">
<div class="mytitle">发布新电影说明..</div>
发布新电影需要审核，请耐心等待
<br />
<a href="books.php">返回电影首页</a><br />

</div>
<div class="cl"></div>
</div>
﻿<?php if(empty($_SGLOBAL['inajax'])) { ?>
<?php if(empty($_TPL['nosidebar'])) { ?>
<?php if($_SGLOBAL['ad']['contentbottom']) { ?><br style="line-height:0;clear:both;"/><div id="ad_contentbottom"><?php adshow('contentbottom'); ?></div><?php } ?>
</div>

<!--/mainarea-->
<div id="bottom"></div>
</div>
<!--/main-->
<?php } ?>

<div id="footer">

<p class="r_option">
<a href="javascript:;" onclick="window.scrollTo(0,0);" id="a_top" title="TOP"><img src="image/top.gif" alt="" style="padding: 5px 6px 6px;" /></a>
</p>

<?php if($_SGLOBAL['ad']['footer']) { ?>
<p style="padding:5px 0 10px 0;"><?php adshow('footer'); ?></p>
<?php } ?>

<?php if($_SCONFIG['close']) { ?>
<p style="color:blue;font-weight:bold;">
提醒：当前站点处于关闭状态
</p>
<?php } ?>
<p>
<?=$_SCONFIG['sitename']?> - 
<a href="mailto:<?=$_SCONFIG['adminemail']?>">联系我们</a>
<?php if($_SCONFIG['miibeian']) { ?> - <a  href="http://www.miibeian.gov.cn" target="_blank"><?=$_SCONFIG['miibeian']?></a><?php } ?>
</p>
<p>
Powered by <a  href="http://u.discuz.net" target="_blank"><strong>UCenter Home</strong></a> <span title="<?php echo X_RELEASE; ?>"><?php echo X_VER; ?></span>
<?php if(!empty($_SCONFIG['licensed'])) { ?><a  href="http://license.comsenz.com/?pid=7&host=<?=$_SERVER['HTTP_HOST']?>" target="_blank">Licensed</a><?php } ?>
&copy; 2001-2011 <a  href="http://www.comsenz.com" target="_blank">Comsenz Inc.</a>
</p>
<?php if($_SCONFIG['debuginfo']) { ?>
<p><?php echo debuginfo(); ?></p>
<?php } ?>
</div>
</div>
<!--/wrap-->

<?php if($_SGLOBAL['appmenu']) { ?>
<ul id="ucappmenu_menu" class="dropmenu_drop" style="display:none;">
<li><a href="<?=$_SGLOBAL['appmenu']['url']?>" title="<?=$_SGLOBAL['appmenu']['name']?>" target="_blank"><?=$_SGLOBAL['appmenu']['name']?></a></li>
<?php if(is_array($_SGLOBAL['appmenus'])) { foreach($_SGLOBAL['appmenus'] as $value) { ?>
<li><a href="<?=$value['url']?>" title="<?=$value['name']?>" target="_blank"><?=$value['name']?></a></li>
<?php } } ?>
</ul>
<?php } ?>


<?php if($_SGLOBAL['supe_uid']) { ?>
<?php if(!isset($_SCOOKIE['checkpm'])) { ?>
<script language="javascript"  type="text/javascript" src="cp.php?ac=pm&op=checknewpm&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>
<?php if(!isset($_SCOOKIE['synfriend'])) { ?>
<script language="javascript"  type="text/javascript" src="cp.php?ac=friend&op=syn&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>
<?php } ?>
<?php if(!isset($_SCOOKIE['sendmail'])) { ?>
<script language="javascript"  type="text/javascript" src="do.php?ac=sendmail&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>

<?php if($_SGLOBAL['ad']['couplet']) { ?>
<script language="javascript" type="text/javascript" src="source/script_couplet.js"></script>
<div id="uch_couplet" style="z-index: 10; position: absolute; display:none">
<div id="couplet_left" style="position: absolute; left: 2px; top: 60px; overflow: hidden;">
<div style="position: relative; top: 25px; margin:0.5em;" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('uch_couplet');"><img src="image/advclose.gif"></div>
<?php adshow('couplet'); ?>
</div>
<div id="couplet_rigth" style="position: absolute; right: 2px; top: 60px; overflow: hidden;">
<div style="position: relative; top: 25px; margin:0.5em;" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('uch_couplet');"><img src="image/advclose.gif"></div>
<?php adshow('couplet'); ?>
</div>
<script type="text/javascript">
lsfloatdiv('uch_couplet', 0, 0, '', 0).floatIt();
</script>
</div>
<?php } ?>
<?php if($_SCOOKIE['reward_log']) { ?>
<script type="text/javascript">
showreward();
</script>
<?php } ?>
</body>
</html>
<?php } ?><?php ob_out();?>