<?php if(!defined('IN_UCHOME')) exit('Access Denied');?><?php subtplcheck('template/default/space_doing|template/default/header|template/default/space_doing_li|template/default/space_menu|template/default/space_doing_form|template/default/space_mydoing_li|template/default/footer', '1303301998', 'template/default/space_doing');?>﻿<?php $_TPL['titles'] = array('记录'); ?>
﻿<?php if(empty($_SGLOBAL['inajax'])) { ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=<?=$_SC['charset']?>" />
<meta http-equiv="x-ua-compatible" content="ie=7" />
<title><?php if($_TPL['titles']) { ?><?php if(is_array($_TPL['titles'])) { foreach($_TPL['titles'] as $value) { ?><?php if($value) { ?><?=$value?> - <?php } ?><?php } } ?><?php } ?><?php if($_SN[$space['uid']]) { ?><?=$_SN[$space['uid']]?> - <?php } ?><?=$_SCONFIG['sitename']?></title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<script language="javascript" type="text/javascript" src="source/script_jquery.js"></script>
<script language="javascript" type="text/javascript" src="source/script_cookie.js"></script>
<script language="javascript" type="text/javascript" src="source/script_common.js"></script>
<script language="javascript" type="text/javascript" src="source/script_menu.js"></script>
<script language="javascript" type="text/javascript" src="source/script_ajax.js"></script>
<script language="javascript" type="text/javascript" src="source/script_face.js"></script>
<script language="javascript" type="text/javascript" src="source/script_manage.js"></script>
<link id="skinc" href="/template/default/style.css" rel="stylesheet" type="text/css" />
<?php if($_TPL['css']) { ?>
<link id="skinc" href="/template/default/<?=$_TPL['css']?>.css" rel="stylesheet" type="text/css" />
<?php } ?>
<?php if(!empty($_SGLOBAL['space_theme'])) { ?>
<link id="skinc" href="/theme/<?=$_SGLOBAL['space_theme']?>/style.css" rel="stylesheet" type="text/css" />
<?php } elseif($_SCONFIG['template'] != 'default') { ?>
<link id="skinc" href="/template/<?=$_SCONFIG['template']?>/style.css" rel="stylesheet" type="text/css" />
<?php } ?>

<style type="text/css">
<?php if(!empty($_SGLOBAL['space_css'])) { ?>
<?=$_SGLOBAL['space_css']?> 
<?php } ?>
</style>
<link rel="shortcut icon" href="image/favicon.ico" />
<link rel="edituri" type="application/rsd+xml" title="rsd" href="xmlrpc.php?rsd=<?=$space['uid']?>" />

</head>
<body>
<div id="append_parent"></div>
<div id="ajaxwaitid"></div>
<div id="header">
<div class="wp">
<div id="logo"></div>

<div id="nav">
<div>
<?php if($_SGLOBAL['supe_uid']) { ?>
<a href="space.php">myspace</a>
<a href="cp.php?ac=common&op=logout&uhash=<?=$_SGLOBAL['uhash']?>">logout</a>
<?php } else { ?>
<a href="do.php?ac=<?=$_SCONFIG['login_action']?>">Share</a> | 
<a href="do.php?ac=<?=$_SCONFIG['login_action']?>">Login</a> | 
<a href="do.php?ac=<?=$_SCONFIG['register_action']?>">Register</a>
<?php } ?>
</div>
<div id="navitem">
<a href="network.php"><img src="/template/default/i/nav_home.jpg" /></a>
<a href="space.php?act=home&view=all"><img src="/template/default/i/nav_comm.jpg" /></a>
<a href="books.php"><img src="/template/default/i/nav_books.jpg" /></a>
<a href="movies.php"><img src="/template/default/i/nav_mov.jpg" /></a>
<a href="music.php"><img src="/template/default/i/nav_mus.jpg" /></a>
<a href="arts.php"><img src="/template/default/i/nav_art.jpg" /></a>
</div>
</div>
<div class="cl"></div>
</div>
</div>

<div id="wrap">

<?php if(empty($_TPL['nosidebar'])) { ?>
<div id="main">
<div id="app_sidebar">
<?php if($_SGLOBAL['supe_uid']) { ?>
    <h2>Personal Center</h2>
<ul class="app_list" id="default_userapp">
<li><a href="space.php?do=doing"><span class="icon i-app24 i-app24-status"></span>Fresh things</a></li>
<li><a href="space.php?do=album"><span class="icon i-app24 i-app24-album"></span>Albums</a><em><a href="cp.php?ac=upload" class="gray">upload</a></em></li>
<li><a href="space.php?do=blog"><span class="icon i-app24 i-app24-blog"></span>WebLog</a><em><a href="cp.php?ac=blog" class="gray">issue</a></em></li>
</ul>

            <h2>互动中心</h2>
<ul class="app_list" id="default_userapp">
<li><a href="space.php?do=poll"><span class="icon i-app24 i-app24-vote"></span>投票</a><em><a href="cp.php?ac=poll" class="gray">发起</a></em></li>
<li><a href="space.php?do=mtag"><span class="icon i-app24 i-app24-thread"></span>群组</a><em><a href="cp.php?ac=thread" class="gray">话题</a></em></li>
<li><a href="space.php?do=event"><span class="icon i-app24 i-app24-event"></span>活动</a><em><a href="cp.php?ac=event" class="gray">发起</a></em></li>
<li><a href="space.php?do=share"><span class="icon i-app24 i-app24-share"></span>分享</a></li>
<li><a href="space.php?do=topic"><span class="icon i-app24 i-app24-hot"></span>专题</a></li>
</ul>

           

<div id="appbarActions">
<?php if($_SCONFIG['my_status']) { ?><a class="act a-manage" href="cp.php?ac=userapp&op=menu" >设置</a>&nbsp;<?php } ?><?php if($_SGLOBAL['my_menu_more']) { ?><a href="javascript:;" id="a_app_more" onclick="userapp_open();" class="off">展开</a><?php } ?>
            </div>

<?php } else { ?>
<div class="bar_text">
<form id="loginform" name="loginform" action="do.php?ac=<?=$_SCONFIG['login_action']?>&ref" method="post">
<input type="hidden" name="formhash" value="<?php echo formhash(); ?>" />
<p><h2>登陆更精彩...</h2></p>
<p>账号:</p>
<p><input type="text" name="username" id="username" class="t_input" size="15" value="" /></p>
<p>密码:</p>
<p><input type="password" name="password" id="password" class="t_input" size="15" value="" /></p>
<p ><input type="checkbox" id="cookietime" name="cookietime" value="315360000" checked /><label for="cookietime">记住我</label></p>
<p>
<input type="submit" id="loginsubmit" name="loginsubmit" value="登录" class="submit" />
<input type="button" name="regbutton" value="注册" class="button" onclick="urlto('do.php?ac=<?=$_SCONFIG['register_action']?>');">
</p>
</form>

</div>
<?php } ?>
</div>

<div id="mainarea">

<?php if($_SGLOBAL['ad']['contenttop']) { ?><div id="ad_contenttop"><?php adshow('contenttop'); ?></div><?php } ?>
<?php } ?>

<?php } ?>


<?php if(!empty($_SGLOBAL['inajax'])) { ?>
<div class="mod" id="space_doing">
<div class="mCt">
<div class="mHd">
<h3>一句话(共 <?=$count?> 条)</h3><?php if($space['self']) { ?><a href="space.php?do=doing&view=me" class="right">一句话</a><?php } ?>
</div>
<div class="mBd">
<?php if($dolist) { ?>
<div class="profileFeedWrap">
<div class="minifeed" id="storyListEl">
<ul class="feedList minifeedList">
<?php if(is_array($dolist)) { foreach($dolist as $dv) { ?>
<?php $doid = $dv[doid]; ?>
<li class="feedItem feedItem-main feed-<?=$value['icon']?> " id="dl<?=$doid?>" >   
<div class="feedIcon">
<span class="icon i-app-doing"></span>	
</div>
<div class="feedContent feedStyle-short">
<div class="feedHead">
<h4>
<span class="statusWord"><i><i><i><i> <?=$dv['message']?> </i></i></i></i></span>     
</h4>
</div>        
<div class="feedFoot">                
<a title="通过手机发布" class="icon i-wap" href="#" style="display:none"></a>
<span class="time"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span>  -   
<span class="action"><a href="javascript:;" onclick="docomment_form(<?=$doid?>, 0);">回复</a><?php if($dv['uid']==$_SGLOBAL['supe_uid']) { ?> - <a href="cp.php?ac=doing&op=delete&doid=<?=$doid?>&id=<?=$dv['id']?>" id="doing_delete_<?=$doid?>_<?=$dv['id']?>" onclick="ajaxmenu(event, this.id)" class="re gray">删除</a> <?php } ?></span> 
</div>
<?php $list = $clist[$doid]; ?>
<div class="feedComment" id="docomment_<?=$doid?>"<?php if(!$list) { ?> style="display:none;"<?php } ?>>
                            <div class="feedComment">              
                <div class="commentBox commentBox-small">
<span id="docomment_form_<?=$doid?>_0"></span>
﻿    <ul>
<?php if(is_array($list)) { foreach($list as $value) { ?>
    <?php if($value['uid']) { ?>
<li class="<?=$value['class']?>" style="<?=$value['style']?>">
<div class="commentAvatar">
<a href="space.php?uid=<?=$value['uid']?>" title="<?=$_SN[$value['uid']]?>"><span class="avatar-32"><?php echo avatar($value[uid],small); ?></span></a>
</div>
<div class="commentOption">
<?php if($value['uid']==$_SGLOBAL['supe_uid'] || $dv['uid']==$_SGLOBAL['supe_uid']) { ?><a href="cp.php?ac=doing&op=delete&doid=<?=$value['doid']?>&id=<?=$value['id']?>" id="doing_delete_<?=$value['doid']?>_<?=$value['id']?>" onclick="ajaxmenu(event, this.id)" class="icon i-del" title="删除">删除</a><?php } ?>
</div>
<div class="commentInfo">
<h4>
<a href="space.php?uid=<?=$value['uid']?>"><?=$_SN[$value['uid']]?></a> <span class="meta"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span>
<span class="meta">-</span> <a href="javascript:void(0)" onclick="docomment_form(<?=$value['doid']?>, <?=$value['id']?>);">回复</a>
</h4>
<p><?=$value['message']?></p>
</div>
<span style="display:none" id="docomment_form_<?=$value['doid']?>_<?=$value['id']?>"></span>
</li>
<?php } ?>
    <?php } } ?>
    </ul>

</div></div></div>
</div>
</li>
<?php } } ?>
</ul>
<div class="pager"><?=$multi?></div>
</div>
</div>
<?php } else { ?>
<div class="feedlistEmpty">现在还没有一句话</div>
<?php } ?>
</div>
</div>
</div>
<?php } else { ?>

<?php if($space['self']) { ?>
<div class="appHead">
    <h2><span class="icon i-app24 i-app24-status"></span>一句话</h2>
</div>

<div class="appBody"> 
<?php } else { ?>
<?php $_TPL['spacetitle'] = "一句话";
	$_TPL['spacemenus'][] = "<a href=\"space.php?uid=$space[uid]&do=doing&view=me\">TA的所有一句话</a>"; ?>
﻿<div class="c_header a_header">
<div class="avatar-48"><a href="space.php?uid=<?=$space['uid']?>"><?php echo avatar($space[uid],small); ?></a></div>
<?php if($_SGLOBAL['refer']) { ?>
<a class="r_option" href="<?=$_SGLOBAL['refer']?>">&laquo; 返回上一页</a>
<?php } ?>
<p style="font-size:14px"><?=$_SN[$space['uid']]?>的<?=$_TPL['spacetitle']?></p>
<a href="space.php?uid=<?=$space['uid']?>" class="spacelink"><?=$_SN[$space['uid']]?>的主页</a>
<?php if($_TPL['spacemenus']) { ?>
<?php if(is_array($_TPL['spacemenus'])) { foreach($_TPL['spacemenus'] as $value) { ?> <span class="pipe">&raquo;</span> <?=$value?><?php } } ?>
<?php } ?>
</div>

<div class="h_status">按照发布时间排序</div>
<?php } ?>

<div class="colmain">	

<?php if($space['self']) { ?>
﻿<div class="multiComposer " id="statusComposer">
 <div class="mcAvatar">
 <div class="avatar-48"><a href="cp.php" title=" <?=$space['viewnum']?> 次访问, <?=$space['credit']?> 个积分, <?=$space['experience']?> 个经验"><?php echo avatar($_SGLOBAL[supe_uid],small); ?></a></div> 
 </div>
 <div class="mcContent">
 <form method="post" id="doingform" action="cp.php?ac=doing&view=<?=$_GET['view']?>">
 <div class="mcPanel">
 <div class="mcStatus">
 <div class="mcStatusInt">
 <div class="mcStatusIpt">
 <textarea id="message" name="message" onfocus="bindFocus();" onBlur="bindBlur();" onkeyup="textCounter(this, 'maxlimit', 200)" onkeydown="ctrlEnter(event, 'add');" rows="3" cols="10" class="blank"></textarea>
 </div>
 <div class="mcStatusAct">
 <div class="mcStatusEmot"><span class="emot e-base-1"><a href="###" id="doingface" onclick="showFace(this.id, 'message');return false;"><img src="image/facelist.gif" align="absmiddle" /></a></span></div>
 <input type="hidden" name="addsubmit" value="true" />
 <div class="mcStatusBtn"><span class="button"><span><button type="submit" id="add" name="add">&nbsp;发送&nbsp;</button></span></span></div>
 <input type="hidden" name="refer" value="<?=$theurl?>" />
<input type="hidden" name="topicid" value="<?=$topicid?>" />
<input type="hidden" name="formhash" value="<?php echo formhash(); ?>" />
 </div>
 </div>
 </div>

 </div>
 </form>
 </div>
 </div>

 <script type="text/javascript">
        function getStatusText() {
var _default = '说说你在做什么？';
var _st = { 
//base 
c: ['嘿，哥们儿，嘛呢？', '既来之，则说之……', '什么叫热闹？大吼小叫！', '“得瑟得瑟”也不犯法！'],
//6:00 - 9:00 
m: ['路上堵车吗？', '地铁上遇到帅哥了吗？', '今天没迟到吧？', '今天小报上有什么趣闻？', '繁忙的一天开始，你要说的第一句是什么？'],
//9:00 - 12:00 
a: ['你准备买房了吗？', '你是否仍深爱酒井法子？', '贾君鹏回家吃饭了吗？', '今天任务多吗？', '今天中午吃点啥？'],
//12:00 - 14:00 
n: ['吃完饭后困了？', '今天中午吃的啥？', '附近新开了家饭馆？', '今天中午有什么八卦吗？', '今天中午和谁吃的饭？'],
//14:00 - 17:00 
p: ['今天大猫在公司吗？', '还有几个小时你就下班了？','向好友大声喊两句发泄发泄……', '说的不是一句话，是寂寞……', '工作完成了？'],
//17:00 - 19:00 
d: ['今天下班后什么安排？', '今天有人加班吗？', '还不下班？','你妈妈喊你回家吃饭', '有人请客吃饭吗？'],
//19:00 - 21:00 
e: ['这一天累吗？跟大家汇报汇报……', '晚上有什么好事儿发生？'],
//21:00 - 24:00 
l: ['周围安静吗？聊两句冒个泡', '还没睡？那喊两句吵醒别人！', '你正在干嘛？', '还在工作么？休息一下聊两句……'],
//0:00 - 6:00 
w: ['发现什么好玩的了吗？', '我要在这深夜对你们说些心里话……', '夜生活才刚刚开始？'],
//weekend 
k: ['周末玩得开心吗？', '周末有人加班吗？', '大周末的，跟朋友扯两句吧', '此刻你在哪呢？', '生活才刚刚开始？']
}; 
var r = _st.c ? _st.c: [];
var t = new Date();
var h = t.getHours(),
d = t.getDay();
if(h>=9&&h<12){r=r.concat(_st.a?_st.a:[]);}
if(h>=12&&h<14){r=r.concat(_st.n?_st.n:[]);}
if(h>=14&&h<17){r=r.concat(_st.p?_st.p:[]);}
if(h>=17&&h<19){r=r.concat(_st.d?_st.d:[]);}
if(h>=19&&h<21){r=r.concat(_st.e?_st.e:[]);}
if(h>=21&&h<24){r=r.concat(_st.l?_st.l:[]);}
if(h>=0&&h<6){r=r.concat(_st.w?_st.w:[]);}
if(d==0||d==6){r=r.concat(_st.k);}
if (r.length == 0) {
return _default;
} else {
return r[Math.floor(Math.random() * r.length)];
}

};

var defaultValue = getStatusText();
    $('message').value = defaultValue;

function bindFocus() {
    if($('message').value == defaultValue){
$('message').value = '';
}
$('message').className = '';

}

function bindBlur() {
$('message').className = 'blank';
if($('message').value == ''){
$('message').value = defaultValue;
}

}

</script>

<?php } ?>

<div class="statusFeed">
<div class="statusFeedTabs">
<ul>
<?php if($space['friendnum']) { ?><li<?=$actives['we']?>><a href="space.php?uid=<?=$space['uid']?>&do=<?=$do?>&view=we"><span>好友的一句话</span></a></li><?php } ?>
<li<?=$actives['all']?>><a href="space.php?uid=<?=$space['uid']?>&do=<?=$do?>&view=all"><span>随便看看</span></a></li>
<li<?=$actives['me']?>><a href="space.php?uid=<?=$space['uid']?>&do=<?=$do?>&view=me"><span>我的一句话</span></a></li>
<li<?=$actives['mood']?>><a href="space.php?uid=<?=$space['uid']?>&do=mood"><span>相同的一句话</span></a></li>
</ul>
<div class="option"></div>
</div>
<?php if($dolist) { ?>
<div class="statusFeedWrap newsfeed">
<ul class="feedList">
<?php if(is_array($dolist)) { foreach($dolist as $dv) { ?>
<?php $doid = $dv[doid]; ?>
<li class="feedItem feedItem-main feed-status feedItem-iphone" id="dl<?=$doid?>">
<div class="feedIcon"><span class="avatar-48"><a href="space.php?uid=<?=$dv['uid']?>"><?php echo avatar($dv[uid],small); ?></a></span></div>
<div class="feedContent">
<div class="feedHead">  
<h4>
<span class="statusWord"><i><i><i><i><a href="space.php?uid=<?=$dv['uid']?>"><?=$_SN[$dv['uid']]?></a>: <?=$dv['message']?> </i></i></i></i></span>     
</h4>
</div>
<div class="feedFoot">                
<a title="通过手机发布" class="icon i-wap" href="#" style="display:none"></a>
<span class="time"><?php echo sgmdate('m-d H:i',$dv[dateline],1); ?></span>
<?php if($dv['uid']==$_SGLOBAL['supe_uid']) { ?>  -  <span class="action"><a href="cp.php?ac=doing&op=delete&doid=<?=$doid?>&id=<?=$dv['id']?>" id="doing_delete_<?=$doid?>_<?=$dv['id']?>" onclick="ajaxmenu(event, this.id)" class="re gray">删除</a></span><?php } ?>  -  <span class="action"><a href="javascript:;" onclick="docomment_get('docomment_<?=$doid?>', 1);">回复</a></span>   
</div>

<?php $list = $clist[$doid]; ?>
<div class="feedComment" id="docomment_<?=$doid?>"<?php if(!$list) { ?> style="display:none;"<?php } ?>>
<span id="docomment_form_<?=$doid?>_0"></span>
<div class="commentBox commentBox-small">
﻿    <ul>
<?php if(is_array($list)) { foreach($list as $value) { ?>
    <?php if($value['uid']) { ?>
<li class="<?=$value['class']?>" style="<?=$value['style']?>">
<div class="commentAvatar">
<a href="space.php?uid=<?=$value['uid']?>" title="<?=$_SN[$value['uid']]?>"><span class="avatar-32"><?php echo avatar($value[uid],small); ?></span></a>
</div>
<div class="commentOption">
<?php if($value['uid']==$_SGLOBAL['supe_uid'] || $dv['uid']==$_SGLOBAL['supe_uid']) { ?><a href="cp.php?ac=doing&op=delete&doid=<?=$value['doid']?>&id=<?=$value['id']?>" id="doing_delete_<?=$value['doid']?>_<?=$value['id']?>" onclick="ajaxmenu(event, this.id)" class="icon i-del" title="删除">删除</a><?php } ?>
</div>
<div class="commentInfo">
<h4>
<a href="space.php?uid=<?=$value['uid']?>"><?=$_SN[$value['uid']]?></a> <span class="meta"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span>
<span class="meta">-</span> <a href="javascript:void(0)" onclick="docomment_form(<?=$value['doid']?>, <?=$value['id']?>);">回复</a>
</h4>
<p><?=$value['message']?></p>
</div>
<span style="display:none" id="docomment_form_<?=$value['doid']?>_<?=$value['id']?>"></span>
</li>
<?php } ?>
    <?php } } ?>
    </ul>
<div class="clickComment">
<div class="addComment" id="input_<?=$doid?>_<?=$id?>">
<textarea onclick="subinput(<?=$doid?>, <?=$id?>);" class="addInput text">我来说一句...</textarea>
</div>
        <div style="display: none;" class="addComBox" id="text_form_<?=$doid?>_<?=$id?>">
            <div class="commentAvatar">
                <a href="space.php?uid=<?=$_SGLOBAL['supe_uid']?>" title="<?=$_SGLOBAL['supe_uid']?>"><span class="avatar-32"><?php echo avatar($_SGLOBAL[supe_uid],middle); ?></span></a>
            </div>
            <div class="commentRight" id="docomment_form_<?=$doid?>_<?=$id?>">
<form id="docommform_<?=$doid?>_<?=$id?>" method="post" action="cp.php?ac=doing&op=comment&doid=<?=$doid?>&id=<?=$id?>" >
                <input type="text" id="do_message_<?=$doid?>_<?=$id?>" name="message" class="addComment text" style="overflow: hidden;" onkeydown="return ctrlEnter(event, 'docommform_btn_<?=$doid?>_<?=$id?>', 1);">
<input type="hidden" name="commentsubmit" value="true" />
                <div class="commentEmot"><span class="emot e-base-1"><a href="#" id="do_face_<?=$doid?>_<?=$id?>" title="插入表情" onclick="showFace(this.id, 'do_message_<?=$doid?>_<?=$id?>');return false;"><img src="image/facelist.gif" align="absmiddle" /></a></span></div>
                <div class="commentBtn">
                    <span class="button button-main"><span><button class="button" type="button" name="do_button" id="docommform_btn_<?=$doid?>_<?=$id?>" onclick="ajaxpost('docommform_<?=$doid?>_<?=$id?>', 'docomment_get', 1)">评论</button></span></span>
<span class="button button-main"><span><button class="button" type="button" name="btncancel" class="button" onclick="docomment_form_close(<?=$doid?>, <?=$id?>);">取消</button></span></span>
                </div>
<input type="hidden" name="formhash" value="<?php echo formhash(); ?>" />
</form><div id="__docommform_<?=$doid?>_<?=$id?>"></div>
            </div>
        </div>
    </div>

<span class="corner"></span> 
</div>
</div>

</div>
</li>
<?php } } ?>
</ul>
<div class="statusFeedPager"><div class="page"><?=$multi?></div></div>
</div>
<?php } else { ?>
<div class="listEmpty">现在还没有记录。<?php if($space['self']) { ?>你可以用一句话记录下这一刻在做什么。<?php } ?></div>
<?php } ?>
</div>

</div>


<div class="colSub">

<div class="statusTopics">
<h3>
<p class="r_option"><a href="space.php?uid=<?=$space['uid']?>&do=mood">全部</a></p>
跟<?php if($space['self']) { ?>我<?php } else { ?><?=$_SN[$space['uid']]?><?php } ?>同心情的朋友
</h3>
<?php if($moodlist) { ?>
<ul class="avatar_list">
<?php if(is_array($moodlist)) { foreach($moodlist as $key => $value) { ?>
<li>
<div class="avatar-48"><a href="space.php?uid=<?=$value['uid']?>&do=doing"><?php echo avatar($value[uid],small); ?></a></div>
<p><a href="space.php?uid=<?=$value['uid']?>" title="<?=$_SN[$value['uid']]?>"><?=$_SN[$value['uid']]?></a></p>
<p class="gray"><?php echo sgmdate('n月j日',$value[updatetime],1); ?></p>
</li>
<?php } } ?>
</ul>
<?php } ?>
</div>

</div>
<?php } ?>
</div>
﻿<?php if(empty($_SGLOBAL['inajax'])) { ?>
<?php if(empty($_TPL['nosidebar'])) { ?>
<?php if($_SGLOBAL['ad']['contentbottom']) { ?><br style="line-height:0;clear:both;"/><div id="ad_contentbottom"><?php adshow('contentbottom'); ?></div><?php } ?>
</div>

<!--/mainarea-->
<div id="bottom"></div>
</div>
<!--/main-->
<?php } ?>

<div id="footer">

<p class="r_option">
<a href="javascript:;" onclick="window.scrollTo(0,0);" id="a_top" title="TOP"><img src="image/top.gif" alt="" style="padding: 5px 6px 6px;" /></a>
</p>

<?php if($_SGLOBAL['ad']['footer']) { ?>
<p style="padding:5px 0 10px 0;"><?php adshow('footer'); ?></p>
<?php } ?>

<?php if($_SCONFIG['close']) { ?>
<p style="color:blue;font-weight:bold;">
提醒：当前站点处于关闭状态
</p>
<?php } ?>
<p>
<?=$_SCONFIG['sitename']?> - 
<a href="mailto:<?=$_SCONFIG['adminemail']?>">联系我们</a>
<?php if($_SCONFIG['miibeian']) { ?> - <a  href="http://www.miibeian.gov.cn" target="_blank"><?=$_SCONFIG['miibeian']?></a><?php } ?>
</p>
<p>
Powered by <a  href="http://u.discuz.net" target="_blank"><strong>UCenter Home</strong></a> <span title="<?php echo X_RELEASE; ?>"><?php echo X_VER; ?></span>
<?php if(!empty($_SCONFIG['licensed'])) { ?><a  href="http://license.comsenz.com/?pid=7&host=<?=$_SERVER['HTTP_HOST']?>" target="_blank">Licensed</a><?php } ?>
&copy; 2001-2011 <a  href="http://www.comsenz.com" target="_blank">Comsenz Inc.</a>
</p>
<?php if($_SCONFIG['debuginfo']) { ?>
<p><?php echo debuginfo(); ?></p>
<?php } ?>
</div>
</div>
<!--/wrap-->

<?php if($_SGLOBAL['appmenu']) { ?>
<ul id="ucappmenu_menu" class="dropmenu_drop" style="display:none;">
<li><a href="<?=$_SGLOBAL['appmenu']['url']?>" title="<?=$_SGLOBAL['appmenu']['name']?>" target="_blank"><?=$_SGLOBAL['appmenu']['name']?></a></li>
<?php if(is_array($_SGLOBAL['appmenus'])) { foreach($_SGLOBAL['appmenus'] as $value) { ?>
<li><a href="<?=$value['url']?>" title="<?=$value['name']?>" target="_blank"><?=$value['name']?></a></li>
<?php } } ?>
</ul>
<?php } ?>


<?php if($_SGLOBAL['supe_uid']) { ?>
<?php if(!isset($_SCOOKIE['checkpm'])) { ?>
<script language="javascript"  type="text/javascript" src="cp.php?ac=pm&op=checknewpm&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>
<?php if(!isset($_SCOOKIE['synfriend'])) { ?>
<script language="javascript"  type="text/javascript" src="cp.php?ac=friend&op=syn&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>
<?php } ?>
<?php if(!isset($_SCOOKIE['sendmail'])) { ?>
<script language="javascript"  type="text/javascript" src="do.php?ac=sendmail&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>

<?php if($_SGLOBAL['ad']['couplet']) { ?>
<script language="javascript" type="text/javascript" src="source/script_couplet.js"></script>
<div id="uch_couplet" style="z-index: 10; position: absolute; display:none">
<div id="couplet_left" style="position: absolute; left: 2px; top: 60px; overflow: hidden;">
<div style="position: relative; top: 25px; margin:0.5em;" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('uch_couplet');"><img src="image/advclose.gif"></div>
<?php adshow('couplet'); ?>
</div>
<div id="couplet_rigth" style="position: absolute; right: 2px; top: 60px; overflow: hidden;">
<div style="position: relative; top: 25px; margin:0.5em;" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('uch_couplet');"><img src="image/advclose.gif"></div>
<?php adshow('couplet'); ?>
</div>
<script type="text/javascript">
lsfloatdiv('uch_couplet', 0, 0, '', 0).floatIt();
</script>
</div>
<?php } ?>
<?php if($_SCOOKIE['reward_log']) { ?>
<script type="text/javascript">
showreward();
</script>
<?php } ?>
</body>
</html>
<?php } ?>
<?php ob_out();?>