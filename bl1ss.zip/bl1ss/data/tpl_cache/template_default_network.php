<?php if(!defined('IN_UCHOME')) exit('Access Denied');?><?php subtplcheck('template/default/network|template/default/header|template/default/space_ifeed_li|template/default/footer', '1303228259', 'template/default/network');?>﻿<?php $_TPL['nosidebar']=1; ?>
﻿<?php if(empty($_SGLOBAL['inajax'])) { ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=<?=$_SC['charset']?>" />
<meta http-equiv="x-ua-compatible" content="ie=7" />
<title><?php if($_TPL['titles']) { ?><?php if(is_array($_TPL['titles'])) { foreach($_TPL['titles'] as $value) { ?><?php if($value) { ?><?=$value?> - <?php } ?><?php } } ?><?php } ?><?php if($_SN[$space['uid']]) { ?><?=$_SN[$space['uid']]?> - <?php } ?><?=$_SCONFIG['sitename']?></title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<script language="javascript" type="text/javascript" src="source/script_jquery.js"></script>
<script language="javascript" type="text/javascript" src="source/script_cookie.js"></script>
<script language="javascript" type="text/javascript" src="source/script_common.js"></script>
<script language="javascript" type="text/javascript" src="source/script_menu.js"></script>
<script language="javascript" type="text/javascript" src="source/script_ajax.js"></script>
<script language="javascript" type="text/javascript" src="source/script_face.js"></script>
<script language="javascript" type="text/javascript" src="source/script_manage.js"></script>
<link id="skinc" href="/template/default/style.css" rel="stylesheet" type="text/css" />
<?php if($_TPL['css']) { ?>
<link id="skinc" href="/template/default/<?=$_TPL['css']?>.css" rel="stylesheet" type="text/css" />
<?php } ?>
<?php if(!empty($_SGLOBAL['space_theme'])) { ?>
<link id="skinc" href="/theme/<?=$_SGLOBAL['space_theme']?>/style.css" rel="stylesheet" type="text/css" />
<?php } elseif($_SCONFIG['template'] != 'default') { ?>
<link id="skinc" href="/template/<?=$_SCONFIG['template']?>/style.css" rel="stylesheet" type="text/css" />
<?php } ?>

<style type="text/css">
<?php if(!empty($_SGLOBAL['space_css'])) { ?>
<?=$_SGLOBAL['space_css']?> 
<?php } ?>
</style>
<link rel="shortcut icon" href="image/favicon.ico" />
<link rel="edituri" type="application/rsd+xml" title="rsd" href="xmlrpc.php?rsd=<?=$space['uid']?>" />

</head>
<body>
<div id="append_parent"></div>
<div id="ajaxwaitid"></div>
<div id="header">
<div class="wp">
<div id="logo"></div>

<div id="nav">
<div>
<?php if($_SGLOBAL['supe_uid']) { ?>
<a href="space.php">myspace</a>
<a href="cp.php?ac=common&op=logout&uhash=<?=$_SGLOBAL['uhash']?>">logout</a>
<?php } else { ?>
<a href="do.php?ac=<?=$_SCONFIG['login_action']?>">Share</a> | 
<a href="do.php?ac=<?=$_SCONFIG['login_action']?>">Login</a> | 
<a href="do.php?ac=<?=$_SCONFIG['register_action']?>">Register</a>
<?php } ?>
</div>
<div id="navitem">
<a href="network.php"><img src="/template/default/i/nav_home.jpg" /></a>
<a href="space.php?act=home&view=all"><img src="/template/default/i/nav_comm.jpg" /></a>
<a href="books.php"><img src="/template/default/i/nav_books.jpg" /></a>
<a href="movies.php"><img src="/template/default/i/nav_mov.jpg" /></a>
<a href="music.php"><img src="/template/default/i/nav_mus.jpg" /></a>
<a href="arts.php"><img src="/template/default/i/nav_art.jpg" /></a>
</div>
</div>
<div class="cl"></div>
</div>
</div>

<div id="wrap">

<?php if(empty($_TPL['nosidebar'])) { ?>
<div id="main">
<div id="app_sidebar">
<?php if($_SGLOBAL['supe_uid']) { ?>
    <h2>Personal Center</h2>
<ul class="app_list" id="default_userapp">
<li><a href="space.php?do=doing"><span class="icon i-app24 i-app24-status"></span>Fresh things</a></li>
<li><a href="space.php?do=album"><span class="icon i-app24 i-app24-album"></span>Albums</a><em><a href="cp.php?ac=upload" class="gray">upload</a></em></li>
<li><a href="space.php?do=blog"><span class="icon i-app24 i-app24-blog"></span>WebLog</a><em><a href="cp.php?ac=blog" class="gray">issue</a></em></li>
</ul>

            <h2>互动中心</h2>
<ul class="app_list" id="default_userapp">
<li><a href="space.php?do=poll"><span class="icon i-app24 i-app24-vote"></span>投票</a><em><a href="cp.php?ac=poll" class="gray">发起</a></em></li>
<li><a href="space.php?do=mtag"><span class="icon i-app24 i-app24-thread"></span>群组</a><em><a href="cp.php?ac=thread" class="gray">话题</a></em></li>
<li><a href="space.php?do=event"><span class="icon i-app24 i-app24-event"></span>活动</a><em><a href="cp.php?ac=event" class="gray">发起</a></em></li>
<li><a href="space.php?do=share"><span class="icon i-app24 i-app24-share"></span>分享</a></li>
<li><a href="space.php?do=topic"><span class="icon i-app24 i-app24-hot"></span>专题</a></li>
</ul>

           

<div id="appbarActions">
<?php if($_SCONFIG['my_status']) { ?><a class="act a-manage" href="cp.php?ac=userapp&op=menu" >设置</a>&nbsp;<?php } ?><?php if($_SGLOBAL['my_menu_more']) { ?><a href="javascript:;" id="a_app_more" onclick="userapp_open();" class="off">展开</a><?php } ?>
            </div>

<?php } else { ?>
<div class="bar_text">
<form id="loginform" name="loginform" action="do.php?ac=<?=$_SCONFIG['login_action']?>&ref" method="post">
<input type="hidden" name="formhash" value="<?php echo formhash(); ?>" />
<p><h2>登陆更精彩...</h2></p>
<p>账号:</p>
<p><input type="text" name="username" id="username" class="t_input" size="15" value="" /></p>
<p>密码:</p>
<p><input type="password" name="password" id="password" class="t_input" size="15" value="" /></p>
<p ><input type="checkbox" id="cookietime" name="cookietime" value="315360000" checked /><label for="cookietime">记住我</label></p>
<p>
<input type="submit" id="loginsubmit" name="loginsubmit" value="登录" class="submit" />
<input type="button" name="regbutton" value="注册" class="button" onclick="urlto('do.php?ac=<?=$_SCONFIG['register_action']?>');">
</p>
</form>

</div>
<?php } ?>
</div>

<div id="mainarea">

<?php if($_SGLOBAL['ad']['contenttop']) { ?><div id="ad_contenttop"><?php adshow('contenttop'); ?></div><?php } ?>
<?php } ?>

<?php } ?>

<script type="text/javascript" language="javascript">

jQ(document).ready(function(){
jQ(".showtipdiv ul li a").mouseover(function(){
    jQ(this).parent().find('div').css({"top":(jQ(this).offset().top - 3)+"px","left":(jQ(this).offset().left+jQ(this).width())+"px"}).show()
}).mouseout(function(){jQ(this).parent().find('div').hide()})

});
</script>
<div id="body">
<div id="bodyleft">
<div class="ad1">
<img src="/template/default/my/AD01.jpg" width="600" height="200" />
</div>
<div class="mytitle">
<a href="/books.php?do=newbooks">New Books (More):</a>
</div>
<div class="booksList showtipdiv">
<ul class="cl">
<?php if(is_array($booksList)) { foreach($booksList as $value) { ?>
<li><a href="books.php?do=view&id=<?=$value['id']?>"><img src="<?=$value['bigimg']?>" width="105" height="145" /></a>
<div style="display:none;">
<h3><?=$value['conname']?></h3>
<p class="msxx"><?=$value['zzname']?> / <?=$value['update']?> / <?=$value['tag']?> / <span class="start<?=$value['pf']['num']?>" ><?=$value['pf']['pjf']?></span> </p>
<p><?php echo getstr($value['apptext'], 420, 0, 0, 0, 0, -1) ?></p>
</div>
</li>

<?php } } ?>
</ul>
</div>
<div class="mytitle">
<a href="movies.php?do=new">In Cinemas (More):</a>
</div>
<div class="CinemasList">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="350">
<?php if(is_array($GroomMovies)) { foreach($GroomMovies as $v) { ?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td rowspan="6" width="120"><a href="movies.php?do=view&id=<?=$v['id']?>"><img src="<?=$v['pic']?>" width="105" height="145" /></a></td>
    <td><a href="movies.php?do=view&id=<?=$v['id']?>"><?=$v['videoname']?></a></td>
  </tr>
  <tr>
    <td><span class="start<?=$v['pf']['num']?>" ><?=$v['pf']['pjf']?></span></td>
  </tr>
  <tr>
    <td>导演：<a href="movies.php?do=search&k=<?=$v['director']?>"><?=$v['director']?></a></td>
  </tr>
  <tr>
    <td>主演：<a href="movies.php?do=search&k=<?=$v['starring']?>"><?=$v['starring']?></a></td>
  </tr>
  <tr>
    <td>上映时间：<?php echo sgmdate('Y-m-d',$v[playtime]); ?></td>
  </tr>
  <tr>
    <td><?=$v['over']?>人看过/<?=$v['want']?>人想看</td>
    </tr>
</table>
<?php } } ?>
</td>
    <td class="showtipdiv">
<ul>
<?php if(is_array($MoviesList)) { foreach($MoviesList as $v) { ?>
<li style="float:left;"><a href="movies.php?do=view&id=<?=$v['id']?>" style="margin-left:8px;"><img src="<?=$v['pic']?>" width="105" height="145" /></a></li>
<div style="display:none;">
<h3><?=$v['videoname']?></h3>
<p class="msxx">导演：<?=$v['director']?> / 上映时间：<?php echo sgmdate('Y-m-d',$v[playtime]); ?> / <?=$v['tag']?> </p>
<p><?php echo getstr($v['summary'], 420, 0, 0, 0, 0, -1) ?></p>
</div>
<?php } } ?>
</ul>
</td>
  </tr>
</table>

</div>
<div class="mytitle">
New Songs (More):
</div>
<div class="SongsList">
<ul class="cl">
<?php if(is_array($MusicList)) { foreach($MusicList as $v) { ?>
<li>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><?=$v['mindex']?></td>
    <td><a href="music.php?do=view&id=<?=$v['mid']?>"><?=$v['musicname']?></a></td>
    <td><?=$v['playtime']?></td>
  </tr>
</table>
</li>
<?php } } ?>
</ul>
</div>
<div class="mytitle">
New Art (More):
</div>
<div class="ArtList showtipdiv">
<ul class="cl">
<?php if(is_array($ArtList)) { foreach($ArtList as $value) { ?>
<li><a href="arts.php?do=view&id=<?=$value['id']?>"><img src="<?=$value['pic']?>" width="105" height="100" /></a>
<div style="display:none;">
<h3><?=$value['artname']?></h3>
<p class="msxx"><?=$value['author']?> / <?=$value['dateline']?> / <?=$value['tag']?> / <?=$value['pjf']?> </p>
<p><?=$value['summary']?></p>
</div>
</li>
<?php } } ?>
</ul>
</div>
<div class="mytitle">
Top Comments (More):
</div>
<div class="CommentsList">
<ul>
<?php if(is_array($CommentsList)) { foreach($CommentsList as $v) { ?>
<li>
<p class="CommentTitle"><a href="comment.php?do=view&id=<?=$v['cid']?>"><?=$v['title']?></a></p>
<p><a href="space.php?uid=<?=$v['uid']?>"><?=$v['author']?></a> <?php echo sgmdate('Y-m-d',$v[addtime]); ?> 评论</p>
<p><?php echo getstr($v['message'], 260, 0, 0, 0, 0, -1) ?><a href="comment.php?do=view&id=<?=$v['cid']?>">(<?=$v['bcount']?>回应)</a></p>
</li>
<?php } } ?>
</ul>
</div>
<div class="mytitle">
Happening Now (More):
</div>
<div class="FeedList">
<div class="FeedTitle">此刻他们正在发生的新鲜事..</div>
<?php if($feedlist) { ?>
<?php $_TPL['hidden_hot']=1; ?>
<div class="mod" id="profileFeed">
<div class="mCt">
<div class="mHd">
<h3>新鲜事</h3><?php if($space['self']) { ?><a href="space.php?uid=<?=$space['uid']?>&do=feed&view=me" class="right">全部</a><?php } ?>
</div>
<div class="mBd">
<div class="profileFeedWrap">
<div class="minifeed" id="storyListEl">
<ul class="feedList minifeedList">
 <?php if(is_array($feedlist)) { foreach($feedlist as $value) { ?>
﻿<?php if($value['icon']=='doing') { ?>
<li class="feedItem feedItem-main feed-<?=$value['icon']?> " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);">    
    <div class="feedIcon">
        <span class="icon i-app-<?=$value['icon']?>"></span>	
    </div>
    <div class="feedContent feedStyle-short">
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<span class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-del">删除</a></span>
<?php } ?>
<h4>
<span class="statusWord"><i><i><i><i> <?=$value['title_template']?> </i></i></i></i></span>     
</h4>
</div>        
            <div class="feedFoot">                
                    <a title="通过手机发布" class="icon i-wap" href="#" style="display:none"></a>
                    <span class="time"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span>  -   
                    <?php if(empty($_TPL['hidden_menu'])) { ?><?php if($value['idtype']=='doid') { ?><span class="action"><a onclick="docomment_get('docomment_<?=$value['id']?>', 1);" id="do_a_op_<?=$value['id']?>" href="javascript:void(0)">回复</a></span><?php } ?><?php } ?><?php if(!empty($hiddenfeed_num[$value['icon']])) { ?>  -  
<div class="feedHead" id="feed_more_<?=$value['feedid']?>" style="display:none;">              
<?php if(is_array($hiddenfeed_list[$value['icon']])) { foreach($hiddenfeed_list[$value['icon']] as $appvalue) { ?>
<?php $appvalue = mkfeed($appvalue); ?>

<h4>
<?=$appvalue['title_template']?>
</h4>
<?php if($appvalue['body_template']) { ?>
<span class="meta time"><?=$appvalue['body_template']?></span>
<?php } ?>

<?php } } ?>
</div>
<span id="appfeed_open_<?=$value['feedid']?>"><a class="act a-tg-down" href="javascript:;" id="feed_a_more_<?=$value['feedid']?>" onclick="feed_more_show('<?=$value['feedid']?>');">显示更多(<?=$hiddenfeed_num[$value['icon']]?>)条</a></span><?php } ?>      
            </div> 
<?php if($value['idtype']=='doid') { ?>
<div class="feedComment" id="docomment_<?=$value['id']?>" style="display:none;"></div>
<?php } ?> 

    </div>
</li>

<?php } elseif($value['icon']=='poll') { ?>

<li class="feedItem  feedItem-main feed-<?=$value['icon']?> " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);"> 
    <div class="feedIcon">       
<span class="icon i-app-<?=$value['icon']?>"></span>	
    </div>
   <div class="feedContent feedStyle-short">
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<span class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-del">删除</a></span>
<?php } ?>
<h4>
 <?=$value['title_template']?>     
</h4>
</div>
<?php if($value['body_template']) { ?>
<div class="feedBody">
<div class="feedAttach"><div class="feedAttachContent"><?=$value['body_template']?></div></div>
</div>
<?php } ?>
            <div class="feedFoot">                
                    <span class="time"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span>  -   
                    <?php if(empty($_TPL['hidden_menu'])) { ?><?php if($value['idtype']=='doid') { ?><span class="action"><a onclick="docomment_get('docomment_<?=$value['id']?>', 1);" id="do_a_op_<?=$value['id']?>" href="javascript:void(0)">回复</a></span><?php } elseif(in_array($value['idtype'], array('blogid','picid','sid','pid','eventid'))) { ?><span class="action"><a onclick="feedcomment_get(<?=$value['feedid']?>);" id="feedcomment_a_op_<?=$value['feedid']?>" href="javascript:void(0)">评论</a></span><?php } ?><?php } ?><?php if(!empty($hiddenfeed_num[$value['icon']])) { ?>  -  
<div class="feedHead" id="feed_more_<?=$value['feedid']?>" style="display:none;">              
<?php if(is_array($hiddenfeed_list[$value['icon']])) { foreach($hiddenfeed_list[$value['icon']] as $appvalue) { ?>
<?php $appvalue = mkfeed($appvalue); ?>

<h4>
<?=$appvalue['title_template']?>
</h4>
<?php if($appvalue['body_template']) { ?>
<span class="meta time"><?=$appvalue['body_template']?></span>
<?php } ?>

<?php } } ?>
</div>
<span id="appfeed_open_<?=$value['feedid']?>"><a class="act a-tg-down" href="javascript:;" id="feed_a_more_<?=$value['feedid']?>" onclick="feed_more_show('<?=$value['feedid']?>');">显示更多(<?=$hiddenfeed_num[$value['icon']]?>)条</a></span><?php } ?>       
            </div> 
<?php if($value['idtype']) { ?>
<div class="feedComment" id="feedcomment_<?=$value['feedid']?>" style="display:none;"></div>
<?php } ?> 
    </div>
</li>

<?php } elseif($value['icon']=='blog') { ?>
<li class="feedItem  feedItem-main feed-<?=$value['icon']?> " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);">
    <div class="feedIcon">       
<span class="icon i-app-<?=$value['icon']?>"></span>
    </div>
    <div class="feedContent feedStyle-short">
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<span class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-del">删除</a></span>
<?php } ?>
<h4>
 <?=$value['title_template']?>     
</h4>
</div>
<?php if($value['body_template']) { ?>
<div class="feedBody">
<div class="feedAttach">
<?php if($value['image_1']) { ?>
<div class="feedAttachMedia"><a href="<?=$value['image_1_link']?>"<?=$value['target']?>><img src="<?=$value['image_1']?>" class="photo-50" /></a></div>
<?php } ?>
<div class="feedAttachContent"><?=$value['body_template']?></div></div>
</div>
<?php } ?>
            <div class="feedFoot">                
                    <span class="time"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span>  -   
                    <?php if(empty($_TPL['hidden_menu'])) { ?><?php if(in_array($value['idtype'], array('blogid','picid','sid','pid','eventid'))) { ?><span class="action"><a onclick="feedcomment_get(<?=$value['feedid']?>);" id="feedcomment_a_op_<?=$value['feedid']?>" href="javascript:void(0)">评论</a></span><?php } ?><?php } ?><?php if(!empty($hiddenfeed_num[$value['icon']])) { ?>  -  
<div class="feedHead" id="feed_more_<?=$value['feedid']?>" style="display:none;">              
<?php if(is_array($hiddenfeed_list[$value['icon']])) { foreach($hiddenfeed_list[$value['icon']] as $appvalue) { ?>
<?php $appvalue = mkfeed($appvalue); ?>

<h4>
<?=$appvalue['title_template']?>
</h4>
<?php if($appvalue['body_template']) { ?>
<span class="meta time"><?=$appvalue['body_template']?></span>
<?php } ?>

<?php } } ?>
   </div>	
<span id="appfeed_open_<?=$value['feedid']?>"><a class="act a-tg-down" href="javascript:;" id="feed_a_more_<?=$value['feedid']?>" onclick="feed_more_show('<?=$value['feedid']?>');">显示更多(<?=$hiddenfeed_num[$value['icon']]?>)条</a></span><?php } ?>         
            </div> 
<?php if($value['idtype']) { ?>
<div class="feedComment" id="feedcomment_<?=$value['feedid']?>" style="display:none;"></div>
<?php } ?>
    </div>
</li>

<?php } elseif($value['icon']=='thread') { ?>

<li class="feedItem  feedItem-main feed-<?=$value['icon']?> " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);">
    <div class="feedIcon">       
<span class="icon i-app-<?=$value['icon']?>"></span>	
    </div>
    <div class="feedContent feedStyle-short">
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<span class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-del" >删除</a></span>
<?php } ?>
<h4>
 <?=$value['title_template']?>     
</h4>
</div>
<?php if($value['body_template']) { ?>
<div class="feedBody">
<div class="feedAttach">
<div class="feedAttachContent"><?=$value['body_template']?></div></div>
</div>
<?php } ?>	
    </div>
</li>

<?php } elseif(in_array($value['icon'], array('profile','friend','joinpoll','click','comment','myop','mtag','task','wall','post','show','joinevent'))) { ?>

<li class="feedItem feedItem-sub feed-<?=$value['icon']?>  " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);">
<div class="feedIcon"><span class="icon i-app-<?=$value['icon']?>"></span></div>
<div class="feedContent feedStyle-oneline" >	
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<span class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-del" title="删除">删除</a></span>
<?php } ?>
<h4> <?=$value['title_template']?><span class="meta time"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span> 
<?php if(in_array($value['idtype'], array('commentid'))) { ?>
<span class="action"><a  onclick="feedcommentback_get(<?=$value['feedid']?>);" id="feedcomment_a_op_<?=$value['feedid']?>" href="javascript:void(0)">回应</a></span>

<?php } ?>
</h4>
<?php if(in_array($value['idtype'], array('commentid'))) { ?>
<div class="feedBody">
<?php if($value['body_template']) { ?><?=$value['body_template']?><?php } ?>
</div>
<?php } ?>
<?php if(in_array($value['idtype'], array('commentid'))) { ?>
<div class="feedComment" id="feedcomment_<?=$value['feedid']?>" style="display:none;"></div>
<?php } ?> 
<?php if(!empty($hiddenfeed_num[$value['icon']])) { ?>
<div class="feedFoot"> 
<div class="feedHead" id="feed_more_<?=$value['feedid']?>" style="display:none;">              
<?php if(is_array($hiddenfeed_list[$value['icon']])) { foreach($hiddenfeed_list[$value['icon']] as $appvalue) { ?>
<?php $appvalue = mkfeed($appvalue); ?>

<h4>
<?=$appvalue['title_template']?>
</h4>
<?php if($appvalue['body_template']) { ?>
<span class="meta time"><?=$appvalue['body_template']?></span>
<?php } ?>

<?php } } ?>
</div>                        
               <span id="appfeed_open_<?=$value['feedid']?>"><a class="act a-tg-down" href="javascript:;" id="feed_a_more_<?=$value['feedid']?>" onclick="feed_more_show('<?=$value['feedid']?>');">显示更多(<?=$hiddenfeed_num[$value['icon']]?>)条</a></span>
        </div>
<?php } ?>

</div>
</li>

<?php } elseif($value['icon']=='share') { ?>
<li class="feedItem  feedItem-main feed-<?=$value['icon']?> " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);">
    <div class="feedIcon">       
<span class="icon i-app-<?=$value['icon']?>"></span>	
    </div>
    <div class="feedContent feedStyle-short">
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<div class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-del" title="删除">删除</a></div>
<?php } ?>
<h4>
 <?=$value['title_template']?> 
</h4>
</div>
<div class="feedBody">
<div class="feedAttach feedAttach-user">
        <?php if($value['image_1'] && empty($value['body_data']['flashvar'])) { ?>
<div class="feedAttachMedia"><a href="<?=$value['image_1_link']?>"<?=$value['target']?>><img src="<?=$value['image_1']?>" class="photo-50" /></a></div>
<?php } ?>
<?php if($value['image_2']) { ?>
<a href="<?=$value['image_2_link']?>"<?=$value['target']?>><img src="<?=$value['image_2']?>" class="summaryimg1" /></a>
<?php } ?>
<?php if($value['image_3']) { ?>
<a href="<?=$value['image_3_link']?>"<?=$value['target']?>><img src="<?=$value['image_3']?>" class="summaryimg2" /></a>
<?php } ?>
<?php if($value['image_4']) { ?>
<a href="<?=$value['image_4_link']?>"<?=$value['target']?>><img src="<?=$value['image_4']?>" class="summaryimg3" /></a>
<?php } ?>
<?php if($value['thisapp'] && !empty($value['body_data']['flashvar'])) { ?>
<div class="feedAttachMedia">
<div class="playVideo">
<a id="media_id_<?=$value['feedid']?>" class="videoCover" title="播放该视频" onclick="javascript:showFlash('<?=$value['body_data']['host']?>', '<?=$value['body_data']['flashvar']?>', this, '<?=$value['feedid']?>');" style="cursor:pointer;"><img id=icon_id_<?=$value['feedid']?> src="<?php if(!empty($value['image_1'])) { ?><?=$value['image_1']?><?php } else { ?>image/videoCover.gif<?php } ?>" class="video"/><em>播放该视频</em></a>
</div>
</div>
<?php } elseif($value['thisapp'] && !empty($value['body_data']['musicvar'])) { ?>
<div class="feedAttachMedia">
<div class="playMusic">
<a onclick="javascript:showFlash('music', '<?=$value['body_data']['musicvar']?>', this, '<?=$value['feedid']?>');" style="cursor:pointer;" class="musicCover" title="播放该音乐" >播放该音乐</a>
</div>
</div>
<?php } elseif($value['thisapp'] && !empty($value['body_data']['flashaddr'])) { ?>
<div class="feedAttachMedia">
<div class="playFlash">
<a onclick="javascript:showFlash('flash', '<?=$value['body_data']['flashaddr']?>', this, '<?=$value['feedid']?>');" style="cursor:pointer;" class="musicCover" title="播放该音乐" >播放该音乐</a>
</div>
</div>
<?php } ?>
<?php if($value['body_template'] && empty($value['body_data']['flashvar']) && empty($value['body_data']['musicvar']) && empty($value['body_data']['flashaddr'])) { ?>
<div class="feedAttachContent"><?=$value['body_template']?></div>
<?php } ?> </div>
<?php if($value['body_general']) { ?>
<p class="quote"><?=$value['body_general']?><q></q></p>
<?php } ?>
</div>

            <div class="feedFoot">                
                    <span class="time"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span>  -   
                    <?php if(empty($_TPL['hidden_menu'])) { ?><?php if($value['idtype']=='doid') { ?><span class="action"><a onclick="docomment_get('docomment_<?=$value['id']?>', 1);" id="do_a_op_<?=$value['id']?>" href="javascript:void(0)">回复</a></span><?php } elseif(in_array($value['idtype'], array('blogid','picid','sid','pid','eventid'))) { ?><span class="action"><a onclick="feedcomment_get(<?=$value['feedid']?>);" id="feedcomment_a_op_<?=$value['feedid']?>" href="javascript:void(0)">评论</a></span><?php } ?><?php } ?>      
            </div> 
<?php if($value['idtype']) { ?>
<div class="feedComment" id="feedcomment_<?=$value['feedid']?>" style="display:none;"></div>
<?php } ?> 
    </div>
</li>

<?php } elseif(in_array($value['icon'], array('album'))) { ?>

<li class="feedItem feedItem-main feed-<?=$value['icon']?>  " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);">
<div class="feedIcon"><span class="icon i-app-<?=$value['icon']?>"></span></div>
<div class="feedContent feedStyle-short" >	
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<span class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-del" title="删除">删除</a></span>
<?php } ?>
<h4><?=$value['title_template']?>&nbsp;<?php if($value['body_template']) { ?><?=$value['body_template']?><?php } ?></h4></div>
<div class="feedBody">
<div class="albumSample"><ul class="albumCover">
<?php if($value['image_1']) { ?>
<li><a href="<?=$value['image_1_link']?>"<?=$value['target']?>><img src="<?=$value['image_1']?>" class="photo" /></a></li>
<?php } ?>
<?php if($value['image_2']) { ?>
<li><a href="<?=$value['image_2_link']?>"<?=$value['target']?>><img src="<?=$value['image_2']?>" class="photo" /></a></li>
<?php } ?>
<?php if($value['image_3']) { ?>
<li><a href="<?=$value['image_3_link']?>"<?=$value['target']?>><img src="<?=$value['image_3']?>" class="photo" /></a></li>
<?php } ?>
<?php if($value['image_4']) { ?>
<li><a href="<?=$value['image_4_link']?>"<?=$value['target']?>><img src="<?=$value['image_4']?>" class="photo" /></a></li>
<?php } ?>
</ul></div></div>
<div class="feedFoot"><span class="time"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span></div>
</div>

</li>

<?php } elseif(in_array($value['icon'], array('event'))) { ?>

<li class="feedItem feedItem-main feed-<?=$value['icon']?>  " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);">
<div class="feedIcon"><span class="icon i-app-<?=$value['icon']?>"></span></div>
<div class="feedContent feedStyle-short" >	
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<span class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-del" title="删除">删除</a></span>
<?php } ?>
<h4><?=$value['title_template']?>&nbsp;</h4></div>
<div class="feedBody"><div class="feedAttach feedAttach-event-img">
<?php if($value['image_1']) { ?><div class="feedAttachMedia"><a href="<?=$value['image_1_link']?>"<?=$value['target']?>><img src="<?=$value['image_1']?>" class="poster_pre" /></a></div><?php } ?>

<div class="feedAttachContent"><?php if($value['body_template']) { ?><?=$value['body_template']?><?php } ?></div></div></div>
<div class="feedFoot">                
<span class="time"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span>  -   
<?php if(empty($_TPL['hidden_menu'])) { ?><?php if(in_array($value['idtype'], array('blogid','picid','sid','pid','eventid'))) { ?><span class="action"><a onclick="feedcomment_get(<?=$value['feedid']?>);" id="feedcomment_a_op_<?=$value['feedid']?>" href="javascript:void(0)">评论</a></span><?php } ?><?php } ?>      
</div> 
<?php if($value['idtype']) { ?>
<div class="feedComment" id="feedcomment_<?=$value['feedid']?>" style="display:none;"></div>
<?php } ?> 	
</li>

<?php } elseif(in_array($value['icon'], array('sitefeed'))) { ?>

<li class="feedItem feedItem-main feed-<?=$value['icon']?>  " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);">
<div class="feedIcon"><span class="icon i-app-<?=$value['icon']?>"></span></div>
<div class="feedContent feedStyle-oneline" >	
<div class="feedHead">
<h4><?=$value['title_template']?></h4>
</div>
</div>
</li>

<?php } else { ?>
<li class="feedItem feedItem-sub feed-<?=$value['icon']?>  " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);">
<div class="feedIcon"><a href="space.php?uid=<?=$_GET['uid']?>&do=feed&view=<?=$_GET['view']?>&appid=<?=$value['appid']?>&icon=<?=$value['icon']?>"><img src="<?=$value['icon_image']?>" /></a></div>
<div class="feedContent feedStyle-oneline" >	
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<span class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-del" title="删除">删除</a></span>
<?php } ?>
<h4> <?=$value['title_template']?><span class="meta time"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span></h4>
</div>
<?php if(!empty($hiddenfeed_num[$value['icon']])) { ?>
<div class="feedFoot"> 
<div class="feedHead" id="feed_more_<?=$value['feedid']?>" style="display:none;">              
<?php if(is_array($hiddenfeed_list[$value['icon']])) { foreach($hiddenfeed_list[$value['icon']] as $appvalue) { ?>
<?php $appvalue = mkfeed($appvalue); ?>

<h4>
<?=$appvalue['title_template']?>
</h4>
<?php if($appvalue['body_template']) { ?>
<span class="meta time"><?=$appvalue['body_template']?></span>
<?php } ?>

<?php } } ?>
</div>                        
               <span id="appfeed_open_<?=$value['feedid']?>"><a class="act a-tg-down" href="javascript:;" id="feed_a_more_<?=$value['feedid']?>" onclick="feed_more_show('<?=$value['feedid']?>');">显示更多(<?=$hiddenfeed_num[$value['icon']]?>)条</a></span>
        </div>
<?php } ?>

</div>
</li>
<?php } ?>
<?php } } ?>
</ul>
</div>
<div style="display: block;" class="feedMore"><a href="space.php?uid=<?=$space['uid']?>&do=feed&view=me">查看更多新鲜事</a></div> 
</div>
</div>
</div>
</div>
<?php } ?>
</div>
</div>
<div id="bodyright">
<div id="loginwrap">
<?php if(empty($_SGLOBAL['supe_uid'])) { ?>
<form id="loginform" name="loginform" action="do.php?ac=<?=$_SCONFIG['login_action']?>&<?=$url_plus?>&ref" method="post">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>User Name :</td>
    <td><input name="username" id="username" type="text" class="ppinput" value="<?=$membername?>" /></td>
    <td><input type="button" value="Register" /></td>
  </tr>
  <tr>
    <td>Password:</td>
    <td><input name="password" id="password" type="password" class="ppinput" value="<?=$password?>" /></td>
    <td><input type="hidden" name="refer" value="<?=$refer?>" /><input type="submit" class="sign"  value="Login" onFocus="this.blur()" name="loginsubmit" /></td>
  </tr>
  <tr>
    <td colspan="3"><input id="cookietime" name="cookietime" value="315360000" <?=$cookiecheck?> type="checkbox" />Remember Me Forgot Password </td>
    </tr>
</table>
<input type="hidden" name="formhash" value="<?php echo formhash(); ?>" /></form>
<?php } else { ?>
<div class="login_top">
<a class="logout_link" href="cp.php?ac=common&op=logout&uhash=<?=$_SGLOBAL['uhash']?>">退出</a> <strong id="nickname" class="welcome_nickname"><?=$_SN[$_SGLOBAL['supe_uid']]?></strong> <strong ><?=$space['star']?></strong>
</div>
<div class="login_info">
  <div class="my_portrait"><?php echo avatar($_SGLOBAL[supe_uid],middle); ?></div>
  <p>主页人气：<?=$space['viewnum']?></p>
  <p>小 金 库：<?=$space['credit']?></p>
  <p>经验等级：<?=$space['experience']?></p>
  <p><a class="icon i-famousStar"></a>&nbsp;<a href="space.php">进入空间</a></p>
</div>
<?php } ?>
</div>
<div class="mytitle">
Quotes :
</div>
<div class="QuotesList">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="70" rowspan="2" align="center"><a href="/"><img src="/template/default/my/lt.jpg" width="60" height="80" /></a></td>
    <td valign="top" style="font-size:14px; line-height:20px;">Under normal circumstances the system configuration cache will modify the settings in the background, automatically updating</td>
  </tr>
  <tr>
    <td valign="top">— <span style="color:#F60; font-size:20px;">Doit</span></td>
  </tr>
</table>

</div>
<div class="mytitle">
Public Pages (More):
</div>
<div class="PPList">
<ul class="cl">
<?php if(is_array($mlist)) { foreach($mlist as $v) { ?>
<li><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td rowspan="3" width="70" align="center"><a href="space.php?uid=<?=$v['uid']?>"><span class="avatar-48"><?php echo avatar($v[uid],small); ?></span></a></td>
    <td><a href="space.php?uid=<?=$v['uid']?>"><?=$v['username']?></a></td>
  </tr>
  <tr>
    <td style="font-size:10px; color:#C30">37911人关注</td>
  </tr>
  <tr>
    <td style="font-size:10px">我喜欢看电影，我也是啊，所以我们有同一个地方..</td>
  </tr>
</table>
</li>
<?php } } ?>
</table>
</li>
</ul>
</div>
<div class="mytitle">
Top Forums (More):
</div>
<div class="ForumList">
<ul class="cl">
<?php if(is_array($mtag)) { foreach($mtag as $value) { ?>
<li><table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td rowspan="3" width="50" align="center"><a href="space.php?do=mtag&tagid=<?=$value['tagid']?>"><img src="<?=$value['pic']?>" width="40" height="40" /></a></td>
    <td><a href="space.php?do=mtag&tagid=<?=$value['tagid']?>"><?=$value['tagname']?></a></td>
  </tr>
  <tr>
    <td style="font-size:10px; color:#C30">0人关注</td>
  </tr>
  <tr>
    <td style="font-size:10px"><?=$value['announcement']?></td>
  </tr>
</table>
</li>
<?php } } ?>

</ul>
</div>
<div class="mytitle">
Top Blogs (More):
</div>
<div class="BlogsList">
<ul>
<?php if(is_array($tbloglist)) { foreach($tbloglist as $value) { ?>
<li><span><a href="space.php?uid=<?=$value['uid']?>" target="_blank" ><?=$value['username']?></a></span><a target="_blank" href="space.php?uid=<?=$value['uid']?>&do=blog&id=<?=$value['blogid']?>"><?=$value['subject']?></a> </li>
<?php } } ?>
</ul>
</div>

<div class="mytitle">
Latest Events (More):
</div>
<div class="EventsList">
<ul>
<?php if(is_array($eventlist)) { foreach($eventlist as $value) { ?>
<li><span><a href="space.php?do=event&id=<?=$value['eventid']?>"><?=$value['username']?></a></span><a href="space.php?do=event&id=<?=$value['eventid']?>"><?=$value['title']?></a> </li>
<?php } } ?>
</ul>
</div>
</div>
<div class="cl"></div>
</div>

﻿<?php if(empty($_SGLOBAL['inajax'])) { ?>
<?php if(empty($_TPL['nosidebar'])) { ?>
<?php if($_SGLOBAL['ad']['contentbottom']) { ?><br style="line-height:0;clear:both;"/><div id="ad_contentbottom"><?php adshow('contentbottom'); ?></div><?php } ?>
</div>

<!--/mainarea-->
<div id="bottom"></div>
</div>
<!--/main-->
<?php } ?>

<div id="footer">

<p class="r_option">
<a href="javascript:;" onclick="window.scrollTo(0,0);" id="a_top" title="TOP"><img src="image/top.gif" alt="" style="padding: 5px 6px 6px;" /></a>
</p>

<?php if($_SGLOBAL['ad']['footer']) { ?>
<p style="padding:5px 0 10px 0;"><?php adshow('footer'); ?></p>
<?php } ?>

<?php if($_SCONFIG['close']) { ?>
<p style="color:blue;font-weight:bold;">
提醒：当前站点处于关闭状态
</p>
<?php } ?>
<p>
<?=$_SCONFIG['sitename']?> - 
<a href="mailto:<?=$_SCONFIG['adminemail']?>">联系我们</a>
<?php if($_SCONFIG['miibeian']) { ?> - <a  href="http://www.miibeian.gov.cn" target="_blank"><?=$_SCONFIG['miibeian']?></a><?php } ?>
</p>
<p>
Powered by <a  href="http://u.discuz.net" target="_blank"><strong>UCenter Home</strong></a> <span title="<?php echo X_RELEASE; ?>"><?php echo X_VER; ?></span>
<?php if(!empty($_SCONFIG['licensed'])) { ?><a  href="http://license.comsenz.com/?pid=7&host=<?=$_SERVER['HTTP_HOST']?>" target="_blank">Licensed</a><?php } ?>
&copy; 2001-2011 <a  href="http://www.comsenz.com" target="_blank">Comsenz Inc.</a>
</p>
<?php if($_SCONFIG['debuginfo']) { ?>
<p><?php echo debuginfo(); ?></p>
<?php } ?>
</div>
</div>
<!--/wrap-->

<?php if($_SGLOBAL['appmenu']) { ?>
<ul id="ucappmenu_menu" class="dropmenu_drop" style="display:none;">
<li><a href="<?=$_SGLOBAL['appmenu']['url']?>" title="<?=$_SGLOBAL['appmenu']['name']?>" target="_blank"><?=$_SGLOBAL['appmenu']['name']?></a></li>
<?php if(is_array($_SGLOBAL['appmenus'])) { foreach($_SGLOBAL['appmenus'] as $value) { ?>
<li><a href="<?=$value['url']?>" title="<?=$value['name']?>" target="_blank"><?=$value['name']?></a></li>
<?php } } ?>
</ul>
<?php } ?>


<?php if($_SGLOBAL['supe_uid']) { ?>
<?php if(!isset($_SCOOKIE['checkpm'])) { ?>
<script language="javascript"  type="text/javascript" src="cp.php?ac=pm&op=checknewpm&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>
<?php if(!isset($_SCOOKIE['synfriend'])) { ?>
<script language="javascript"  type="text/javascript" src="cp.php?ac=friend&op=syn&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>
<?php } ?>
<?php if(!isset($_SCOOKIE['sendmail'])) { ?>
<script language="javascript"  type="text/javascript" src="do.php?ac=sendmail&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>

<?php if($_SGLOBAL['ad']['couplet']) { ?>
<script language="javascript" type="text/javascript" src="source/script_couplet.js"></script>
<div id="uch_couplet" style="z-index: 10; position: absolute; display:none">
<div id="couplet_left" style="position: absolute; left: 2px; top: 60px; overflow: hidden;">
<div style="position: relative; top: 25px; margin:0.5em;" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('uch_couplet');"><img src="image/advclose.gif"></div>
<?php adshow('couplet'); ?>
</div>
<div id="couplet_rigth" style="position: absolute; right: 2px; top: 60px; overflow: hidden;">
<div style="position: relative; top: 25px; margin:0.5em;" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('uch_couplet');"><img src="image/advclose.gif"></div>
<?php adshow('couplet'); ?>
</div>
<script type="text/javascript">
lsfloatdiv('uch_couplet', 0, 0, '', 0).floatIt();
</script>
</div>
<?php } ?>
<?php if($_SCOOKIE['reward_log']) { ?>
<script type="text/javascript">
showreward();
</script>
<?php } ?>
</body>
</html>
<?php } ?><?php ob_out();?>