<?php if(!defined('IN_UCHOME')) exit('Access Denied');?><?php subtplcheck('template/default/do_register|template/default/header|template/default/footer', '1303330284', 'template/default/do_register');?>﻿<?php $_TPL['nosidebar']=1; ?>
﻿<?php if(empty($_SGLOBAL['inajax'])) { ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=<?=$_SC['charset']?>" />
<meta http-equiv="x-ua-compatible" content="ie=7" />
<title><?php if($_TPL['titles']) { ?><?php if(is_array($_TPL['titles'])) { foreach($_TPL['titles'] as $value) { ?><?php if($value) { ?><?=$value?> - <?php } ?><?php } } ?><?php } ?><?php if($_SN[$space['uid']]) { ?><?=$_SN[$space['uid']]?> - <?php } ?><?=$_SCONFIG['sitename']?></title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<script language="javascript" type="text/javascript" src="source/script_jquery.js"></script>
<script language="javascript" type="text/javascript" src="source/script_cookie.js"></script>
<script language="javascript" type="text/javascript" src="source/script_common.js"></script>
<script language="javascript" type="text/javascript" src="source/script_menu.js"></script>
<script language="javascript" type="text/javascript" src="source/script_ajax.js"></script>
<script language="javascript" type="text/javascript" src="source/script_face.js"></script>
<script language="javascript" type="text/javascript" src="source/script_manage.js"></script>
<link id="skinc" href="/template/default/style.css" rel="stylesheet" type="text/css" />
<?php if($_TPL['css']) { ?>
<link id="skinc" href="/template/default/<?=$_TPL['css']?>.css" rel="stylesheet" type="text/css" />
<?php } ?>
<?php if(!empty($_SGLOBAL['space_theme'])) { ?>
<link id="skinc" href="/theme/<?=$_SGLOBAL['space_theme']?>/style.css" rel="stylesheet" type="text/css" />
<?php } elseif($_SCONFIG['template'] != 'default') { ?>
<link id="skinc" href="/template/<?=$_SCONFIG['template']?>/style.css" rel="stylesheet" type="text/css" />
<?php } ?>

<style type="text/css">
<?php if(!empty($_SGLOBAL['space_css'])) { ?>
<?=$_SGLOBAL['space_css']?> 
<?php } ?>
</style>
<link rel="shortcut icon" href="image/favicon.ico" />
<link rel="edituri" type="application/rsd+xml" title="rsd" href="xmlrpc.php?rsd=<?=$space['uid']?>" />

</head>
<body>
<div id="append_parent"></div>
<div id="ajaxwaitid"></div>
<div id="header">
<div class="wp">
<div id="logo"></div>

<div id="nav">
<div>
<?php if($_SGLOBAL['supe_uid']) { ?>
<a href="space.php">myspace</a>
<a href="cp.php?ac=common&op=logout&uhash=<?=$_SGLOBAL['uhash']?>">logout</a>
<?php } else { ?>
<a href="do.php?ac=<?=$_SCONFIG['login_action']?>">Share</a> | 
<a href="do.php?ac=<?=$_SCONFIG['login_action']?>">Login</a> | 
<a href="do.php?ac=<?=$_SCONFIG['register_action']?>">Register</a>
<?php } ?>
</div>
<div id="navitem">
<a href="network.php"><img src="/template/default/i/nav_home.jpg" /></a>
<a href="space.php?act=home&view=all"><img src="/template/default/i/nav_comm.jpg" /></a>
<a href="books.php"><img src="/template/default/i/nav_books.jpg" /></a>
<a href="movies.php"><img src="/template/default/i/nav_mov.jpg" /></a>
<a href="music.php"><img src="/template/default/i/nav_mus.jpg" /></a>
<a href="arts.php"><img src="/template/default/i/nav_art.jpg" /></a>
</div>
</div>
<div class="cl"></div>
</div>
</div>

<div id="wrap">

<?php if(empty($_TPL['nosidebar'])) { ?>
<div id="main">
<div id="app_sidebar">
<?php if($_SGLOBAL['supe_uid']) { ?>
    <h2>Personal Center</h2>
<ul class="app_list" id="default_userapp">
<li><a href="space.php?do=doing"><span class="icon i-app24 i-app24-status"></span>Fresh things</a></li>
<li><a href="space.php?do=album"><span class="icon i-app24 i-app24-album"></span>Albums</a><em><a href="cp.php?ac=upload" class="gray">upload</a></em></li>
<li><a href="space.php?do=blog"><span class="icon i-app24 i-app24-blog"></span>WebLog</a><em><a href="cp.php?ac=blog" class="gray">issue</a></em></li>
</ul>

            <h2>互动中心</h2>
<ul class="app_list" id="default_userapp">
<li><a href="space.php?do=poll"><span class="icon i-app24 i-app24-vote"></span>投票</a><em><a href="cp.php?ac=poll" class="gray">发起</a></em></li>
<li><a href="space.php?do=mtag"><span class="icon i-app24 i-app24-thread"></span>群组</a><em><a href="cp.php?ac=thread" class="gray">话题</a></em></li>
<li><a href="space.php?do=event"><span class="icon i-app24 i-app24-event"></span>活动</a><em><a href="cp.php?ac=event" class="gray">发起</a></em></li>
<li><a href="space.php?do=share"><span class="icon i-app24 i-app24-share"></span>分享</a></li>
<li><a href="space.php?do=topic"><span class="icon i-app24 i-app24-hot"></span>专题</a></li>
</ul>

           

<div id="appbarActions">
<?php if($_SCONFIG['my_status']) { ?><a class="act a-manage" href="cp.php?ac=userapp&op=menu" >设置</a>&nbsp;<?php } ?><?php if($_SGLOBAL['my_menu_more']) { ?><a href="javascript:;" id="a_app_more" onclick="userapp_open();" class="off">展开</a><?php } ?>
            </div>

<?php } else { ?>
<div class="bar_text">
<form id="loginform" name="loginform" action="do.php?ac=<?=$_SCONFIG['login_action']?>&ref" method="post">
<input type="hidden" name="formhash" value="<?php echo formhash(); ?>" />
<p><h2>登陆更精彩...</h2></p>
<p>账号:</p>
<p><input type="text" name="username" id="username" class="t_input" size="15" value="" /></p>
<p>密码:</p>
<p><input type="password" name="password" id="password" class="t_input" size="15" value="" /></p>
<p ><input type="checkbox" id="cookietime" name="cookietime" value="315360000" checked /><label for="cookietime">记住我</label></p>
<p>
<input type="submit" id="loginsubmit" name="loginsubmit" value="登录" class="submit" />
<input type="button" name="regbutton" value="注册" class="button" onclick="urlto('do.php?ac=<?=$_SCONFIG['register_action']?>');">
</p>
</form>

</div>
<?php } ?>
</div>

<div id="mainarea">

<?php if($_SGLOBAL['ad']['contenttop']) { ?><div id="ad_contenttop"><?php adshow('contenttop'); ?></div><?php } ?>
<?php } ?>

<?php } ?>


<script>
function register(id, result) {
if(result) {
$('registersubmit').disabled = true;
window.location.href = "<?=$jumpurl?>";
} else {
updateseccode();
}
}
</script>
<style type="text/css">
/template/default/template/default/login.css);
</style>
<div id="regIndex">
<div class="regBg">
<div class="regIntBg">
<div class="regBox">
<div class="regTitle">
<!--h1>基本信息</h1-->
<p>请填写你的基本信息，这样能帮助你找到更多身边的好友。</p>
</div>
<div class="regContent">
<form id="registerform" name="registerform" action="do.php?ac=<?=$_SCONFIG['register_action']?>&amp;<?=$url_plus?>&amp;ref" method="post">
<div class="regIndexBox">
<dl class="fieldset ">
<DT>帐号名称： </DT>
  <DD style="Z-INDEX: 100">
  <INPUT class="text text_m" id="username" name="username" onfocus="tipsUserName()" onBlur="checkUserName()" tabindex="2"> 
  <!--提示信息-->
  <DIV id="checkusername" class="tips0" style="DISPLAY: none"><I>&nbsp;</I></DIV>
  <?php if($invitearr) { ?>
  <DIV class="tips0" style="DISPLAY: none"><I>由好友<?=$_SN[$invitearr['uid']]?>邀请</I></DIV>
  <?php } ?>
  </DD>
  <DT>你的密码： </DT>
  <DD><INPUT class="password text_m" type=password name="password" id="password" onfocus="tipsPassword()" onBlur="checkPassword()" onkeyup="checkPwd(this.value);" tabindex="3"> 
  <!--提示信息-->
  <DIV style="DISPLAY: none" id="checkpassword" class="tips0"><I>&nbsp; 
  <SPAN id="chkpswd" class="pwd-none">&nbsp;</SPAN> </I></DIV></DD>
  <DT>你的姓名： </DT>
  <DD><INPUT id=name class="text text_m" name=name onfocus="tipsName()" onBlur="checkName()" tabindex="4"> 
  <!--提示信息-->
  <DIV id="checkName" class="tips0" style="DISPLAY: none"><I>&nbsp;</I></DIV>
  </DD>
  <DT>你的邮箱： </DT>
  <DD><INPUT id="email" name="email" class="text text_m" onfocus="tipsEmail()" onBlur="checkEmail()" tabindex="5"> 
  <!--提示信息-->
  <DIV id="checkEmail" class="tips0" style="DISPLAY: none"><I>&nbsp;</I></DIV>
  </DD>
  <?php if($_SCONFIG['seccode_register']) { ?>
  <?php if($_SCONFIG['questionmode']) { ?>
  <DT><LABEL for=vcode>回答问题：</LABEL> </DT>
  <DD><INPUT style="IME-MODE: disabled" id="seccode" name="seccode" class="text textVcode" maxLength=6 onBlur="checkSeccode()" tabindex="1" autocomplete="off"> <?php question(); ?>
  <!--提示信息-->
  <DIV id="checkseccode" style="DISPLAY: none" class="tips0"><I>&nbsp;</I></DIV>
  </DD>
  <?php } else { ?>
  <DT><LABEL for=vcode>验证码：</LABEL> </DT>
  <DD><INPUT style="IME-MODE: disabled" id="seccode" name="seccode" class="text textVcode" maxLength=6 onBlur="checkSeccode()" tabindex="1" autocomplete="off"> <a href="javascript:updateseccode()"><script>seccode();</script> </a>
  <!--提示信息-->
  <DIV id="checkseccode" style="DISPLAY: none" class="tips0"><I>&nbsp;</I></DIV>
  </DD>
  <?php } ?>
  <?php } ?>
  <dd>
  <div class="regBtn"><input type="hidden" name="refer" value="space.php?do=home" >
                                     <input type="submit" id="registersubmit" name="registersubmit" value="注册新用户" class="submit" onclick="<?php if($register_rule) { ?>if(!checkClause()){return false;}<?php } ?>ajaxpost('registerform', 'register');" tabindex="6" /></SPAN></SPAN></div>
  </dd>
 <?php if($register_rule) { ?>
 <dd class="regCheckBox">
<input type="checkbox" checked="checked" id="regCheck" class="checkbox"/><label for="regCheck">同意<?=$_SCONFIG['sitename']?>用户发布</label><a href="javascript:void(0)">信息协议</a><br/>
<div style="display: none;" class="regTxt" id="regTxt"><?=$register_rule?></div>
</dd>
<?php } ?>
</dl>
</div>
<input type="hidden" name="formhash" value="<?php echo formhash(); ?>" /></FORM>   
</div>
</div>
<div class="regIntS">           
  <div style="display: none;" class="regInfo" id="msnRegInfo">
   <span class="msg" id="__registerform"></span>
  </div>
   </div>

</div>
</div>
</div>
<script type="text/javascript">
<!--
$('username').focus();
var lastUserName = lastPassword = lastName = lastEmail = lastSecCode = '';
function checkUserName() {
var userName = $('username').value;
if(userName == lastUserName) {
return;
} else {
lastUserName = userName;
}
var cu = $('checkusername');
var unLen = userName.length;  
if(unLen < 4 || unLen > 15) {
warning(cu, unLen < 4 ? '帐号小于4个字符，不支持中文，不区分大小写' : '帐号超过 15 个字符，不支持中文，不区分大小写');
return false;
}
var reg = /^[0-9a-zA-Z]+$/;
        if(!reg.test(userName))
        {
        warning(cu, '很抱歉！帐号只能有字母和数字组成！');
            return false;
        }
ajaxresponse('checkusername', 'op=checkusername&username=' + (is_ie && document.charset == 'utf-8' ? encodeURIComponent(userName) : userName));
}
function tipsUserName() {
var userName = $('username').value;
if(userName == lastUserName) {
return;
} else {
lastUserName = userName;
}
var cu = $('checkusername');
var unLen = userName.length;  
if(unLen == '') {
tips(cu, '由4-15个字母或数字组成，不支持中文，不区分大小写，注册成功后不可修改。');
return false;
}
ajaxresponse('checkusername', 'op=checkusername&username=' + (is_ie && document.charset == 'utf-8' ? encodeURIComponent(userName) : userName));
}
function checkPassword(confirm) {
var password = $('password').value;
if(!confirm && password == lastPassword) {
return;
} else {
lastPassword = password;
}
var cp = $('checkpassword');
if(password.length < 6) {
warning(cp, '密码应为6~18位，你输入的少于6位！<SPAN id="chkpswd" class="pwd0">密码强度</SPAN>');
return;
}
if(password == '' || /[\'\"\\]/.test(password)) {
warning(cp, '很抱歉！请填写你的密码或密码包含非法字符');
return false;
} else {
cp.style.display = 'block';
cp.innerHTML = '<SPAN class=formCorrect></SPAN>';
cp.className = "tipsIcon";
if(!confirm) {
tipsPassword(true);
}
return true;
}
}
function tipsPassword(confirm) {
var password = $('password').value;
var cp = $('checkpassword');
if(password.length < 6) {
tips(cp, '密码应为6~18位，可包含字母、数字、下划线和减号<SPAN id="chkpswd" class="pwd0">密码强度</SPAN>');
return;
}
if(password == '') {
tips(cp, '密码应为6~18位，可包含字母、数字、下划线和减号<SPAN id="chkpswd" class="pwd0">密码强度</SPAN>');
return false;
} 

}
function checkName() {
var Name = $('name').value;
if(Name == lastName) {
return;
} else {
lastName = Name;
}
var cn = $('checkName');
var unLen = Name.length;  
if(unLen < 2 || unLen > 5) {
warning(cn, unLen < 2 ? '姓名小于2个字符' : '姓名超过 5 个字符');
return false;
}
var reg = /^[\u4e00-\u9fa5]+$/i; 
        if(!reg.test(Name))
        {
        warning(cn, '重要！请填写中文真实姓名，便于被亲朋好友找到！');
            return false;
        } else {
    cn.style.display = 'block';
cn.innerHTML = '<SPAN class=formCorrect></SPAN>';
cn.className = "tipsIcon";
    return true; 
}

}
function tipsName() {
var Name = $('name').value;
var cn = $('checkName');
var unLen = Name.length;  
if(unLen == '') {
tips(cn, '请填写<STRONG>中文真实姓名</STRONG>，便于被亲朋好友找到');
return false;
}

}
    function checkEmail() {
    var email = trim($('email').value);
        if(email == lastEmail) {
            return;
        } else {
        lastEmail = email;
        }
        var ce = $('checkEmail');
        ajaxresponse('checkEmail', 'op=checkemail&email=' + email);
    }
function tipsEmail() {
var Email = $('email').value;
var ce = $('checkEmail');
var eLen = Email.length; 
if(eLen == '') {
tips(ce, '请填写有效邮箱，在忘记密码，或者您使用邮件通知功能时，会发送邮件到该邮箱！');
return false;
}
}
function checkSeccode() {
var seccodeVerify = $('seccode').value;
var cv = $('checkSeccode');
if(seccodeVerify == lastSecCode) {
return;
} else {
lastSecCode = seccodeVerify;
}
ajaxresponse('checkseccode', 'op=checkseccode&seccode=' + (is_ie && document.charset == 'utf-8' ? encodeURIComponent(seccodeVerify) : seccodeVerify));
}

function ajaxresponse(objname, data) {
var x = new Ajax('XML', objname);
x.get('do.php?ac=<?=$_SCONFIG['register_action']?>&' + data, function(s){
var obj = $(objname);
s = trim(s);
if(s.indexOf('succeed') > -1) {
obj.style.display = 'block';
obj.innerHTML = '<SPAN class=formCorrect></SPAN>';
obj.className = "tipsIcon";
} else {
warning(obj, s);
}
});
}
function warning(obj, msg) {
obj.style.display = 'block';
obj.innerHTML = '<I>'  + msg  ;
obj.className = "tips2 tipsErr";
}
function tips(obj, msg) {

obj.style.display = 'block';
obj.innerHTML = '<I>'  + msg  ;
obj.className = "tips0";
}
function hideAlr(alrId){
        var alrObj=alrId;
        if(alrObj!=null){
        alrObj.style.display="block";
        }
    }
function checkPwd(pwd){

if (pwd == "") {
$("chkpswd").className = "pwd0";
$("chkpswd").innerHTML = "";
} else if (pwd.length < 6) {
$("chkpswd").className = "pwd0";
$("chkpswd").innerHTML = "密码强度";
} else if(!isPassword(pwd) || !/^[^%&]*$/.test(pwd)) {
$("chkpswd").className = "pwd0";
$("chkpswd").innerHTML = "";
} else {
var csint = checkStrong(pwd);
switch(csint) {
case 0:
$("chkpswd").innerHTML = "密码强度:低";
$( "chkpswd" ).className = "pwd"+(csint + 1);
break;
case 1:
$("chkpswd").innerHTML = "密码强度:中";
$( "chkpswd" ).className = "pwd"+(csint + 1);
break;
case 2:		
$("chkpswd").innerHTML = "密码强度:高";
$("chkpswd").className = "pwd"+(csint + 1);
break;
}
}
}
function isPassword(str){
if (str.length < 3) return false;
var len;
var i;
len = 0;
for (i=0;i<str.length;i++){
if (str.charCodeAt(i)>255) return false;
}
return true;
}
function charMode(iN){ 
if (iN>=48 && iN <=57) //数字 
return 1; 
if (iN>=65 && iN <=90) //大写字母 
return 2; 
if (iN>=97 && iN <=122) //小写 
return 4; 
else 
return 8; //特殊字符 
} 
//计算出当前密码当中一共有多少种模式 
function bitTotal(num){ 
modes=0; 
for (i=0;i<4;i++){ 
if (num & 1) modes++; 
num>>>=1; 
} 
return modes; 
} 

//返回密码的强度级别 
function checkStrong(pwd){ 
modes=0; 
for (i=0;i<pwd.length;i++){ 
//测试每一个字符的类别并统计一共有多少种模式. 
modes|=charMode(pwd.charCodeAt(i)); 
} 
return bitTotal(modes);
}
//-->
</script>

﻿<?php if(empty($_SGLOBAL['inajax'])) { ?>
<?php if(empty($_TPL['nosidebar'])) { ?>
<?php if($_SGLOBAL['ad']['contentbottom']) { ?><br style="line-height:0;clear:both;"/><div id="ad_contentbottom"><?php adshow('contentbottom'); ?></div><?php } ?>
</div>

<!--/mainarea-->
<div id="bottom"></div>
</div>
<!--/main-->
<?php } ?>

<div id="footer">

<p class="r_option">
<a href="javascript:;" onclick="window.scrollTo(0,0);" id="a_top" title="TOP"><img src="image/top.gif" alt="" style="padding: 5px 6px 6px;" /></a>
</p>

<?php if($_SGLOBAL['ad']['footer']) { ?>
<p style="padding:5px 0 10px 0;"><?php adshow('footer'); ?></p>
<?php } ?>

<?php if($_SCONFIG['close']) { ?>
<p style="color:blue;font-weight:bold;">
提醒：当前站点处于关闭状态
</p>
<?php } ?>
<p>
<?=$_SCONFIG['sitename']?> - 
<a href="mailto:<?=$_SCONFIG['adminemail']?>">联系我们</a>
<?php if($_SCONFIG['miibeian']) { ?> - <a  href="http://www.miibeian.gov.cn" target="_blank"><?=$_SCONFIG['miibeian']?></a><?php } ?>
</p>
<p>
Powered by <a  href="http://u.discuz.net" target="_blank"><strong>UCenter Home</strong></a> <span title="<?php echo X_RELEASE; ?>"><?php echo X_VER; ?></span>
<?php if(!empty($_SCONFIG['licensed'])) { ?><a  href="http://license.comsenz.com/?pid=7&host=<?=$_SERVER['HTTP_HOST']?>" target="_blank">Licensed</a><?php } ?>
&copy; 2001-2011 <a  href="http://www.comsenz.com" target="_blank">Comsenz Inc.</a>
</p>
<?php if($_SCONFIG['debuginfo']) { ?>
<p><?php echo debuginfo(); ?></p>
<?php } ?>
</div>
</div>
<!--/wrap-->

<?php if($_SGLOBAL['appmenu']) { ?>
<ul id="ucappmenu_menu" class="dropmenu_drop" style="display:none;">
<li><a href="<?=$_SGLOBAL['appmenu']['url']?>" title="<?=$_SGLOBAL['appmenu']['name']?>" target="_blank"><?=$_SGLOBAL['appmenu']['name']?></a></li>
<?php if(is_array($_SGLOBAL['appmenus'])) { foreach($_SGLOBAL['appmenus'] as $value) { ?>
<li><a href="<?=$value['url']?>" title="<?=$value['name']?>" target="_blank"><?=$value['name']?></a></li>
<?php } } ?>
</ul>
<?php } ?>


<?php if($_SGLOBAL['supe_uid']) { ?>
<?php if(!isset($_SCOOKIE['checkpm'])) { ?>
<script language="javascript"  type="text/javascript" src="cp.php?ac=pm&op=checknewpm&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>
<?php if(!isset($_SCOOKIE['synfriend'])) { ?>
<script language="javascript"  type="text/javascript" src="cp.php?ac=friend&op=syn&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>
<?php } ?>
<?php if(!isset($_SCOOKIE['sendmail'])) { ?>
<script language="javascript"  type="text/javascript" src="do.php?ac=sendmail&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>

<?php if($_SGLOBAL['ad']['couplet']) { ?>
<script language="javascript" type="text/javascript" src="source/script_couplet.js"></script>
<div id="uch_couplet" style="z-index: 10; position: absolute; display:none">
<div id="couplet_left" style="position: absolute; left: 2px; top: 60px; overflow: hidden;">
<div style="position: relative; top: 25px; margin:0.5em;" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('uch_couplet');"><img src="image/advclose.gif"></div>
<?php adshow('couplet'); ?>
</div>
<div id="couplet_rigth" style="position: absolute; right: 2px; top: 60px; overflow: hidden;">
<div style="position: relative; top: 25px; margin:0.5em;" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('uch_couplet');"><img src="image/advclose.gif"></div>
<?php adshow('couplet'); ?>
</div>
<script type="text/javascript">
lsfloatdiv('uch_couplet', 0, 0, '', 0).floatIt();
</script>
</div>
<?php } ?>
<?php if($_SCOOKIE['reward_log']) { ?>
<script type="text/javascript">
showreward();
</script>
<?php } ?>
</body>
</html>
<?php } ?><?php ob_out();?>