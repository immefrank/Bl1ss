<?php if(!defined('IN_UCHOME')) exit('Access Denied');?><?php subtplcheck('template/default/space_mtag_member|template/default/header|template/default/footer', '1303264939', 'template/default/space_mtag_member');?>﻿<?php $_TPL['titles'] = array($mtag['tagname'], $mtag['title'], '成员'); ?>
﻿<?php if(empty($_SGLOBAL['inajax'])) { ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=<?=$_SC['charset']?>" />
<meta http-equiv="x-ua-compatible" content="ie=7" />
<title><?php if($_TPL['titles']) { ?><?php if(is_array($_TPL['titles'])) { foreach($_TPL['titles'] as $value) { ?><?php if($value) { ?><?=$value?> - <?php } ?><?php } } ?><?php } ?><?php if($_SN[$space['uid']]) { ?><?=$_SN[$space['uid']]?> - <?php } ?><?=$_SCONFIG['sitename']?></title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<script language="javascript" type="text/javascript" src="source/script_jquery.js"></script>
<script language="javascript" type="text/javascript" src="source/script_cookie.js"></script>
<script language="javascript" type="text/javascript" src="source/script_common.js"></script>
<script language="javascript" type="text/javascript" src="source/script_menu.js"></script>
<script language="javascript" type="text/javascript" src="source/script_ajax.js"></script>
<script language="javascript" type="text/javascript" src="source/script_face.js"></script>
<script language="javascript" type="text/javascript" src="source/script_manage.js"></script>
<link id="skinc" href="/template/default/style.css" rel="stylesheet" type="text/css" />
<?php if($_TPL['css']) { ?>
<link id="skinc" href="/template/default/<?=$_TPL['css']?>.css" rel="stylesheet" type="text/css" />
<?php } ?>
<?php if(!empty($_SGLOBAL['space_theme'])) { ?>
<link id="skinc" href="/theme/<?=$_SGLOBAL['space_theme']?>/style.css" rel="stylesheet" type="text/css" />
<?php } elseif($_SCONFIG['template'] != 'default') { ?>
<link id="skinc" href="/template/<?=$_SCONFIG['template']?>/style.css" rel="stylesheet" type="text/css" />
<?php } ?>

<style type="text/css">
<?php if(!empty($_SGLOBAL['space_css'])) { ?>
<?=$_SGLOBAL['space_css']?> 
<?php } ?>
</style>
<link rel="shortcut icon" href="image/favicon.ico" />
<link rel="edituri" type="application/rsd+xml" title="rsd" href="xmlrpc.php?rsd=<?=$space['uid']?>" />

</head>
<body>
<div id="append_parent"></div>
<div id="ajaxwaitid"></div>
<div id="header">
<div class="wp">
<div id="logo"></div>

<div id="nav">
<div>
<?php if($_SGLOBAL['supe_uid']) { ?>
<a href="space.php">myspace</a>
<a href="cp.php?ac=common&op=logout&uhash=<?=$_SGLOBAL['uhash']?>">logout</a>
<?php } else { ?>
<a href="do.php?ac=<?=$_SCONFIG['login_action']?>">Share</a> | 
<a href="do.php?ac=<?=$_SCONFIG['login_action']?>">Login</a> | 
<a href="do.php?ac=<?=$_SCONFIG['register_action']?>">Register</a>
<?php } ?>
</div>
<div id="navitem">
<a href="network.php"><img src="/template/default/i/nav_home.jpg" /></a>
<a href="space.php?act=home&view=all"><img src="/template/default/i/nav_comm.jpg" /></a>
<a href="books.php"><img src="/template/default/i/nav_books.jpg" /></a>
<a href="movies.php"><img src="/template/default/i/nav_mov.jpg" /></a>
<a href="music.php"><img src="/template/default/i/nav_mus.jpg" /></a>
<a href="arts.php"><img src="/template/default/i/nav_art.jpg" /></a>
</div>
</div>
<div class="cl"></div>
</div>
</div>

<div id="wrap">

<?php if(empty($_TPL['nosidebar'])) { ?>
<div id="main">
<div id="app_sidebar">
<?php if($_SGLOBAL['supe_uid']) { ?>
    <h2>Personal Center</h2>
<ul class="app_list" id="default_userapp">
<li><a href="space.php?do=doing"><span class="icon i-app24 i-app24-status"></span>Fresh things</a></li>
<li><a href="space.php?do=album"><span class="icon i-app24 i-app24-album"></span>Albums</a><em><a href="cp.php?ac=upload" class="gray">upload</a></em></li>
<li><a href="space.php?do=blog"><span class="icon i-app24 i-app24-blog"></span>WebLog</a><em><a href="cp.php?ac=blog" class="gray">issue</a></em></li>
</ul>

            <h2>互动中心</h2>
<ul class="app_list" id="default_userapp">
<li><a href="space.php?do=poll"><span class="icon i-app24 i-app24-vote"></span>投票</a><em><a href="cp.php?ac=poll" class="gray">发起</a></em></li>
<li><a href="space.php?do=mtag"><span class="icon i-app24 i-app24-thread"></span>群组</a><em><a href="cp.php?ac=thread" class="gray">话题</a></em></li>
<li><a href="space.php?do=event"><span class="icon i-app24 i-app24-event"></span>活动</a><em><a href="cp.php?ac=event" class="gray">发起</a></em></li>
<li><a href="space.php?do=share"><span class="icon i-app24 i-app24-share"></span>分享</a></li>
<li><a href="space.php?do=topic"><span class="icon i-app24 i-app24-hot"></span>专题</a></li>
</ul>

           

<div id="appbarActions">
<?php if($_SCONFIG['my_status']) { ?><a class="act a-manage" href="cp.php?ac=userapp&op=menu" >设置</a>&nbsp;<?php } ?><?php if($_SGLOBAL['my_menu_more']) { ?><a href="javascript:;" id="a_app_more" onclick="userapp_open();" class="off">展开</a><?php } ?>
            </div>

<?php } else { ?>
<div class="bar_text">
<form id="loginform" name="loginform" action="do.php?ac=<?=$_SCONFIG['login_action']?>&ref" method="post">
<input type="hidden" name="formhash" value="<?php echo formhash(); ?>" />
<p><h2>登陆更精彩...</h2></p>
<p>账号:</p>
<p><input type="text" name="username" id="username" class="t_input" size="15" value="" /></p>
<p>密码:</p>
<p><input type="password" name="password" id="password" class="t_input" size="15" value="" /></p>
<p ><input type="checkbox" id="cookietime" name="cookietime" value="315360000" checked /><label for="cookietime">记住我</label></p>
<p>
<input type="submit" id="loginsubmit" name="loginsubmit" value="登录" class="submit" />
<input type="button" name="regbutton" value="注册" class="button" onclick="urlto('do.php?ac=<?=$_SCONFIG['register_action']?>');">
</p>
</form>

</div>
<?php } ?>
</div>

<div id="mainarea">

<?php if($_SGLOBAL['ad']['contenttop']) { ?><div id="ad_contenttop"><?php adshow('contenttop'); ?></div><?php } ?>
<?php } ?>

<?php } ?>


<div class="appHead">
<h2>
<span title="群组" class="icon i-app24 i-app24-feedback"></span><a href="space.php?do=mtag&id=<?=$mtag['fieldid']?>"><?=$mtag['title']?></a> -
<a href="space.php?do=mtag&tagid=<?=$mtag['tagid']?>"><?=$mtag['tagname']?></a>
</h2>
</div>
<div class="appBody">
<div class="tabs">
<ul>
<li><a href="space.php?do=mtag&tagid=<?=$mtag['tagid']?>"><span>首页</span></a></li>
<li><a href="space.php?do=mtag&tagid=<?=$mtag['tagid']?>&view=list"><span>讨论区</span></a></li>
<li><a href="space.php?do=mtag&tagid=<?=$mtag['tagid']?>&view=digest"><span>精华区</span></a></li>
<?php if($eventnum) { ?>
<li><a href="space.php?do=mtag&tagid=<?=$mtag['tagid']?>&view=event"><span>群组活动</span></a></li>
<?php } ?>
<li class="active"><a href="space.php?do=mtag&tagid=<?=$mtag['tagid']?>&view=member"><span>成员列表</span></a></li>
<?php if($mtag['allowpost']) { ?><li class="orphan"><a href="cp.php?ac=thread&tagid=<?=$tagid?>"><font class="act a-add">发起新话题</font></a></li><?php } ?>
</ul>
</div>

<script>
function searchFriend() {
$('searchform').submit();
}
</script>

<div class="h_status">
<form name="searchform" id="searchform" method="get" action="space.php?do=mtag&tagid=<?=$mtag['tagid']?>&view=member">
<table cellpadding="0" cellspacing="0" width="100%">
<tr>
<td>
成员列表
<?php if($mtag['grade']>=8) { ?><span class="pipe">|</span><a href="cp.php?ac=mtag&op=manage&tagid=<?=$mtag['tagid']?>&subop=members">成员批量管理</a><?php } ?>
</td>
<td align="right">
<table cellspacing="0" cellpadding="0">
<tr>
<td style="padding: 0;"><input type="text" id="key" name="key" value="搜索成员" onfocus="if(this.value=='搜索成员')this.value='';" class="t_input" tabindex="1" style="width: 160px; border-right: none;" /></td>
<td style="padding: 0;"><a href="javascript:searchFriend();"><img src="image/search_btn.gif" alt="搜索" /></a></td>
</tr>
</table>
</td>
</tr>
</table>
<input type="hidden" name="do" value="mtag">
<input type="hidden" name="tagid" value="<?=$mtag['tagid']?>">
<input type="hidden" name="view" value="member">
<input type="hidden" name="formhash" value="<?php echo formhash(); ?>" /></form>
</div>

<div class="appContent">
<!--投票列表 begin-->

 <?php if($list) { ?>
<ul class="avStarList">	
<?php if(is_array($list)) { foreach($list as $key => $value) { ?>
<li class="avStarItem">
<div class="avStarAvatar"><a href="space.php?uid=<?=$value['uid']?>"><span class="avatar-48<?php if($value['grade']==1) { ?> avatar-48-star<?php } ?>"><?php echo avatar($value[uid],small); ?></span></a> </div>
<div class="avStarAction" id="mtag_member_<?=$value['uid']?>">
<?php if($mtag['grade']>=8) { ?><a href="cp.php?ac=mtag&op=manage&subop=member&tagid=<?=$mtag['tagid']?>&uid=<?=$value['uid']?>" id="a_mod_<?=$key?>" onclick="ajaxmenu(event, this.id, 1)" class="r_option" style="padding-left:0.5em;">管理该成员</a><br/><?php } ?>
<?php if($value['grade']==9) { ?><a class="act a-Groupmast" href="javascript:void(0);">群主</a>
<?php } elseif($value['grade']==8) { ?><a class="act a-Groupmast2" href="javascript:void(0);">管理</a>
<?php } elseif($value['grade']==1) { ?><a class="act a-Groupatar" href="javascript:void(0);">明星</a>
<?php } elseif($value['grade']==-1) { ?><a class="act a-privacy" href="javascript:void(0);">禁言</a>
<?php } elseif($value['grade']==-2) { ?><a class="act a-star-unfollow" href="javascript:void(0);">待审</a>
<?php } else { ?><a class="act a-Groupp" href="javascript:void(0);">普通</a>
<?php } ?>
</div>
<div class="avStarInfo">
<h4><a href="space.php?uid=<?=$value['uid']?>"><?=$_SN[$value['uid']]?></a><?php if($value['videostatus']) { ?><span class="icon i-famousStar" title="已通过视频认证"/><?php } ?></h4>
<p>Hi~<?php if($value['resideprovince'] || $value['residecity']) { ?><?=$_SN[$value['uid']]?>来自<a href="cp.php?ac=friend&op=search&resideprovince=<?=$value['p']?>&residecity=&searchmode=1"><?=$value['resideprovince']?></a> <a href="cp.php?ac=friend&op=search&resideprovince=<?=$value['p']?>&residecity=<?=$value['c']?>&searchmode=1"><?=$value['residecity']?></a>，<?php } ?>你可以
<a href="cp.php?ac=friend&op=add&uid=<?=$value['uid']?>" id="a_friend_<?=$key?>" onclick="ajaxmenu(event, this.id, 1)">加为好友</a>
            <span class="pipe">|</span><a href="cp.php?ac=pm&uid=<?=$value['uid']?>" id="a_pm_<?=$key?>" onclick="ajaxmenu(event, this.id, 1)">发短消息</a>
            <span class="pipe">|</span><a href="cp.php?ac=poke&op=send&uid=<?=$value['uid']?>" id="a_poke_<?=$key?>" onclick="ajaxmenu(event, this.id, 1)">打个招呼</a>&nbsp;给他<?php if($value['note']) { ?>，他最近的心情<?=$value['note']?>。<?php } ?></p></div>
</li>
<?php } } ?>
</ul>
 <div class="pager">
 <div class="pager"><?=$multi?></div>
 </div>
 <?php } else { ?>
                                     <div class="listEmpty">没有找到可浏览的成员信息。</div>
 <?php } ?>
<!--投票列表 end-->
 </div>


</div>
﻿<?php if(empty($_SGLOBAL['inajax'])) { ?>
<?php if(empty($_TPL['nosidebar'])) { ?>
<?php if($_SGLOBAL['ad']['contentbottom']) { ?><br style="line-height:0;clear:both;"/><div id="ad_contentbottom"><?php adshow('contentbottom'); ?></div><?php } ?>
</div>

<!--/mainarea-->
<div id="bottom"></div>
</div>
<!--/main-->
<?php } ?>

<div id="footer">

<p class="r_option">
<a href="javascript:;" onclick="window.scrollTo(0,0);" id="a_top" title="TOP"><img src="image/top.gif" alt="" style="padding: 5px 6px 6px;" /></a>
</p>

<?php if($_SGLOBAL['ad']['footer']) { ?>
<p style="padding:5px 0 10px 0;"><?php adshow('footer'); ?></p>
<?php } ?>

<?php if($_SCONFIG['close']) { ?>
<p style="color:blue;font-weight:bold;">
提醒：当前站点处于关闭状态
</p>
<?php } ?>
<p>
<?=$_SCONFIG['sitename']?> - 
<a href="mailto:<?=$_SCONFIG['adminemail']?>">联系我们</a>
<?php if($_SCONFIG['miibeian']) { ?> - <a  href="http://www.miibeian.gov.cn" target="_blank"><?=$_SCONFIG['miibeian']?></a><?php } ?>
</p>
<p>
Powered by <a  href="http://u.discuz.net" target="_blank"><strong>UCenter Home</strong></a> <span title="<?php echo X_RELEASE; ?>"><?php echo X_VER; ?></span>
<?php if(!empty($_SCONFIG['licensed'])) { ?><a  href="http://license.comsenz.com/?pid=7&host=<?=$_SERVER['HTTP_HOST']?>" target="_blank">Licensed</a><?php } ?>
&copy; 2001-2011 <a  href="http://www.comsenz.com" target="_blank">Comsenz Inc.</a>
</p>
<?php if($_SCONFIG['debuginfo']) { ?>
<p><?php echo debuginfo(); ?></p>
<?php } ?>
</div>
</div>
<!--/wrap-->

<?php if($_SGLOBAL['appmenu']) { ?>
<ul id="ucappmenu_menu" class="dropmenu_drop" style="display:none;">
<li><a href="<?=$_SGLOBAL['appmenu']['url']?>" title="<?=$_SGLOBAL['appmenu']['name']?>" target="_blank"><?=$_SGLOBAL['appmenu']['name']?></a></li>
<?php if(is_array($_SGLOBAL['appmenus'])) { foreach($_SGLOBAL['appmenus'] as $value) { ?>
<li><a href="<?=$value['url']?>" title="<?=$value['name']?>" target="_blank"><?=$value['name']?></a></li>
<?php } } ?>
</ul>
<?php } ?>


<?php if($_SGLOBAL['supe_uid']) { ?>
<?php if(!isset($_SCOOKIE['checkpm'])) { ?>
<script language="javascript"  type="text/javascript" src="cp.php?ac=pm&op=checknewpm&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>
<?php if(!isset($_SCOOKIE['synfriend'])) { ?>
<script language="javascript"  type="text/javascript" src="cp.php?ac=friend&op=syn&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>
<?php } ?>
<?php if(!isset($_SCOOKIE['sendmail'])) { ?>
<script language="javascript"  type="text/javascript" src="do.php?ac=sendmail&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>

<?php if($_SGLOBAL['ad']['couplet']) { ?>
<script language="javascript" type="text/javascript" src="source/script_couplet.js"></script>
<div id="uch_couplet" style="z-index: 10; position: absolute; display:none">
<div id="couplet_left" style="position: absolute; left: 2px; top: 60px; overflow: hidden;">
<div style="position: relative; top: 25px; margin:0.5em;" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('uch_couplet');"><img src="image/advclose.gif"></div>
<?php adshow('couplet'); ?>
</div>
<div id="couplet_rigth" style="position: absolute; right: 2px; top: 60px; overflow: hidden;">
<div style="position: relative; top: 25px; margin:0.5em;" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('uch_couplet');"><img src="image/advclose.gif"></div>
<?php adshow('couplet'); ?>
</div>
<script type="text/javascript">
lsfloatdiv('uch_couplet', 0, 0, '', 0).floatIt();
</script>
</div>
<?php } ?>
<?php if($_SCOOKIE['reward_log']) { ?>
<script type="text/javascript">
showreward();
</script>
<?php } ?>
</body>
</html>
<?php } ?>
<?php ob_out();?>