<?php if(!defined('IN_UCHOME')) exit('Access Denied');?><?php subtplcheck('template/default/space_tag_view|template/default/header|template/default/footer', '1303363058', 'template/default/space_tag_view');?>﻿<?php $_TPL['titles'] = array($tag['tagname'], '标签'); ?>
﻿<?php if(empty($_SGLOBAL['inajax'])) { ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=<?=$_SC['charset']?>" />
<meta http-equiv="x-ua-compatible" content="ie=7" />
<title><?php if($_TPL['titles']) { ?><?php if(is_array($_TPL['titles'])) { foreach($_TPL['titles'] as $value) { ?><?php if($value) { ?><?=$value?> - <?php } ?><?php } } ?><?php } ?><?php if($_SN[$space['uid']]) { ?><?=$_SN[$space['uid']]?> - <?php } ?><?=$_SCONFIG['sitename']?></title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<script language="javascript" type="text/javascript" src="source/script_jquery.js"></script>
<script language="javascript" type="text/javascript" src="source/script_cookie.js"></script>
<script language="javascript" type="text/javascript" src="source/script_common.js"></script>
<script language="javascript" type="text/javascript" src="source/script_menu.js"></script>
<script language="javascript" type="text/javascript" src="source/script_ajax.js"></script>
<script language="javascript" type="text/javascript" src="source/script_face.js"></script>
<script language="javascript" type="text/javascript" src="source/script_manage.js"></script>
<link id="skinc" href="/template/default/style.css" rel="stylesheet" type="text/css" />
<?php if($_TPL['css']) { ?>
<link id="skinc" href="/template/default/<?=$_TPL['css']?>.css" rel="stylesheet" type="text/css" />
<?php } ?>
<?php if(!empty($_SGLOBAL['space_theme'])) { ?>
<link id="skinc" href="/theme/<?=$_SGLOBAL['space_theme']?>/style.css" rel="stylesheet" type="text/css" />
<?php } elseif($_SCONFIG['template'] != 'default') { ?>
<link id="skinc" href="/template/<?=$_SCONFIG['template']?>/style.css" rel="stylesheet" type="text/css" />
<?php } ?>

<style type="text/css">
<?php if(!empty($_SGLOBAL['space_css'])) { ?>
<?=$_SGLOBAL['space_css']?> 
<?php } ?>
</style>
<link rel="shortcut icon" href="image/favicon.ico" />
<link rel="edituri" type="application/rsd+xml" title="rsd" href="xmlrpc.php?rsd=<?=$space['uid']?>" />

</head>
<body>
<div id="append_parent"></div>
<div id="ajaxwaitid"></div>
<div id="header">
<div class="wp">
<div id="logo"></div>

<div id="nav">
<div>
<?php if($_SGLOBAL['supe_uid']) { ?>
<a href="space.php">myspace</a>
<a href="cp.php?ac=common&op=logout&uhash=<?=$_SGLOBAL['uhash']?>">logout</a>
<?php } else { ?>
<a href="do.php?ac=<?=$_SCONFIG['login_action']?>">Share</a> | 
<a href="do.php?ac=<?=$_SCONFIG['login_action']?>">Login</a> | 
<a href="do.php?ac=<?=$_SCONFIG['register_action']?>">Register</a>
<?php } ?>
</div>
<div id="navitem">
<a href="network.php"><img src="/template/default/i/nav_home.jpg" /></a>
<a href="space.php?act=home&view=all"><img src="/template/default/i/nav_comm.jpg" /></a>
<a href="books.php"><img src="/template/default/i/nav_books.jpg" /></a>
<a href="movies.php"><img src="/template/default/i/nav_mov.jpg" /></a>
<a href="music.php"><img src="/template/default/i/nav_mus.jpg" /></a>
<a href="arts.php"><img src="/template/default/i/nav_art.jpg" /></a>
</div>
</div>
<div class="cl"></div>
</div>
</div>

<div id="wrap">

<?php if(empty($_TPL['nosidebar'])) { ?>
<div id="main">
<div id="app_sidebar">
<?php if($_SGLOBAL['supe_uid']) { ?>
    <h2>Personal Center</h2>
<ul class="app_list" id="default_userapp">
<li><a href="space.php?do=doing"><span class="icon i-app24 i-app24-status"></span>Fresh things</a></li>
<li><a href="space.php?do=album"><span class="icon i-app24 i-app24-album"></span>Albums</a><em><a href="cp.php?ac=upload" class="gray">upload</a></em></li>
<li><a href="space.php?do=blog"><span class="icon i-app24 i-app24-blog"></span>WebLog</a><em><a href="cp.php?ac=blog" class="gray">issue</a></em></li>
</ul>

            <h2>互动中心</h2>
<ul class="app_list" id="default_userapp">
<li><a href="space.php?do=poll"><span class="icon i-app24 i-app24-vote"></span>投票</a><em><a href="cp.php?ac=poll" class="gray">发起</a></em></li>
<li><a href="space.php?do=mtag"><span class="icon i-app24 i-app24-thread"></span>群组</a><em><a href="cp.php?ac=thread" class="gray">话题</a></em></li>
<li><a href="space.php?do=event"><span class="icon i-app24 i-app24-event"></span>活动</a><em><a href="cp.php?ac=event" class="gray">发起</a></em></li>
<li><a href="space.php?do=share"><span class="icon i-app24 i-app24-share"></span>分享</a></li>
<li><a href="space.php?do=topic"><span class="icon i-app24 i-app24-hot"></span>专题</a></li>
</ul>

           

<div id="appbarActions">
<?php if($_SCONFIG['my_status']) { ?><a class="act a-manage" href="cp.php?ac=userapp&op=menu" >设置</a>&nbsp;<?php } ?><?php if($_SGLOBAL['my_menu_more']) { ?><a href="javascript:;" id="a_app_more" onclick="userapp_open();" class="off">展开</a><?php } ?>
            </div>

<?php } else { ?>
<div class="bar_text">
<form id="loginform" name="loginform" action="do.php?ac=<?=$_SCONFIG['login_action']?>&ref" method="post">
<input type="hidden" name="formhash" value="<?php echo formhash(); ?>" />
<p><h2>登陆更精彩...</h2></p>
<p>账号:</p>
<p><input type="text" name="username" id="username" class="t_input" size="15" value="" /></p>
<p>密码:</p>
<p><input type="password" name="password" id="password" class="t_input" size="15" value="" /></p>
<p ><input type="checkbox" id="cookietime" name="cookietime" value="315360000" checked /><label for="cookietime">记住我</label></p>
<p>
<input type="submit" id="loginsubmit" name="loginsubmit" value="登录" class="submit" />
<input type="button" name="regbutton" value="注册" class="button" onclick="urlto('do.php?ac=<?=$_SCONFIG['register_action']?>');">
</p>
</form>

</div>
<?php } ?>
</div>

<div id="mainarea">

<?php if($_SGLOBAL['ad']['contenttop']) { ?><div id="ad_contenttop"><?php adshow('contenttop'); ?></div><?php } ?>
<?php } ?>

<?php } ?>

<div class="appHead">
<h2><span title="标签(Tag)" class="icon i-app24 i-app24-paper"></span>标签 - <?=$tag['tagname']?> (<?=$tag['blognum']?> 篇日志)</h2>
</div>
<div class="appBody">
<div class="appContent">
<div class="tabs">
<div style="padding-left: 8px;" class="option shareOption"><a href="cp.php?ac=share&type=tag&id=<?=$tag['tagid']?>" id="a_share" onclick="ajaxmenu(event, this.id, 1)" class="tab_share">分享</a></div>
<ul>
<li class="active"><a href="space.php?do=tag&id=<?=$tag['tagid']?>"><span>日志列表</span></a></li>
<li><a href="space.php?do=tag"><span>返回标签列表</span></a></li>
</ul>
</div>

<div class="topic_list">
<table cellspacing="0" cellpadding="0" class="infotable">
<thead>
<tr>
<td class="subject">标题</td>
<td class="author">作者(回复数)</td>
<td class="lastpost">发布时间</td>
</tr>
</thead>
<?php if(is_array($list)) { foreach($list as $key => $value) { ?>
<tr<?php if($key%2==1) { ?> class="alt"<?php } ?>>
<td class="subject"><a href="space.php?uid=<?=$value['uid']?>&do=blog&id=<?=$value['blogid']?>" target="_blank"><?=$value['subject']?></a></td>
<td class="author"><a href="space.php?uid=<?=$value['uid']?>"><?=$_SN[$value['uid']]?></a><em>(<?=$value['replynum']?>)</em></td>
<td class="lastpost"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></td>
</tr>
<?php } } ?>
</table>

<?php if($prinum) { ?>
<div class="notice">本页有 <?=$prinum?> 篇日志因隐私设置而隐藏</div>
<?php } ?>

<div class="page"><?=$multi?></div>
</div>
</div></div>
﻿<?php if(empty($_SGLOBAL['inajax'])) { ?>
<?php if(empty($_TPL['nosidebar'])) { ?>
<?php if($_SGLOBAL['ad']['contentbottom']) { ?><br style="line-height:0;clear:both;"/><div id="ad_contentbottom"><?php adshow('contentbottom'); ?></div><?php } ?>
</div>

<!--/mainarea-->
<div id="bottom"></div>
</div>
<!--/main-->
<?php } ?>

<div id="footer">

<p class="r_option">
<a href="javascript:;" onclick="window.scrollTo(0,0);" id="a_top" title="TOP"><img src="image/top.gif" alt="" style="padding: 5px 6px 6px;" /></a>
</p>

<?php if($_SGLOBAL['ad']['footer']) { ?>
<p style="padding:5px 0 10px 0;"><?php adshow('footer'); ?></p>
<?php } ?>

<?php if($_SCONFIG['close']) { ?>
<p style="color:blue;font-weight:bold;">
提醒：当前站点处于关闭状态
</p>
<?php } ?>
<p>
<?=$_SCONFIG['sitename']?> - 
<a href="mailto:<?=$_SCONFIG['adminemail']?>">联系我们</a>
<?php if($_SCONFIG['miibeian']) { ?> - <a  href="http://www.miibeian.gov.cn" target="_blank"><?=$_SCONFIG['miibeian']?></a><?php } ?>
</p>
<p>
Powered by <a  href="http://u.discuz.net" target="_blank"><strong>UCenter Home</strong></a> <span title="<?php echo X_RELEASE; ?>"><?php echo X_VER; ?></span>
<?php if(!empty($_SCONFIG['licensed'])) { ?><a  href="http://license.comsenz.com/?pid=7&host=<?=$_SERVER['HTTP_HOST']?>" target="_blank">Licensed</a><?php } ?>
&copy; 2001-2011 <a  href="http://www.comsenz.com" target="_blank">Comsenz Inc.</a>
</p>
<?php if($_SCONFIG['debuginfo']) { ?>
<p><?php echo debuginfo(); ?></p>
<?php } ?>
</div>
</div>
<!--/wrap-->

<?php if($_SGLOBAL['appmenu']) { ?>
<ul id="ucappmenu_menu" class="dropmenu_drop" style="display:none;">
<li><a href="<?=$_SGLOBAL['appmenu']['url']?>" title="<?=$_SGLOBAL['appmenu']['name']?>" target="_blank"><?=$_SGLOBAL['appmenu']['name']?></a></li>
<?php if(is_array($_SGLOBAL['appmenus'])) { foreach($_SGLOBAL['appmenus'] as $value) { ?>
<li><a href="<?=$value['url']?>" title="<?=$value['name']?>" target="_blank"><?=$value['name']?></a></li>
<?php } } ?>
</ul>
<?php } ?>


<?php if($_SGLOBAL['supe_uid']) { ?>
<?php if(!isset($_SCOOKIE['checkpm'])) { ?>
<script language="javascript"  type="text/javascript" src="cp.php?ac=pm&op=checknewpm&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>
<?php if(!isset($_SCOOKIE['synfriend'])) { ?>
<script language="javascript"  type="text/javascript" src="cp.php?ac=friend&op=syn&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>
<?php } ?>
<?php if(!isset($_SCOOKIE['sendmail'])) { ?>
<script language="javascript"  type="text/javascript" src="do.php?ac=sendmail&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>

<?php if($_SGLOBAL['ad']['couplet']) { ?>
<script language="javascript" type="text/javascript" src="source/script_couplet.js"></script>
<div id="uch_couplet" style="z-index: 10; position: absolute; display:none">
<div id="couplet_left" style="position: absolute; left: 2px; top: 60px; overflow: hidden;">
<div style="position: relative; top: 25px; margin:0.5em;" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('uch_couplet');"><img src="image/advclose.gif"></div>
<?php adshow('couplet'); ?>
</div>
<div id="couplet_rigth" style="position: absolute; right: 2px; top: 60px; overflow: hidden;">
<div style="position: relative; top: 25px; margin:0.5em;" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('uch_couplet');"><img src="image/advclose.gif"></div>
<?php adshow('couplet'); ?>
</div>
<script type="text/javascript">
lsfloatdiv('uch_couplet', 0, 0, '', 0).floatIt();
</script>
</div>
<?php } ?>
<?php if($_SCOOKIE['reward_log']) { ?>
<script type="text/javascript">
showreward();
</script>
<?php } ?>
</body>
</html>
<?php } ?>
<?php ob_out();?>