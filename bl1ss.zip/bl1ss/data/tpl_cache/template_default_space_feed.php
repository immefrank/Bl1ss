<?php if(!defined('IN_UCHOME')) exit('Access Denied');?><?php subtplcheck('template/default/space_feed|template/default/header|template/default/space_status|template/default/space_menu|template/default/space_feed_li|template/default/space_feed_li|template/default/footer', '1303230747', 'template/default/space_feed');?>﻿<?php if(empty($_TPL['getmore'])) { ?>	
<?php $_TPL['titles'] = array('首页'); ?>
﻿<?php if(empty($_SGLOBAL['inajax'])) { ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=<?=$_SC['charset']?>" />
<meta http-equiv="x-ua-compatible" content="ie=7" />
<title><?php if($_TPL['titles']) { ?><?php if(is_array($_TPL['titles'])) { foreach($_TPL['titles'] as $value) { ?><?php if($value) { ?><?=$value?> - <?php } ?><?php } } ?><?php } ?><?php if($_SN[$space['uid']]) { ?><?=$_SN[$space['uid']]?> - <?php } ?><?=$_SCONFIG['sitename']?></title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<script language="javascript" type="text/javascript" src="source/script_jquery.js"></script>
<script language="javascript" type="text/javascript" src="source/script_cookie.js"></script>
<script language="javascript" type="text/javascript" src="source/script_common.js"></script>
<script language="javascript" type="text/javascript" src="source/script_menu.js"></script>
<script language="javascript" type="text/javascript" src="source/script_ajax.js"></script>
<script language="javascript" type="text/javascript" src="source/script_face.js"></script>
<script language="javascript" type="text/javascript" src="source/script_manage.js"></script>
<link id="skinc" href="/template/default/style.css" rel="stylesheet" type="text/css" />
<?php if($_TPL['css']) { ?>
<link id="skinc" href="/template/default/<?=$_TPL['css']?>.css" rel="stylesheet" type="text/css" />
<?php } ?>
<?php if(!empty($_SGLOBAL['space_theme'])) { ?>
<link id="skinc" href="/theme/<?=$_SGLOBAL['space_theme']?>/style.css" rel="stylesheet" type="text/css" />
<?php } elseif($_SCONFIG['template'] != 'default') { ?>
<link id="skinc" href="/template/<?=$_SCONFIG['template']?>/style.css" rel="stylesheet" type="text/css" />
<?php } ?>

<style type="text/css">
<?php if(!empty($_SGLOBAL['space_css'])) { ?>
<?=$_SGLOBAL['space_css']?> 
<?php } ?>
</style>
<link rel="shortcut icon" href="image/favicon.ico" />
<link rel="edituri" type="application/rsd+xml" title="rsd" href="xmlrpc.php?rsd=<?=$space['uid']?>" />

</head>
<body>
<div id="append_parent"></div>
<div id="ajaxwaitid"></div>
<div id="header">
<div class="wp">
<div id="logo"></div>

<div id="nav">
<div>
<?php if($_SGLOBAL['supe_uid']) { ?>
<a href="space.php">myspace</a>
<a href="cp.php?ac=common&op=logout&uhash=<?=$_SGLOBAL['uhash']?>">logout</a>
<?php } else { ?>
<a href="do.php?ac=<?=$_SCONFIG['login_action']?>">Share</a> | 
<a href="do.php?ac=<?=$_SCONFIG['login_action']?>">Login</a> | 
<a href="do.php?ac=<?=$_SCONFIG['register_action']?>">Register</a>
<?php } ?>
</div>
<div id="navitem">
<a href="network.php"><img src="/template/default/i/nav_home.jpg" /></a>
<a href="space.php?act=home&view=all"><img src="/template/default/i/nav_comm.jpg" /></a>
<a href="books.php"><img src="/template/default/i/nav_books.jpg" /></a>
<a href="movies.php"><img src="/template/default/i/nav_mov.jpg" /></a>
<a href="music.php"><img src="/template/default/i/nav_mus.jpg" /></a>
<a href="arts.php"><img src="/template/default/i/nav_art.jpg" /></a>
</div>
</div>
<div class="cl"></div>
</div>
</div>

<div id="wrap">

<?php if(empty($_TPL['nosidebar'])) { ?>
<div id="main">
<div id="app_sidebar">
<?php if($_SGLOBAL['supe_uid']) { ?>
    <h2>Personal Center</h2>
<ul class="app_list" id="default_userapp">
<li><a href="space.php?do=doing"><span class="icon i-app24 i-app24-status"></span>Fresh things</a></li>
<li><a href="space.php?do=album"><span class="icon i-app24 i-app24-album"></span>Albums</a><em><a href="cp.php?ac=upload" class="gray">upload</a></em></li>
<li><a href="space.php?do=blog"><span class="icon i-app24 i-app24-blog"></span>WebLog</a><em><a href="cp.php?ac=blog" class="gray">issue</a></em></li>
</ul>

            <h2>互动中心</h2>
<ul class="app_list" id="default_userapp">
<li><a href="space.php?do=poll"><span class="icon i-app24 i-app24-vote"></span>投票</a><em><a href="cp.php?ac=poll" class="gray">发起</a></em></li>
<li><a href="space.php?do=mtag"><span class="icon i-app24 i-app24-thread"></span>群组</a><em><a href="cp.php?ac=thread" class="gray">话题</a></em></li>
<li><a href="space.php?do=event"><span class="icon i-app24 i-app24-event"></span>活动</a><em><a href="cp.php?ac=event" class="gray">发起</a></em></li>
<li><a href="space.php?do=share"><span class="icon i-app24 i-app24-share"></span>分享</a></li>
<li><a href="space.php?do=topic"><span class="icon i-app24 i-app24-hot"></span>专题</a></li>
</ul>

           

<div id="appbarActions">
<?php if($_SCONFIG['my_status']) { ?><a class="act a-manage" href="cp.php?ac=userapp&op=menu" >设置</a>&nbsp;<?php } ?><?php if($_SGLOBAL['my_menu_more']) { ?><a href="javascript:;" id="a_app_more" onclick="userapp_open();" class="off">展开</a><?php } ?>
            </div>

<?php } else { ?>
<div class="bar_text">
<form id="loginform" name="loginform" action="do.php?ac=<?=$_SCONFIG['login_action']?>&ref" method="post">
<input type="hidden" name="formhash" value="<?php echo formhash(); ?>" />
<p><h2>登陆更精彩...</h2></p>
<p>账号:</p>
<p><input type="text" name="username" id="username" class="t_input" size="15" value="" /></p>
<p>密码:</p>
<p><input type="password" name="password" id="password" class="t_input" size="15" value="" /></p>
<p ><input type="checkbox" id="cookietime" name="cookietime" value="315360000" checked /><label for="cookietime">记住我</label></p>
<p>
<input type="submit" id="loginsubmit" name="loginsubmit" value="登录" class="submit" />
<input type="button" name="regbutton" value="注册" class="button" onclick="urlto('do.php?ac=<?=$_SCONFIG['register_action']?>');">
</p>
</form>

</div>
<?php } ?>
</div>

<div id="mainarea">

<?php if($_SGLOBAL['ad']['contenttop']) { ?><div id="ad_contenttop"><?php adshow('contenttop'); ?></div><?php } ?>
<?php } ?>

<?php } ?>

<style type="text/css">
@import url(template/default/home_style.css);
</style>
<div id="content">
<div class="whiteBox">
<span class="whiteBoxHd"><span></span></span>
<div class="whiteBoxBd">
<?php if($space['uid'] && $space['self']) { ?>
    ﻿<div id="mood_mystatus">
<?=$space['spacenote']?>
</div>

<div class="multiComposer" id="homeComposer">								
<div class="mcAvatar">
<div class="avatar-48"><a href="cp.php" title=" <?=$space['viewnum']?> 次访问, <?=$space['credit']?> 个积分, <?=$space['experience']?> 个经验"><?php echo avatar($_SGLOBAL[supe_uid],small); ?></a></div>
        <a id="homeUploadAvatar" class="uploadAvatar" href="cp.php?ac=avatar" >修改头像</a>
</div>																
<div class="mcContent">
<div class="mcPanel" id="mood_form">
<form method="post" action="cp.php?ac=doing" id="mood_addform">
<div class="mcStatus">
<div class="mcStatusInt">
<div class="mcStatusIpt">
<textarea rows="3" cols="10" name="message" id="mood_message" onfocus="bindFocus();" tabindex="1" class="blank" onkeydown="if(event.keyCode == 13 ){ event.returnValue=false;event.cancel = true;$('mood_add').click();$('mood_message').value='';this.blur(); };" ></textarea>
</div>
<div class="mcStatusEmot" id="emot" style="display:none"><span class="emot e-base-1"><a href="###" id="doingface" onclick="showFace(this.id, 'mood_message');return false;"><img src="image/facelist.gif" align="absmiddle" /></a></span></div>
<div class="mcStatusAct" id="mcs" >
<div class="mcStatusBtn"><span class="button"><span><button tabindex="2" id="mood_add" type="button" id="mood_add" name="add" onclick="ajaxpost('mood_addform', 'reloadMood');$('mood_message').value='';" > 发送 </button></span></span>&nbsp;<span class="button button-sub"><span><button onclick="bindBlur();return false;"> 取消 </button></span></span>
<input type="hidden" name="addsubmit" value="true" />
                <input type="hidden" name="spacenote" value="true" />
                <input type="hidden" name="formhash" value="<?php echo formhash(); ?>" /></div>
</div>
</div>
</div>

<div class="mcAttachs">
已有 <?=$space['viewnum']?> 人次访问, <?=$space['credit']?> 个金币, <?=$space['experience']?> 个经验
</div>
<div class="mcAd">

<?php if($_SGLOBAL['session']['magichidden']) { ?><a class="icon i-enoline"></a><a href="javascript:void(0);">当前隐身</a><?php } else { ?><a class="icon i-eonline"></a><a href="javascript:void(0);">当前在线</a><?php } ?>
<?php if($_SGLOBAL['magic']['invisible']) { ?>
<?php if($_SGLOBAL['session']['magichidden']) { ?>
&nbsp;<a class="icon i-nohidden"></a><a id="a_magic_appear" href="cp.php?ac=magic&op=appear" onclick="ajaxmenu(event,this.id)">我要在线</a>
<?php } else { ?>
&nbsp;<a title="<?=$_SGLOBAL['magic']['invisible']?>" class="icon i-hidden"></a><a id="a_magic_invisible" href="magic.php?mid=invisible" onclick="ajaxmenu(event,this.id,1)">我要隐身</a>
<?php } ?>
<?php } ?>
</div>
</form>
</div>
<div class="mcLayer" id="mcLayer">
<a class="mcLayerOpt">关闭</a>
<span class="mcLayerHd"><span></span></span>
<div class="mcLayerBd">
<div class="j-box">
<div class="mcAttach-share" id="d_said"></div>
<div class="mcAttach-vote" id="d_vid"></div>
</div></div>
<span class="mcLayerFt"><span></span></span>
</div>
</div>
<div class="mcTooltipWrap"></div>
</div>
<div id="mood_mystatus" style="display:none">
<?=$space['spacenote']?>
</div>
<script type="text/javascript">
        function getStatusText() {
var _default = '说说你在做什么？';
var _st = { 
//base 
c: ['嘿，哥们儿，嘛呢？', '既来之，则说之……', '什么叫热闹？大吼小叫！', '“得瑟得瑟”也不犯法！'],
//6:00 - 9:00 
m: ['路上堵车吗？', '地铁上遇到帅哥了吗？', '今天没迟到吧？', '今天小报上有什么趣闻？', '繁忙的一天开始，你要说的第一句是什么？'],
//9:00 - 12:00 
a: ['你准备买房了吗？', '你是否仍深爱酒井法子？', '贾君鹏回家吃饭了吗？', '今天任务多吗？', '今天中午吃点啥？'],
//12:00 - 14:00 
n: ['吃完饭后困了？', '今天中午吃的啥？', '附近新开了家饭馆？', '今天中午有什么八卦吗？', '今天中午和谁吃的饭？'],
//14:00 - 17:00 
p: ['今天大猫在公司吗？', '还有几个小时你就下班了？','向好友大声喊两句发泄发泄……', '说的不是一句话，是寂寞……', '工作完成了？'],
//17:00 - 19:00 
d: ['今天下班后什么安排？', '今天有人加班吗？', '还不下班？','你妈妈喊你回家吃饭', '有人请客吃饭吗？'],
//19:00 - 21:00 
e: ['这一天累吗？跟大家汇报汇报……', '晚上有什么好事儿发生？'],
//21:00 - 24:00 
l: ['周围安静吗？聊两句冒个泡', '还没睡？那喊两句吵醒别人！', '你正在干嘛？', '还在工作么？休息一下聊两句……'],
//0:00 - 6:00 
w: ['发现什么好玩的了吗？', '我要在这深夜对你们说些心里话……', '夜生活才刚刚开始？'],
//weekend 
k: ['周末玩得开心吗？', '周末有人加班吗？', '大周末的，跟朋友扯两句吧', '此刻你在哪呢？', '生活才刚刚开始？']
}; 
var r = _st.c ? _st.c: [];
var t = new Date();
var h = t.getHours(),
d = t.getDay();
if(h>=9&&h<12){r=r.concat(_st.a?_st.a:[]);}
if(h>=12&&h<14){r=r.concat(_st.n?_st.n:[]);}
if(h>=14&&h<17){r=r.concat(_st.p?_st.p:[]);}
if(h>=17&&h<19){r=r.concat(_st.d?_st.d:[]);}
if(h>=19&&h<21){r=r.concat(_st.e?_st.e:[]);}
if(h>=21&&h<24){r=r.concat(_st.l?_st.l:[]);}
if(h>=0&&h<6){r=r.concat(_st.w?_st.w:[]);}
if(d==0||d==6){r=r.concat(_st.k);}
if (r.length == 0) {
return _default;
} else {
return r[Math.floor(Math.random() * r.length)];
}

};

var defaultValue = getStatusText();
    $('mood_message').value = defaultValue;

function bindFocus() {
    if($('mood_message').value == defaultValue){
$('mood_message').value = '';
}
$('emot').style.display = '';
$('mcs').style.height = '28px';
$('mood_message').className = '';

}

    function hiddenface() {
$('mood_message_menu').style.display = 'none';

}

function bindBlur() {
$('mood_message').className = 'blank';
$('mcs').style.height = '0px';
$('emot').style.display = 'none';
if($('mood_message').value == ''){
$('mood_message').value = defaultValue;
}

}

    function statust() {
if($('share_general').value == '写上分享理由…'){
$('share_general').value = '';
}

}

function reloadMood(showid, result) {
var x = new Ajax();
x.get('cp.php?ac=doing&op=getmood', function(s){
$('mood_mystatus').innerHTML = s;
});
//提示获得积分
showreward();
bindBlur();
}
</script>


<?php if(empty($_SCOOKIE['closefeedbox']) && $_SGLOBAL['ad']['feedbox']) { ?>
<div id="feed_box" ><div class="ye_l_b">
<div class="task_notice">
<a title="忽略" class="float_cancel" href="javascript:;" onclick="close_feedbox();">忽略</a>
<div class="task_notice_body">
<?php adshow('feedbox'); ?>
</div>
</div>
</div></div>
<?php } ?>
    <div id="homeFeed">
<div class="homeFeedTabs" id="homeNewsTab">
<ul>
<?php if($space['friendnum']) { ?><li<?=$actives['we']?>><a href="space.php?do=home&view=we"><span>全部</span></a></li><?php } ?>
<li<?=$cat_actives['doing']?>><a href="space.php?do=home&view=all&icon=doing"><span>一句话</span></a></li>
<li<?=$cat_actives['album']?>><a href="space.php?do=home&view=all&icon=album"><span>照片</span></a></li>
<li<?=$cat_actives['blog']?>><a href="space.php?do=home&view=all&icon=blog"><span>日志</span></a></li>
<li<?=$cat_actives['share']?>><a href="space.php?do=home&view=all&icon=share"><span>分享</span></a></li>
<li<?=$actives['all']?>><a href="space.php?do=home&view=all"><span>随便看看</span></a></li>
</ul>
</div>
<div class="homeFeedFilter" id="homeFeedFilter">
<?php if($_SGLOBAL['magic']['thunder']) { ?><a class="uploadAvatar" id="a_magic_thunder" href="magic.php?mid=thunder" onclick="ajaxmenu(event,this.id, 1)" style="display: block;">雷鸣之声</a><?php } ?>
</div>
<div class="popLayer homeFeedFilterLayer" style="width: 68px;">
<div class="decor"><span class="tl"/><span class="tr"></span><span class="br"></span><span class="bl"></span></div>
<div class="content">
<ul class="checkList">
<?php if($space['friendnum']) { ?><li<?=$actives['we']?> class="on"><a href="space.php?do=home&view=we">好友</a></li><?php } ?>
<li<?=$actives['hot']?>><a href="space.php?do=home&view=hot">热门</a></li>
<li<?=$actives['me']?>><a href="space.php?do=home&view=me">我的</a></li>
<li<?=$actives['all']?>><a href="space.php?do=home&view=all">全站</a></li>
</ul>
</div>
</div>


<?php } elseif($space['uid']) { ?>

<?php $_TPL['spacetitle'] = "动态";
	$_TPL['spacemenus'][] = "<a href=\"space.php?uid=$space[uid]&do=feed&view=me\">TA的近期动态</a>"; ?>
﻿<div class="c_header a_header">
<div class="avatar-48"><a href="space.php?uid=<?=$space['uid']?>"><?php echo avatar($space[uid],small); ?></a></div>
<?php if($_SGLOBAL['refer']) { ?>
<a class="r_option" href="<?=$_SGLOBAL['refer']?>">&laquo; 返回上一页</a>
<?php } ?>
<p style="font-size:14px"><?=$_SN[$space['uid']]?>的<?=$_TPL['spacetitle']?></p>
<a href="space.php?uid=<?=$space['uid']?>" class="spacelink"><?=$_SN[$space['uid']]?>的主页</a>
<?php if($_TPL['spacemenus']) { ?>
<?php if(is_array($_TPL['spacemenus'])) { foreach($_TPL['spacemenus'] as $value) { ?> <span class="pipe">&raquo;</span> <?=$value?><?php } } ?>
<?php } ?>
</div>

<div id="homeFeed">

<?php } else { ?>
<div class="nologin">
<h3>此刻，他们正在发生的新鲜事...</h3>
</div>
<?php } ?>

<?php } ?>
<div id="feed_div" class="enter-content">
<div class="homeFeedWrap" id="homeFeedWrap">
<div class="newsfeed" id="homeFeedList">	
    <div>
<?php if($list) { ?>
<?php if(is_array($list)) { foreach($list as $day => $values) { ?>
<?php if($_GET['view']!='hot') { ?>
<h4 class="diviTitle">
<?php if($day=='yesterday') { ?><span class="diviLabel">昨天</span><span class="diviLine"></span>
<?php } elseif($day=='today') { ?><span class="diviLabel" style="display:none"></span><span class="diviLine" style="display:none"></span>
<?php } elseif($day=='app') { ?><span class="diviLabel">看看大家都在玩什么</span><span class="diviLine"></span>
<?php } else { ?><span class="diviLabel"><?=$day?></span><span class="diviLine"></span>
<?php } ?>
</h4>
<?php } ?>
<ul class="feedList">
<?php if(is_array($values)) { foreach($values as $value) { ?>
﻿<?php if($value['icon']=='doing') { ?>
<li class="feedItem feedItem-main feed-<?=$value['icon']?> " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);">   
    <div class="feedIcon">
        <div class="avatar-48"><a href="space.php?uid=<?=$value['uid']?>" title="<?=$_SN[$value['uid']]?>" alt="<?=$_SN[$value['uid']]?>"><?php echo avatar($value[uid],small); ?></a></div>
    </div>
    <div class="feedContent feedStyle-short">
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<span class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-edit">删除</a></span>
<?php } ?>
<h4>
<span class="statusWord"><i><i><i><i> <?=$value['title_template']?> </i></i></i></i></span>     
</h4>
</div>        
            <div class="feedFoot">                
                    <a title="通过手机发布" class="icon i-wap" href="#" style="display:none"></a>
                    <span class="time"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span>  -   
                    <?php if(empty($_TPL['hidden_menu'])) { ?><?php if($value['idtype']=='doid') { ?><span class="action"><a onclick="docomment_get('docomment_<?=$value['id']?>', 1);" id="do_a_op_<?=$value['id']?>" href="javascript:void(0)">回复</a></span><?php } ?><?php } ?><?php if(!empty($hiddenfeed_num[$value['icon']])) { ?>  -  
<div class="feedHead" id="feed_more_<?=$value['feedid']?>" style="display:none;">              
<?php if(is_array($hiddenfeed_list[$value['icon']])) { foreach($hiddenfeed_list[$value['icon']] as $appvalue) { ?>
<?php $appvalue = mkfeed($appvalue); ?>

<h4>
<?=$appvalue['title_template']?>
</h4>
<?php if($appvalue['body_template']) { ?>
<span class="meta time"><?=$appvalue['body_template']?></span>
<?php } ?>

<?php } } ?>
</div>
<span id="appfeed_open_<?=$value['feedid']?>"><a class="act a-tg-down" href="javascript:;" id="feed_a_more_<?=$value['feedid']?>" onclick="feed_more_show('<?=$value['feedid']?>');">显示更多(<?=$hiddenfeed_num[$value['icon']]?>)条</a></span><?php } ?>      
            </div> 
<?php if($value['idtype']=='doid') { ?>
<div class="feedComment" id="docomment_<?=$value['id']?>" style="display:none;"></div>
<?php } ?> 

    </div>
</li>

<?php } elseif($value['icon']=='poll') { ?>

<li class="feedItem  feedItem-main feed-<?=$value['icon']?> " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);"> 
    <div class="feedIcon">       
<div class="avatar-48"><a href="space.php?uid=<?=$value['uid']?>" title="<?=$_SN[$value['uid']]?>" alt="<?=$_SN[$value['uid']]?>"><?php echo avatar($value[uid],small); ?></a></div>	
    </div>
    <div class="feedContent feedStyle-short">
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<span class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-edit">删除</a></span>
<?php } ?>
<h4>
 <?=$value['title_template']?>     
</h4>
</div>
<?php if($value['body_template']) { ?>
<div class="feedBody">
<div class="feedAttach"><div class="feedAttachContent"><?=$value['body_template']?></div></div>
</div>
<?php } ?>
            <div class="feedFoot">                
                    <span class="time"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span>  -   
                    <?php if(empty($_TPL['hidden_menu'])) { ?><?php if($value['idtype']=='doid') { ?><span class="action"><a onclick="docomment_get('docomment_<?=$value['id']?>', 1);" id="do_a_op_<?=$value['id']?>" href="javascript:void(0)">回复</a></span><?php } elseif(in_array($value['idtype'], array('blogid','picid','sid','pid','eventid'))) { ?><span class="action"><a onclick="feedcomment_get(<?=$value['feedid']?>);" id="feedcomment_a_op_<?=$value['feedid']?>" href="javascript:void(0)">评论</a></span><?php } ?><?php } ?><?php if(!empty($hiddenfeed_num[$value['icon']])) { ?>  -  
<div class="feedHead" id="feed_more_<?=$value['feedid']?>" style="display:none;">              
<?php if(is_array($hiddenfeed_list[$value['icon']])) { foreach($hiddenfeed_list[$value['icon']] as $appvalue) { ?>
<?php $appvalue = mkfeed($appvalue); ?>

<h4>
<?=$appvalue['title_template']?>
</h4>
<?php if($appvalue['body_template']) { ?>
<span class="meta time"><?=$appvalue['body_template']?></span>
<?php } ?>

<?php } } ?>
</div>
<span id="appfeed_open_<?=$value['feedid']?>"><a class="act a-tg-down" href="javascript:;" id="feed_a_more_<?=$value['feedid']?>" onclick="feed_more_show('<?=$value['feedid']?>');">显示更多(<?=$hiddenfeed_num[$value['icon']]?>)条</a></span><?php } ?>       
            </div> 
<?php if($value['idtype']) { ?>
<div class="feedComment" id="feedcomment_<?=$value['feedid']?>" style="display:none;"></div>
<?php } ?> 
    </div>
</li>

<?php } elseif($value['icon']=='blog') { ?>
<li class="feedItem  feedItem-main feed-<?=$value['icon']?> " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);"> 
    <div class="feedIcon">       
<div class="avatar-48"><a href="space.php?uid=<?=$value['uid']?>" title="<?=$_SN[$value['uid']]?>" alt="<?=$_SN[$value['uid']]?>"><?php echo avatar($value[uid],small); ?></a></div>	
    </div>
    <div class="feedContent feedStyle-short">
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<span class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-edit">删除</a></span>
<?php } ?>
<h4>
 <?=$value['title_template']?>     
</h4>
</div>
<?php if($value['body_template']) { ?>
<div class="feedBody">
<div class="feedAttach">
<?php if($value['image_1']) { ?>
<div class="feedAttachMedia"><a href="<?=$value['image_1_link']?>"<?=$value['target']?>><img src="<?=$value['image_1']?>" class="photo-50" /></a></div>
<?php } ?>
<div class="feedAttachContent"><?=$value['body_template']?></div></div>
</div>
<?php } ?>
            <div class="feedFoot">                
                    <span class="time"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span>  -   
                    <?php if(empty($_TPL['hidden_menu'])) { ?><?php if(in_array($value['idtype'], array('blogid','picid','sid','pid','eventid'))) { ?><span class="action"><a onclick="feedcomment_get(<?=$value['feedid']?>);" id="feedcomment_a_op_<?=$value['feedid']?>" href="javascript:void(0)">评论</a></span><?php } ?><?php } ?><?php if(!empty($hiddenfeed_num[$value['icon']])) { ?>  -  
<div class="feedHead" id="feed_more_<?=$value['feedid']?>" style="display:none;">              
<?php if(is_array($hiddenfeed_list[$value['icon']])) { foreach($hiddenfeed_list[$value['icon']] as $appvalue) { ?>
<?php $appvalue = mkfeed($appvalue); ?>

<h4>
<?=$appvalue['title_template']?>
</h4>
<?php if($appvalue['body_template']) { ?>
<span class="meta time"><?=$appvalue['body_template']?></span>
<?php } ?>

<?php } } ?>
   </div>	
<span id="appfeed_open_<?=$value['feedid']?>"><a class="act a-tg-down" href="javascript:;" id="feed_a_more_<?=$value['feedid']?>" onclick="feed_more_show('<?=$value['feedid']?>');">显示更多(<?=$hiddenfeed_num[$value['icon']]?>)条</a></span><?php } ?>         
            </div> 
<?php if($value['idtype']) { ?>
<div class="feedComment" id="feedcomment_<?=$value['feedid']?>" style="display:none;"></div>
<?php } ?>
    </div>
</li>

<?php } elseif($value['icon']=='thread') { ?>

<li class="feedItem  feedItem-main feed-<?=$value['icon']?> " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);"> 
    <div class="feedIcon">       
<div class="avatar-48"><a href="space.php?uid=<?=$value['uid']?>" title="<?=$_SN[$value['uid']]?>" alt="<?=$_SN[$value['uid']]?>"><?php echo avatar($value[uid],small); ?></a></div>	
    </div>
    <div class="feedContent feedStyle-short">
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<span class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-edit" >删除</a></span>
<?php } ?>
<h4>
 <?=$value['title_template']?>     
</h4>
</div>
<?php if($value['body_template']) { ?>
<div class="feedBody">
<div class="feedAttach">
<div class="feedAttachContent"><?=$value['body_template']?></div></div>
</div>
<?php } ?>	
    </div>
</li>

<?php } elseif(in_array($value['icon'], array('profile','friend','joinpoll','click','comment','myop','mtag','task','wall','post','show','joinevent'))) { ?>
<li class="feedItem feedItem-sub feed-<?=$value['icon']?>  " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);">
<div class="feedIcon"><div class="avatar-48"><a href="space.php?uid=<?=$value['uid']?>" title="<?=$_SN[$value['uid']]?>" alt="<?=$_SN[$value['uid']]?>"><?php echo avatar($value[uid],small); ?></a></div></div>
<div class="feedContent feedStyle-oneline" >	
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<span class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-edit" title="删除">删除</a></span>
<?php } ?>
<h4> <?=$value['title_template']?><span class="meta time"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span>
<?php if(in_array($value['idtype'], array('commentid'))) { ?>
<span class="action"><a onclick="feedcommentback_get(<?=$value['feedid']?>);" id="feedcomment_a_op_<?=$value['feedid']?>" href="javascript:void(0)">回应</a></span>
<?php } ?>
</h4>
</div>
<?php if(in_array($value['idtype'], array('commentid'))) { ?>
<div class="feedBody">
<?php if($value['body_template']) { ?><?=$value['body_template']?><?php } ?>
</div>
<?php } ?>
<?php if(in_array($value['idtype'], array('commentid'))) { ?>
<div class="feedComment" id="feedcomment_<?=$value['feedid']?>" style="display:none;"></div>
<?php } ?> 
<?php if(!empty($hiddenfeed_num[$value['icon']])) { ?>
<div class="feedFoot"> 
<div class="feedHead" id="feed_more_<?=$value['feedid']?>" style="display:none;">              
<?php if(is_array($hiddenfeed_list[$value['icon']])) { foreach($hiddenfeed_list[$value['icon']] as $appvalue) { ?>
<?php $appvalue = mkfeed($appvalue); ?>

<h4>
<?=$appvalue['title_template']?>
</h4>
<?php if($appvalue['body_template']) { ?>
<span class="meta time"><?=$appvalue['body_template']?></span>
<?php } ?>

<?php } } ?>
</div>                        
               <span id="appfeed_open_<?=$value['feedid']?>"><a class="act a-tg-down" href="javascript:;" id="feed_a_more_<?=$value['feedid']?>" onclick="feed_more_show('<?=$value['feedid']?>');">显示更多(<?=$hiddenfeed_num[$value['icon']]?>)条</a></span>
        </div>
<?php } ?>

</div>
</li>

<?php } elseif($value['icon']=='share') { ?>
<li class="feedItem  feedItem-main feed-<?=$value['icon']?> " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);">
    <div class="feedIcon">       
<div class="avatar-48"><a href="space.php?uid=<?=$value['uid']?>" title="<?=$_SN[$value['uid']]?>" alt="<?=$_SN[$value['uid']]?>"><?php echo avatar($value[uid],small); ?></a></div>	
    </div>
    <div class="feedContent feedStyle-short">
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<div class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-edit" title="删除">删除</a></div>
<?php } ?>
<h4>
 <?=$value['title_template']?> 
</h4>
</div>
<div class="feedBody">
<div class="feedAttach feedAttach-user">
        <?php if($value['image_1'] && empty($value['body_data']['flashvar'])) { ?>
<div class="feedAttachMedia"><a href="<?=$value['image_1_link']?>"<?=$value['target']?>><img src="<?=$value['image_1']?>" class="photo-50" /></a></div>
<?php } ?>
<?php if($value['image_2']) { ?>
<a href="<?=$value['image_2_link']?>"<?=$value['target']?>><img src="<?=$value['image_2']?>" class="summaryimg1" /></a>
<?php } ?>
<?php if($value['image_3']) { ?>
<a href="<?=$value['image_3_link']?>"<?=$value['target']?>><img src="<?=$value['image_3']?>" class="summaryimg2" /></a>
<?php } ?>
<?php if($value['image_4']) { ?>
<a href="<?=$value['image_4_link']?>"<?=$value['target']?>><img src="<?=$value['image_4']?>" class="summaryimg3" /></a>
<?php } ?>
<?php if($value['thisapp'] && !empty($value['body_data']['flashvar'])) { ?>
<div class="feedAttachMedia">
<div class="playVideo">
<a id="media_id_<?=$value['feedid']?>" class="videoCover" title="播放该视频" onclick="javascript:showFlash('<?=$value['body_data']['host']?>', '<?=$value['body_data']['flashvar']?>', this, '<?=$value['feedid']?>');" style="cursor:pointer;"><img id=icon_id_<?=$value['feedid']?> src="<?php if(!empty($value['image_1'])) { ?><?=$value['image_1']?><?php } else { ?>image/videoCover.gif<?php } ?>" class="video"/><em>播放该视频</em></a>
</div>
</div>
<?php } elseif($value['thisapp'] && !empty($value['body_data']['musicvar'])) { ?>
<div class="feedAttachMedia">
<div class="playMusic">
<a onclick="javascript:showFlash('music', '<?=$value['body_data']['musicvar']?>', this, '<?=$value['feedid']?>');" style="cursor:pointer;" class="musicCover" title="播放该音乐"  >播放该音乐</a>
</div>
</div>
<?php } elseif($value['thisapp'] && !empty($value['body_data']['flashaddr'])) { ?>
<div class="feedAttachMedia">
<div class="playFlash">
<a onclick="javascript:showFlash('flash', '<?=$value['body_data']['flashaddr']?>', this, '<?=$value['feedid']?>');" style="cursor:pointer;" class="musicCover" title="播放该音乐" >播放该音乐</a>
</div>
</div>
<?php } ?>
<?php if($value['body_template'] && empty($value['body_data']['flashvar']) && empty($value['body_data']['musicvar']) && empty($value['body_data']['flashaddr'])) { ?>
<div class="feedAttachContent"><?=$value['body_template']?></div>
<?php } ?> </div>
<?php if($value['body_general']) { ?>
<p class="quote"><?=$value['body_general']?><q></q></p>
<?php } ?>
</div>

            <div class="feedFoot">                
                    <span class="time"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span>  -   
                    <?php if(empty($_TPL['hidden_menu'])) { ?><?php if($value['idtype']=='doid') { ?><span class="action"><a onclick="docomment_get('docomment_<?=$value['id']?>', 1);" id="do_a_op_<?=$value['id']?>" href="javascript:void(0)">回复</a></span><?php } elseif(in_array($value['idtype'], array('blogid','picid','sid','pid','eventid'))) { ?><span class="action"><a onclick="feedcomment_get(<?=$value['feedid']?>);" id="feedcomment_a_op_<?=$value['feedid']?>" href="javascript:void(0)">评论</a></span><?php } ?><?php } ?>      
            </div> 
<?php if($value['idtype']) { ?>
<div class="feedComment" id="feedcomment_<?=$value['feedid']?>" style="display:none;"></div>
<?php } ?> 
    </div>
</li>

<?php } elseif(in_array($value['icon'], array('album'))) { ?>

<li class="feedItem feedItem-main feed-<?=$value['icon']?>  " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);">
<div class="feedIcon"><div class="avatar-48"><a href="space.php?uid=<?=$value['uid']?>" title="<?=$_SN[$value['uid']]?>" alt="<?=$_SN[$value['uid']]?>"><?php echo avatar($value[uid],small); ?></a></div></div>
<div class="feedContent feedStyle-short" >	
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<span class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-edit" title="删除">删除</a></span>
<?php } ?>
<h4><?=$value['title_template']?>&nbsp;<?php if($value['body_template']) { ?><?=$value['body_template']?><?php } ?></h4></div>
<div class="feedBody">
<div class="albumSample"><ul class="albumCover">
<?php if($value['image_1']) { ?>
<li><a href="<?=$value['image_1_link']?>"<?=$value['target']?>><img src="<?=$value['image_1']?>" class="photo" /></a>

</li>
<?php } ?>
</ul></div></div>
<div class="feedFoot"><span class="time"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span></div>
</div>

</li>
<?php } elseif(in_array($value['icon'], array('event'))) { ?>

<li class="feedItem feedItem-main feed-<?=$value['icon']?>  " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);">
<div class="feedIcon"><div class="avatar-48"><a href="space.php?uid=<?=$value['uid']?>" title="<?=$_SN[$value['uid']]?>" alt="<?=$_SN[$value['uid']]?>"><?php echo avatar($value[uid],small); ?></a></div></div>
<div class="feedContent feedStyle-short" >	
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<span class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-edit" title="删除">删除</a></span>
<?php } ?>
<h4><?=$value['title_template']?>&nbsp;</h4>
</div>
<div class="feedBody">
<div class="feedAttach feedAttach-event-img">
<?php if($value['image_1']) { ?><div class="feedAttachMedia"><a href="<?=$value['image_1_link']?>"<?=$value['target']?>><img src="<?=$value['image_1']?>" class="poster_pre" /></a></div><?php } ?>
<div class="feedAttachContent"><?php if($value['body_template']) { ?><?=$value['body_template']?><?php } ?></div>
</div>
</div>
<div class="feedFoot">                
<span class="time"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span>  -   
<?php if(empty($_TPL['hidden_menu'])) { ?><?php if(in_array($value['idtype'], array('blogid','picid','sid','pid','eventid'))) { ?><span class="action"><a onclick="feedcomment_get(<?=$value['feedid']?>);" id="feedcomment_a_op_<?=$value['feedid']?>" href="javascript:void(0)">评论</a></span><?php } ?><?php } ?>      
</div> 
<?php if($value['idtype']) { ?>
<div class="feedComment" id="feedcomment_<?=$value['feedid']?>" style="display:none;"></div>
<?php } ?> 
</div>
</li>

<?php } elseif(in_array($value['icon'], array('sitefeed'))) { ?>

<li class="feedItem feedItem-main feed-<?=$value['icon']?>  " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);">
<div class="feedIcon"><div class="avatar-48"><a href="space.php?uid=1" title="发言人马甲" alt="发言人马甲"><img src="image/manage.jpg"/></a></div></div>
<div class="feedContent feedStyle-oneline" >	
<div class="feedHead">
<h4><?=$value['title_template']?></h4>
</div>
</div>
</li>

<?php } else { ?>

<li class="feedItem feedItem-sub feed-<?=$value['icon']?>  " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);">
<div class="feedIcon"><div class="avatar-48"><a href="space.php?uid=<?=$_GET['uid']?>&do=feed&view=<?=$_GET['view']?>&appid=<?=$value['appid']?>&icon=<?=$value['icon']?>"><img src="<?=$value['icon_image']?>" /></a></div></div>
<div class="feedContent feedStyle-oneline" >	
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<span class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-edit" title="删除">删除</a></span>
<?php } ?>
<h4> <?=$value['title_template']?><span class="meta time"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span></h4>
</div>
<?php if(!empty($hiddenfeed_num[$value['icon']])) { ?>
<div class="feedFoot"> 
<div class="feedHead" id="feed_more_<?=$value['feedid']?>" style="display:none;">              
<?php if(is_array($hiddenfeed_list[$value['icon']])) { foreach($hiddenfeed_list[$value['icon']] as $appvalue) { ?>
<?php $appvalue = mkfeed($appvalue); ?>

<h4>
<?=$appvalue['title_template']?>
</h4>
<?php if($appvalue['body_template']) { ?>
<span class="meta time"><?=$appvalue['body_template']?></span>
<?php } ?>

<?php } } ?>
</div>                        
               <span id="appfeed_open_<?=$value['feedid']?>"><a class="act a-tg-down" href="javascript:;" id="feed_a_more_<?=$value['feedid']?>" onclick="feed_more_show('<?=$value['feedid']?>');">显示更多(<?=$hiddenfeed_num[$value['icon']]?>)条</a></span>
        </div>
<?php } ?>

</div>
</li>
<?php } ?>
<?php } } ?>
</ul>
<?php } } ?>

<?php } else { ?>
<ul class="feedList">
<li class="feedlistEmpty">没有相关动态</li>
</ul>
<?php } ?>

<?php if($filtercount) { ?>
<div class="homeFeedIdle" id="feed_filter_notice_<?=$start?>">
根据您的<a href="cp.php?ac=privacy&op=view">筛选设置</a>，有 <?=$filtercount?> 条动态被屏蔽 (<a href="javascript:;" onclick="filter_more(<?=$start?>);" id="a_feed_privacy_more">点击查看</a>)
</div>
<div id="feed_filter_div_<?=$start?>" class="enter-content" style="display:none;">
<h4 class="diviTitle"><span class="diviLabel">以下是被屏蔽的动态</span><span class="diviLine"></span></h4>
<ul class="feedList">
<?php if(is_array($filter_list)) { foreach($filter_list as $value) { ?>
<?php $value = mkfeed($value); ?>
﻿<?php if($value['icon']=='doing') { ?>
<li class="feedItem feedItem-main feed-<?=$value['icon']?> " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);">   
    <div class="feedIcon">
        <div class="avatar-48"><a href="space.php?uid=<?=$value['uid']?>" title="<?=$_SN[$value['uid']]?>" alt="<?=$_SN[$value['uid']]?>"><?php echo avatar($value[uid],small); ?></a></div>
    </div>
    <div class="feedContent feedStyle-short">
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<span class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-edit">删除</a></span>
<?php } ?>
<h4>
<span class="statusWord"><i><i><i><i> <?=$value['title_template']?> </i></i></i></i></span>     
</h4>
</div>        
            <div class="feedFoot">                
                    <a title="通过手机发布" class="icon i-wap" href="#" style="display:none"></a>
                    <span class="time"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span>  -   
                    <?php if(empty($_TPL['hidden_menu'])) { ?><?php if($value['idtype']=='doid') { ?><span class="action"><a onclick="docomment_get('docomment_<?=$value['id']?>', 1);" id="do_a_op_<?=$value['id']?>" href="javascript:void(0)">回复</a></span><?php } ?><?php } ?><?php if(!empty($hiddenfeed_num[$value['icon']])) { ?>  -  
<div class="feedHead" id="feed_more_<?=$value['feedid']?>" style="display:none;">              
<?php if(is_array($hiddenfeed_list[$value['icon']])) { foreach($hiddenfeed_list[$value['icon']] as $appvalue) { ?>
<?php $appvalue = mkfeed($appvalue); ?>

<h4>
<?=$appvalue['title_template']?>
</h4>
<?php if($appvalue['body_template']) { ?>
<span class="meta time"><?=$appvalue['body_template']?></span>
<?php } ?>

<?php } } ?>
</div>
<span id="appfeed_open_<?=$value['feedid']?>"><a class="act a-tg-down" href="javascript:;" id="feed_a_more_<?=$value['feedid']?>" onclick="feed_more_show('<?=$value['feedid']?>');">显示更多(<?=$hiddenfeed_num[$value['icon']]?>)条</a></span><?php } ?>      
            </div> 
<?php if($value['idtype']=='doid') { ?>
<div class="feedComment" id="docomment_<?=$value['id']?>" style="display:none;"></div>
<?php } ?> 

    </div>
</li>

<?php } elseif($value['icon']=='poll') { ?>

<li class="feedItem  feedItem-main feed-<?=$value['icon']?> " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);"> 
    <div class="feedIcon">       
<div class="avatar-48"><a href="space.php?uid=<?=$value['uid']?>" title="<?=$_SN[$value['uid']]?>" alt="<?=$_SN[$value['uid']]?>"><?php echo avatar($value[uid],small); ?></a></div>	
    </div>
    <div class="feedContent feedStyle-short">
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<span class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-edit">删除</a></span>
<?php } ?>
<h4>
 <?=$value['title_template']?>     
</h4>
</div>
<?php if($value['body_template']) { ?>
<div class="feedBody">
<div class="feedAttach"><div class="feedAttachContent"><?=$value['body_template']?></div></div>
</div>
<?php } ?>
            <div class="feedFoot">                
                    <span class="time"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span>  -   
                    <?php if(empty($_TPL['hidden_menu'])) { ?><?php if($value['idtype']=='doid') { ?><span class="action"><a onclick="docomment_get('docomment_<?=$value['id']?>', 1);" id="do_a_op_<?=$value['id']?>" href="javascript:void(0)">回复</a></span><?php } elseif(in_array($value['idtype'], array('blogid','picid','sid','pid','eventid'))) { ?><span class="action"><a onclick="feedcomment_get(<?=$value['feedid']?>);" id="feedcomment_a_op_<?=$value['feedid']?>" href="javascript:void(0)">评论</a></span><?php } ?><?php } ?><?php if(!empty($hiddenfeed_num[$value['icon']])) { ?>  -  
<div class="feedHead" id="feed_more_<?=$value['feedid']?>" style="display:none;">              
<?php if(is_array($hiddenfeed_list[$value['icon']])) { foreach($hiddenfeed_list[$value['icon']] as $appvalue) { ?>
<?php $appvalue = mkfeed($appvalue); ?>

<h4>
<?=$appvalue['title_template']?>
</h4>
<?php if($appvalue['body_template']) { ?>
<span class="meta time"><?=$appvalue['body_template']?></span>
<?php } ?>

<?php } } ?>
</div>
<span id="appfeed_open_<?=$value['feedid']?>"><a class="act a-tg-down" href="javascript:;" id="feed_a_more_<?=$value['feedid']?>" onclick="feed_more_show('<?=$value['feedid']?>');">显示更多(<?=$hiddenfeed_num[$value['icon']]?>)条</a></span><?php } ?>       
            </div> 
<?php if($value['idtype']) { ?>
<div class="feedComment" id="feedcomment_<?=$value['feedid']?>" style="display:none;"></div>
<?php } ?> 
    </div>
</li>

<?php } elseif($value['icon']=='blog') { ?>
<li class="feedItem  feedItem-main feed-<?=$value['icon']?> " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);"> 
    <div class="feedIcon">       
<div class="avatar-48"><a href="space.php?uid=<?=$value['uid']?>" title="<?=$_SN[$value['uid']]?>" alt="<?=$_SN[$value['uid']]?>"><?php echo avatar($value[uid],small); ?></a></div>	
    </div>
    <div class="feedContent feedStyle-short">
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<span class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-edit">删除</a></span>
<?php } ?>
<h4>
 <?=$value['title_template']?>     
</h4>
</div>
<?php if($value['body_template']) { ?>
<div class="feedBody">
<div class="feedAttach">
<?php if($value['image_1']) { ?>
<div class="feedAttachMedia"><a href="<?=$value['image_1_link']?>"<?=$value['target']?>><img src="<?=$value['image_1']?>" class="photo-50" /></a></div>
<?php } ?>
<div class="feedAttachContent"><?=$value['body_template']?></div></div>
</div>
<?php } ?>
            <div class="feedFoot">                
                    <span class="time"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span>  -   
                    <?php if(empty($_TPL['hidden_menu'])) { ?><?php if(in_array($value['idtype'], array('blogid','picid','sid','pid','eventid'))) { ?><span class="action"><a onclick="feedcomment_get(<?=$value['feedid']?>);" id="feedcomment_a_op_<?=$value['feedid']?>" href="javascript:void(0)">评论</a></span><?php } ?><?php } ?><?php if(!empty($hiddenfeed_num[$value['icon']])) { ?>  -  
<div class="feedHead" id="feed_more_<?=$value['feedid']?>" style="display:none;">              
<?php if(is_array($hiddenfeed_list[$value['icon']])) { foreach($hiddenfeed_list[$value['icon']] as $appvalue) { ?>
<?php $appvalue = mkfeed($appvalue); ?>

<h4>
<?=$appvalue['title_template']?>
</h4>
<?php if($appvalue['body_template']) { ?>
<span class="meta time"><?=$appvalue['body_template']?></span>
<?php } ?>

<?php } } ?>
   </div>	
<span id="appfeed_open_<?=$value['feedid']?>"><a class="act a-tg-down" href="javascript:;" id="feed_a_more_<?=$value['feedid']?>" onclick="feed_more_show('<?=$value['feedid']?>');">显示更多(<?=$hiddenfeed_num[$value['icon']]?>)条</a></span><?php } ?>         
            </div> 
<?php if($value['idtype']) { ?>
<div class="feedComment" id="feedcomment_<?=$value['feedid']?>" style="display:none;"></div>
<?php } ?>
    </div>
</li>

<?php } elseif($value['icon']=='thread') { ?>

<li class="feedItem  feedItem-main feed-<?=$value['icon']?> " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);"> 
    <div class="feedIcon">       
<div class="avatar-48"><a href="space.php?uid=<?=$value['uid']?>" title="<?=$_SN[$value['uid']]?>" alt="<?=$_SN[$value['uid']]?>"><?php echo avatar($value[uid],small); ?></a></div>	
    </div>
    <div class="feedContent feedStyle-short">
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<span class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-edit" >删除</a></span>
<?php } ?>
<h4>
 <?=$value['title_template']?>     
</h4>
</div>
<?php if($value['body_template']) { ?>
<div class="feedBody">
<div class="feedAttach">
<div class="feedAttachContent"><?=$value['body_template']?></div></div>
</div>
<?php } ?>	
    </div>
</li>

<?php } elseif(in_array($value['icon'], array('profile','friend','joinpoll','click','comment','myop','mtag','task','wall','post','show','joinevent'))) { ?>
<li class="feedItem feedItem-sub feed-<?=$value['icon']?>  " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);">
<div class="feedIcon"><div class="avatar-48"><a href="space.php?uid=<?=$value['uid']?>" title="<?=$_SN[$value['uid']]?>" alt="<?=$_SN[$value['uid']]?>"><?php echo avatar($value[uid],small); ?></a></div></div>
<div class="feedContent feedStyle-oneline" >	
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<span class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-edit" title="删除">删除</a></span>
<?php } ?>
<h4> <?=$value['title_template']?><span class="meta time"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span>
<?php if(in_array($value['idtype'], array('commentid'))) { ?>
<span class="action"><a onclick="feedcommentback_get(<?=$value['feedid']?>);" id="feedcomment_a_op_<?=$value['feedid']?>" href="javascript:void(0)">回应</a></span>
<?php } ?>
</h4>
</div>
<?php if(in_array($value['idtype'], array('commentid'))) { ?>
<div class="feedBody">
<?php if($value['body_template']) { ?><?=$value['body_template']?><?php } ?>
</div>
<?php } ?>
<?php if(in_array($value['idtype'], array('commentid'))) { ?>
<div class="feedComment" id="feedcomment_<?=$value['feedid']?>" style="display:none;"></div>
<?php } ?> 
<?php if(!empty($hiddenfeed_num[$value['icon']])) { ?>
<div class="feedFoot"> 
<div class="feedHead" id="feed_more_<?=$value['feedid']?>" style="display:none;">              
<?php if(is_array($hiddenfeed_list[$value['icon']])) { foreach($hiddenfeed_list[$value['icon']] as $appvalue) { ?>
<?php $appvalue = mkfeed($appvalue); ?>

<h4>
<?=$appvalue['title_template']?>
</h4>
<?php if($appvalue['body_template']) { ?>
<span class="meta time"><?=$appvalue['body_template']?></span>
<?php } ?>

<?php } } ?>
</div>                        
               <span id="appfeed_open_<?=$value['feedid']?>"><a class="act a-tg-down" href="javascript:;" id="feed_a_more_<?=$value['feedid']?>" onclick="feed_more_show('<?=$value['feedid']?>');">显示更多(<?=$hiddenfeed_num[$value['icon']]?>)条</a></span>
        </div>
<?php } ?>

</div>
</li>

<?php } elseif($value['icon']=='share') { ?>
<li class="feedItem  feedItem-main feed-<?=$value['icon']?> " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);">
    <div class="feedIcon">       
<div class="avatar-48"><a href="space.php?uid=<?=$value['uid']?>" title="<?=$_SN[$value['uid']]?>" alt="<?=$_SN[$value['uid']]?>"><?php echo avatar($value[uid],small); ?></a></div>	
    </div>
    <div class="feedContent feedStyle-short">
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<div class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-edit" title="删除">删除</a></div>
<?php } ?>
<h4>
 <?=$value['title_template']?> 
</h4>
</div>
<div class="feedBody">
<div class="feedAttach feedAttach-user">
        <?php if($value['image_1'] && empty($value['body_data']['flashvar'])) { ?>
<div class="feedAttachMedia"><a href="<?=$value['image_1_link']?>"<?=$value['target']?>><img src="<?=$value['image_1']?>" class="photo-50" /></a></div>
<?php } ?>
<?php if($value['image_2']) { ?>
<a href="<?=$value['image_2_link']?>"<?=$value['target']?>><img src="<?=$value['image_2']?>" class="summaryimg1" /></a>
<?php } ?>
<?php if($value['image_3']) { ?>
<a href="<?=$value['image_3_link']?>"<?=$value['target']?>><img src="<?=$value['image_3']?>" class="summaryimg2" /></a>
<?php } ?>
<?php if($value['image_4']) { ?>
<a href="<?=$value['image_4_link']?>"<?=$value['target']?>><img src="<?=$value['image_4']?>" class="summaryimg3" /></a>
<?php } ?>
<?php if($value['thisapp'] && !empty($value['body_data']['flashvar'])) { ?>
<div class="feedAttachMedia">
<div class="playVideo">
<a id="media_id_<?=$value['feedid']?>" class="videoCover" title="播放该视频" onclick="javascript:showFlash('<?=$value['body_data']['host']?>', '<?=$value['body_data']['flashvar']?>', this, '<?=$value['feedid']?>');" style="cursor:pointer;"><img id=icon_id_<?=$value['feedid']?> src="<?php if(!empty($value['image_1'])) { ?><?=$value['image_1']?><?php } else { ?>image/videoCover.gif<?php } ?>" class="video"/><em>播放该视频</em></a>
</div>
</div>
<?php } elseif($value['thisapp'] && !empty($value['body_data']['musicvar'])) { ?>
<div class="feedAttachMedia">
<div class="playMusic">
<a onclick="javascript:showFlash('music', '<?=$value['body_data']['musicvar']?>', this, '<?=$value['feedid']?>');" style="cursor:pointer;" class="musicCover" title="播放该音乐"  >播放该音乐</a>
</div>
</div>
<?php } elseif($value['thisapp'] && !empty($value['body_data']['flashaddr'])) { ?>
<div class="feedAttachMedia">
<div class="playFlash">
<a onclick="javascript:showFlash('flash', '<?=$value['body_data']['flashaddr']?>', this, '<?=$value['feedid']?>');" style="cursor:pointer;" class="musicCover" title="播放该音乐" >播放该音乐</a>
</div>
</div>
<?php } ?>
<?php if($value['body_template'] && empty($value['body_data']['flashvar']) && empty($value['body_data']['musicvar']) && empty($value['body_data']['flashaddr'])) { ?>
<div class="feedAttachContent"><?=$value['body_template']?></div>
<?php } ?> </div>
<?php if($value['body_general']) { ?>
<p class="quote"><?=$value['body_general']?><q></q></p>
<?php } ?>
</div>

            <div class="feedFoot">                
                    <span class="time"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span>  -   
                    <?php if(empty($_TPL['hidden_menu'])) { ?><?php if($value['idtype']=='doid') { ?><span class="action"><a onclick="docomment_get('docomment_<?=$value['id']?>', 1);" id="do_a_op_<?=$value['id']?>" href="javascript:void(0)">回复</a></span><?php } elseif(in_array($value['idtype'], array('blogid','picid','sid','pid','eventid'))) { ?><span class="action"><a onclick="feedcomment_get(<?=$value['feedid']?>);" id="feedcomment_a_op_<?=$value['feedid']?>" href="javascript:void(0)">评论</a></span><?php } ?><?php } ?>      
            </div> 
<?php if($value['idtype']) { ?>
<div class="feedComment" id="feedcomment_<?=$value['feedid']?>" style="display:none;"></div>
<?php } ?> 
    </div>
</li>

<?php } elseif(in_array($value['icon'], array('album'))) { ?>

<li class="feedItem feedItem-main feed-<?=$value['icon']?>  " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);">
<div class="feedIcon"><div class="avatar-48"><a href="space.php?uid=<?=$value['uid']?>" title="<?=$_SN[$value['uid']]?>" alt="<?=$_SN[$value['uid']]?>"><?php echo avatar($value[uid],small); ?></a></div></div>
<div class="feedContent feedStyle-short" >	
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<span class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-edit" title="删除">删除</a></span>
<?php } ?>
<h4><?=$value['title_template']?>&nbsp;<?php if($value['body_template']) { ?><?=$value['body_template']?><?php } ?></h4></div>
<div class="feedBody">
<div class="albumSample"><ul class="albumCover">
<?php if($value['image_1']) { ?>
<li><a href="<?=$value['image_1_link']?>"<?=$value['target']?>><img src="<?=$value['image_1']?>" class="photo" /></a>

</li>
<?php } ?>
</ul></div></div>
<div class="feedFoot"><span class="time"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span></div>
</div>

</li>
<?php } elseif(in_array($value['icon'], array('event'))) { ?>

<li class="feedItem feedItem-main feed-<?=$value['icon']?>  " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);">
<div class="feedIcon"><div class="avatar-48"><a href="space.php?uid=<?=$value['uid']?>" title="<?=$_SN[$value['uid']]?>" alt="<?=$_SN[$value['uid']]?>"><?php echo avatar($value[uid],small); ?></a></div></div>
<div class="feedContent feedStyle-short" >	
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<span class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-edit" title="删除">删除</a></span>
<?php } ?>
<h4><?=$value['title_template']?>&nbsp;</h4>
</div>
<div class="feedBody">
<div class="feedAttach feedAttach-event-img">
<?php if($value['image_1']) { ?><div class="feedAttachMedia"><a href="<?=$value['image_1_link']?>"<?=$value['target']?>><img src="<?=$value['image_1']?>" class="poster_pre" /></a></div><?php } ?>
<div class="feedAttachContent"><?php if($value['body_template']) { ?><?=$value['body_template']?><?php } ?></div>
</div>
</div>
<div class="feedFoot">                
<span class="time"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span>  -   
<?php if(empty($_TPL['hidden_menu'])) { ?><?php if(in_array($value['idtype'], array('blogid','picid','sid','pid','eventid'))) { ?><span class="action"><a onclick="feedcomment_get(<?=$value['feedid']?>);" id="feedcomment_a_op_<?=$value['feedid']?>" href="javascript:void(0)">评论</a></span><?php } ?><?php } ?>      
</div> 
<?php if($value['idtype']) { ?>
<div class="feedComment" id="feedcomment_<?=$value['feedid']?>" style="display:none;"></div>
<?php } ?> 
</div>
</li>

<?php } elseif(in_array($value['icon'], array('sitefeed'))) { ?>

<li class="feedItem feedItem-main feed-<?=$value['icon']?>  " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);">
<div class="feedIcon"><div class="avatar-48"><a href="space.php?uid=1" title="发言人马甲" alt="发言人马甲"><img src="image/manage.jpg"/></a></div></div>
<div class="feedContent feedStyle-oneline" >	
<div class="feedHead">
<h4><?=$value['title_template']?></h4>
</div>
</div>
</li>

<?php } else { ?>

<li class="feedItem feedItem-sub feed-<?=$value['icon']?>  " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);">
<div class="feedIcon"><div class="avatar-48"><a href="space.php?uid=<?=$_GET['uid']?>&do=feed&view=<?=$_GET['view']?>&appid=<?=$value['appid']?>&icon=<?=$value['icon']?>"><img src="<?=$value['icon_image']?>" /></a></div></div>
<div class="feedContent feedStyle-oneline" >	
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<span class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-edit" title="删除">删除</a></span>
<?php } ?>
<h4> <?=$value['title_template']?><span class="meta time"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span></h4>
</div>
<?php if(!empty($hiddenfeed_num[$value['icon']])) { ?>
<div class="feedFoot"> 
<div class="feedHead" id="feed_more_<?=$value['feedid']?>" style="display:none;">              
<?php if(is_array($hiddenfeed_list[$value['icon']])) { foreach($hiddenfeed_list[$value['icon']] as $appvalue) { ?>
<?php $appvalue = mkfeed($appvalue); ?>

<h4>
<?=$appvalue['title_template']?>
</h4>
<?php if($appvalue['body_template']) { ?>
<span class="meta time"><?=$appvalue['body_template']?></span>
<?php } ?>

<?php } } ?>
</div>                        
               <span id="appfeed_open_<?=$value['feedid']?>"><a class="act a-tg-down" href="javascript:;" id="feed_a_more_<?=$value['feedid']?>" onclick="feed_more_show('<?=$value['feedid']?>');">显示更多(<?=$hiddenfeed_num[$value['icon']]?>)条</a></span>
        </div>
<?php } ?>

</div>
</li>
<?php } ?>
<?php } } ?>
<li><a href="javascript:;" onclick="filter_more(<?=$start?>);">&laquo; 收起</a></li>
</ul>
</div>
<?php } ?>
</div>
</div>			
</div>
</div>
<?php if(empty($_TPL['getmore'])) { ?>	

            
<?php if($count==$perpage) { ?>
<div class="page" style="padding-top:20px;">
<a href="javascript:;" onclick="feed_more();" id="a_feed_more">查看更多动态</a>
</div>
<?php } ?>

<div id="ajax_wait"></div>

<?php if($space['uid'] && $space['self']) { ?></div><?php } elseif($space['uid']) { ?></div><?php } ?></div>
<span class="whiteBoxFt"><span></span></span>
</div>
</div>
<!--/content-->

<div id="sidebar">
<?php if($isnewer && $task) { ?>
<div class="sidebox">
<div class="ye_l_b">
<div class="task_notice" >
<h2><b>今天</b>你完成了吗？<div class="allTask"><a href="cp.php?ac=task">全部任务</a></div></h2>

<div class="task_notice_body">
<img src="<?=$task['image']?>" alt="" class="iconbg" />
<h3><a href="cp.php?ac=task&op=do&taskid=<?=$task['taskid']?>"><?=$task['name']?></a></h3>
<p>奖励 <span class="num"><?=$task['credit']?></span> 金币</p>
</div>
</div>
</div></div>
<?php } ?>

<?php if($topiclist) { ?>
<div class="ye_r_t"><div class="ye_l_t"><div class="ye_r_b"><div class="ye_l_b">
<div class="task_notice" style="width:230px;">
<?php if(is_array($topiclist)) { foreach($topiclist as $key => $value) { ?>
<div class="task_notice_body">
<?php if($value['pic']) { ?>
<a href="space.php?do=topic&topicid=<?=$value['topicid']?>"><img src="<?=$value['pic']?>" alt="" class="icon" /></a>
<?php } ?>
<h3>
<img src="image/app/topic.gif" align="absmiddle">
<a href="space.php?do=topic&topicid=<?=$value['topicid']?>"><?=$value['subject']?></a>
</h3>
<div class="gray">已有 <span class="num"><?=$value['joinnum']?></span> 人参与</div>
</div>
<?php } } ?>
</div>
</div></div></div></div>
<?php } ?>

<?php if($mtag) { ?>
<div class="sidebox">
<h2 class="title">
<p class="r_option">
<a href="space.php?do=mtag">更多</a>
</p>
活跃的群组
</h2>
<div class="list_group">
<ul class="tagphoto bor_b_3">
<?php if(is_array($mtag)) { foreach($mtag as $value) { ?>
<li><a class="tagphoto_pic user_img_3" target="_blank" href="space.php?do=mtag&tagid=<?=$value['tagid']?>"><img src="<?=$value['pic']?>"/><?php if($value['recommend']==1) { ?><sup class="excellent_group">优秀组</sup><?php } ?></a><a class="tagphoto_name" target="_blank" href="space.php?do=mtag&tagid=<?=$value['tagid']?>"><?=$value['tagname']?></a></li>
<?php } } ?>
</ul>
</div>
<?php if($threadlist) { ?>
<div class="tit_sub">
<h3>热门帖子</h3>
 <a target="_blank" href="space.php?uid=1&do=thread&view=hot">更多</a>
</div>
<div class="list_hot_post">
<ul>
<?php if(is_array($threadlist)) { foreach($threadlist as $value) { ?>
<li class="bor_b_3"><a target="_blank" href="space.php?uid=<?=$value['uid']?>&do=thread&id=<?=$value['tid']?>"><?=$value['subject']?></a></li>
<?php } } ?>
</ul>
</div>
<?php } ?>
</div>
<?php } ?>

<?php if($visitorlist) { ?>
<div class="sidebox">
<h2 class="title">
<p class="r_option">
<a href="space.php?uid=<?=$space['uid']?>&do=friend&view=visitor">全部</a>
</p>
最近来访
<?php if($_SGLOBAL['magic']['detector']) { ?>
<span class="gray"><img src="image/magic/detector.small.gif" title="<?=$_SGLOBAL['magic']['detector']?>" /><a id="a_magic_detector" href="magic.php?mid=detector" onclick="ajaxmenu(event,this.id,1)"><?=$_SGLOBAL['magic']['detector']?></a></span>
<?php } ?>
</h2>
<ul class="avatar_list">
<?php if(is_array($visitorlist)) { foreach($visitorlist as $key => $value) { ?>
<li>
<?php if($value['vusername'] == '') { ?>
<div class="avatar-48"><img src="image/magic/hidden.gif" alt="匿名" /></a></div>
<p>匿名</p>
<p class="gray"><?php echo sgmdate('n月j日',$value[dateline],1); ?></p>
<?php } else { ?>
<div class="avatar-48"><a href="space.php?uid=<?=$value['vuid']?>"><?php echo avatar($value[vuid],small); ?></a></div>
<p<?php if($ols[$value['vuid']]) { ?> class="online_icon_p" title="在线"<?php } ?>><a href="space.php?uid=<?=$value['vuid']?>" title="<?=$_SN[$value['vuid']]?>"><?=$_SN[$value['vuid']]?></a></p>
<p class="gray"><?php echo sgmdate('n月j日',$value[dateline],1); ?></p>
<?php } ?>
</li>
<?php } } ?>
</ul>
</div>
<?php } ?>

<?php if($olfriendlist) { ?>
<div class="sidebox">
<h2 class="title">
<p class="r_option">
<a href="space.php?uid=<?=$space['uid']?>&do=friend">全部</a>
</p>
我的好友
<?php if($_SGLOBAL['magic']['visit']) { ?>
<span class="gray"><img src="image/magic/visit.small.gif" title="<?=$_SGLOBAL['magic']['visit']?>" /><a id="a_magic_visit" href="magic.php?mid=visit" onclick="ajaxmenu(event,this.id,1)"><?=$_SGLOBAL['magic']['visit']?></a></span>
<?php } ?>
</h2>
<ul class="avatar_list">
<?php if(is_array($olfriendlist)) { foreach($olfriendlist as $key => $value) { ?>
<li>
<div class="avatar-48"><a href="space.php?uid=<?=$value['uid']?>"><?php echo avatar($value[uid],small); ?></a></div>
<p<?php if($ols[$value['uid']]) { ?> class="online_icon_p" title="在线"<?php } ?>><a href="space.php?uid=<?=$value['uid']?>" title="<?=$_SN[$value['uid']]?>"><?=$_SN[$value['uid']]?></a></p>
<p class="gray"><?php if($value['lastactivity']) { ?><?php echo sgmdate('H:i',$value[lastactivity],1); ?><?php } else { ?>热度(<?=$value['num']?>)<?php } ?></p>
</li>
<?php } } ?>
</ul>
</div>
<?php } ?>

<?php if($newspacelist) { ?>
<div class="sidebox">
<h2 class="title">
<p class="r_option">
<a href="space.php?do=top">排行</a>
</p>
热烈欢迎新成员
</h2>
<ul class="avatar_list">
<?php if(is_array($newspacelist)) { foreach($newspacelist as $key => $value) { ?>
<li>
<div class="avatar-48"><a href="space.php?uid=<?=$value['uid']?>"><?php echo avatar($value[uid],small); ?></a></div>
<p<?php if($ols[$value['uid']]) { ?> class="online_icon_p" title="在线"<?php } ?>><a href="space.php?uid=<?=$value['uid']?>" title="<?=$_SN[$value['uid']]?>"><?=$_SN[$value['uid']]?></a></p>
<p class="gray"><?php echo sgmdate('n月j日',$value[dateline],1); ?></p>
</li>
<?php } } ?>
</ul>
</div>
<?php } ?>

<?php if($birthlist) { ?>
<div class="homeInvite">
<div class="ye_l_b">
<h3>好友生日提醒</h3>
<div class="box">
<table cellpadding="2" cellspacing="4">
<?php if(is_array($birthlist)) { foreach($birthlist as $key => $values) { ?>
<tr>
<td align="right" valign="top" style="padding-left:10px;">
<?php if($values['0']['istoday']) { ?>今天<?php } else { ?><?=$values['0']['birthmonth']?>-<?=$values['0']['birthday']?><?php } ?>
</td>
<td style="padding-left:10px;">
<ul>
<?php if(is_array($values)) { foreach($values as $value) { ?>
<li><a href="space.php?uid=<?=$value['uid']?>"><?=$_SN[$value['uid']]?></a></li>
<?php } } ?>
</ul>
</td>
</tr>
<?php } } ?>
</table>
</div>
</div>
</div>
<?php } ?>

<div class="homeInvite">
<h3>搜索用户</h3>
<form method="get" action="cp.php" style="padding:5px 0;">
<input name="searchkey" value="" size="20" class="t_input" type="text">
<input name="searchsubmit" value="找人" class="submit" type="submit">
<input type="hidden" name="searchmode" value="1" />
<input type="hidden" name="ac" value="friend" />
<input type="hidden" name="op" value="search" />
</form>
<ul>
<li class="homeInvite-invite"><a href="cp.php?ac=invite">邀请好友加入<?=$_SCONFIG['sitename']?>得金币</a></li>
<li class="homeInvite-search"><a href="cp.php?ac=friend&op=search">看看哪些朋友在<?=$_SCONFIG['sitename']?></a></li>
</ul>

</div>

</div>
<!--/sidebar-->

<script type="text/javascript">

var next = <?=$start?>;
function feed_more() {
var x = new Ajax('XML', 'ajax_wait');
var html = '';
next = next + <?=$perpage?>;
x.get('cp.php?ac=feed&op=get&start='+next+'&view=<?=$_GET['view']?>&appid=<?=$_GET['appid']?>&icon=<?=$_GET['icon']?>&filter=<?=$_GET['filter']?>&day=<?=$_GET['day']?>', function(s){
html = '<h4 class="feedtime">以下是新读取的动态</h4>' + s;
$('homeFeedList').innerHTML += html;
});
}

function filter_more(id) {
if($('feed_filter_div_'+id).style.display == '') {
$('feed_filter_div_'+id).style.display = 'none';
$('feed_filter_notice_'+id).style.display = '';
} else {
$('feed_filter_div_'+id).style.display = '';
$('feed_filter_notice_'+id).style.display = 'none';
}
}

function close_feedbox() {
var x = new Ajax();
x.get('cp.php?ac=common&op=closefeedbox', function(s){
$('feed_box').style.display = 'none';
});
}

var elems = selector('li[class~=magicthunder]', $('feed_div')); 
for(var i=0; i<elems.length; i++){		
magicColor(elems[i]); 
}
</script>

<?php my_checkupdate(); ?>
<?php my_showgift(); ?>
﻿<?php if(empty($_SGLOBAL['inajax'])) { ?>
<?php if(empty($_TPL['nosidebar'])) { ?>
<?php if($_SGLOBAL['ad']['contentbottom']) { ?><br style="line-height:0;clear:both;"/><div id="ad_contentbottom"><?php adshow('contentbottom'); ?></div><?php } ?>
</div>

<!--/mainarea-->
<div id="bottom"></div>
</div>
<!--/main-->
<?php } ?>

<div id="footer">

<p class="r_option">
<a href="javascript:;" onclick="window.scrollTo(0,0);" id="a_top" title="TOP"><img src="image/top.gif" alt="" style="padding: 5px 6px 6px;" /></a>
</p>

<?php if($_SGLOBAL['ad']['footer']) { ?>
<p style="padding:5px 0 10px 0;"><?php adshow('footer'); ?></p>
<?php } ?>

<?php if($_SCONFIG['close']) { ?>
<p style="color:blue;font-weight:bold;">
提醒：当前站点处于关闭状态
</p>
<?php } ?>
<p>
<?=$_SCONFIG['sitename']?> - 
<a href="mailto:<?=$_SCONFIG['adminemail']?>">联系我们</a>
<?php if($_SCONFIG['miibeian']) { ?> - <a  href="http://www.miibeian.gov.cn" target="_blank"><?=$_SCONFIG['miibeian']?></a><?php } ?>
</p>
<p>
Powered by <a  href="http://u.discuz.net" target="_blank"><strong>UCenter Home</strong></a> <span title="<?php echo X_RELEASE; ?>"><?php echo X_VER; ?></span>
<?php if(!empty($_SCONFIG['licensed'])) { ?><a  href="http://license.comsenz.com/?pid=7&host=<?=$_SERVER['HTTP_HOST']?>" target="_blank">Licensed</a><?php } ?>
&copy; 2001-2011 <a  href="http://www.comsenz.com" target="_blank">Comsenz Inc.</a>
</p>
<?php if($_SCONFIG['debuginfo']) { ?>
<p><?php echo debuginfo(); ?></p>
<?php } ?>
</div>
</div>
<!--/wrap-->

<?php if($_SGLOBAL['appmenu']) { ?>
<ul id="ucappmenu_menu" class="dropmenu_drop" style="display:none;">
<li><a href="<?=$_SGLOBAL['appmenu']['url']?>" title="<?=$_SGLOBAL['appmenu']['name']?>" target="_blank"><?=$_SGLOBAL['appmenu']['name']?></a></li>
<?php if(is_array($_SGLOBAL['appmenus'])) { foreach($_SGLOBAL['appmenus'] as $value) { ?>
<li><a href="<?=$value['url']?>" title="<?=$value['name']?>" target="_blank"><?=$value['name']?></a></li>
<?php } } ?>
</ul>
<?php } ?>


<?php if($_SGLOBAL['supe_uid']) { ?>
<?php if(!isset($_SCOOKIE['checkpm'])) { ?>
<script language="javascript"  type="text/javascript" src="cp.php?ac=pm&op=checknewpm&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>
<?php if(!isset($_SCOOKIE['synfriend'])) { ?>
<script language="javascript"  type="text/javascript" src="cp.php?ac=friend&op=syn&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>
<?php } ?>
<?php if(!isset($_SCOOKIE['sendmail'])) { ?>
<script language="javascript"  type="text/javascript" src="do.php?ac=sendmail&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>

<?php if($_SGLOBAL['ad']['couplet']) { ?>
<script language="javascript" type="text/javascript" src="source/script_couplet.js"></script>
<div id="uch_couplet" style="z-index: 10; position: absolute; display:none">
<div id="couplet_left" style="position: absolute; left: 2px; top: 60px; overflow: hidden;">
<div style="position: relative; top: 25px; margin:0.5em;" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('uch_couplet');"><img src="image/advclose.gif"></div>
<?php adshow('couplet'); ?>
</div>
<div id="couplet_rigth" style="position: absolute; right: 2px; top: 60px; overflow: hidden;">
<div style="position: relative; top: 25px; margin:0.5em;" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('uch_couplet');"><img src="image/advclose.gif"></div>
<?php adshow('couplet'); ?>
</div>
<script type="text/javascript">
lsfloatdiv('uch_couplet', 0, 0, '', 0).floatIt();
</script>
</div>
<?php } ?>
<?php if($_SCOOKIE['reward_log']) { ?>
<script type="text/javascript">
showreward();
</script>
<?php } ?>
</body>
</html>
<?php } ?>
<?php } ?><?php ob_out();?>