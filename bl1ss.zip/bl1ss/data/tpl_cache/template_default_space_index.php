<?php if(!defined('IN_UCHOME')) exit('Access Denied');?><?php subtplcheck('template/default/space_index|template/default/space_header|template/default/header|template/default/space_istatus|template/default/space_ifeed_li|template/default/space_icomment_li|template/default/footer', '1303269236', 'template/default/space_index');?>﻿<?php $_TPL['nosidebar']=1; ?>
<?php if(!empty($space['theme'])) { ?>
    ﻿<?php if(empty($_SGLOBAL['inajax'])) { ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=<?=$_SC['charset']?>" />
<meta http-equiv="x-ua-compatible" content="ie=7" />
<title><?php if($_TPL['titles']) { ?><?php if(is_array($_TPL['titles'])) { foreach($_TPL['titles'] as $value) { ?><?php if($value) { ?><?=$value?> - <?php } ?><?php } } ?><?php } ?><?php if($_SN[$space['uid']]) { ?><?=$_SN[$space['uid']]?> - <?php } ?><?=$_SCONFIG['sitename']?> - Powered by UCenter Home</title>
<script language="javascript" type="text/javascript" src="source/script_jquery.js"></script>
<script language="javascript" type="text/javascript" src="source/script_cookie.js"></script>
<script language="javascript" type="text/javascript" src="source/script_common.js"></script>
<script language="javascript" type="text/javascript" src="source/script_menu.js"></script>
<script language="javascript" type="text/javascript" src="source/script_ajax.js"></script>
<script language="javascript" type="text/javascript" src="source/script_face.js"></script>
<script language="javascript" type="text/javascript" src="source/script_manage.js"></script>
<style type="text/css">
@import url(template/default/style.css);
@import url(template/default/toolbar.css);
<?php if($_TPL['css']) { ?>
@import url(template/default/<?=$_TPL['css']?>.css);
<?php } ?>
<?php if(!empty($_SGLOBAL['space_theme'])) { ?>
@import url(theme/<?=$_SGLOBAL['space_theme']?>/style.css);
<?php } elseif($_SCONFIG['template'] != 'default') { ?>
@import url(template/<?=$_SCONFIG['template']?>/style.css);
<?php } ?>
<?php if(!empty($_SGLOBAL['space_css'])) { ?>
<?=$_SGLOBAL['space_css']?>
<?php } ?>
</style>
<link rel="shortcut icon" href="image/favicon.ico" />
<link rel="edituri" type="application/rsd+xml" title="rsd" href="xmlrpc.php?rsd=<?=$space['uid']?>" />
</head>
<body>

<div id="append_parent"></div>
<div id="ajaxwaitid"></div>
<div id="divToolbarRoot" class="toolbar_v3" style="height: auto;">
<div class="t_wrap" id="divToolbarBody">
<div class="panel_left">
<p class="bor_r mode_userinfo">
<a href="index.php"><img class="icon_toolbar_logo logo" target="_blank" src="image/pageHd.gif" title="<?=$_SCONFIG['sitename']?>"></a> 
<?php if($_SGLOBAL['supe_uid']) { ?>
<a class="user_name" title="我的主页" href="space.php?uid=<?=$_SGLOBAL['supe_uid']?>"><?=$_SN[$_SGLOBAL['supe_uid']]?></a> <span class="line">[</span><a class="quit" title="退出登录" href="cp.php?ac=common&op=logout&uhash=<?=$_SGLOBAL['uhash']?>">退出</a><span class="line">]</span>&nbsp;<a title="个性设置" style="color: rgb(255, 0, 0) ! important;" target="_blank" class="user_name" href="cp.php?ac=theme">主页设置</a>
<?php } else { ?>
                欢迎您
    <a class="user_name" href="do.php?ac=<?=$_SCONFIG['login_action']?>">登录</a> | 
    <a class="user_name" href="do.php?ac=<?=$_SCONFIG['register_action']?>">注册</a>
<?php } ?>
</p>
<div class="mode_quicklinks" id="LinksArea">
<a class="quick_links" title="快速入口" href="javascript:;" id="LinksEntry"><span>快速入口</span></a>
<div style="display: none;" class="quick_links_list" id="LinksMenu">
<div style="width:113px;" class="inner" id="divQLinksMenuList">
     <div class="panel_list">
<div class="list">
<?php if($_SGLOBAL['supe_uid']) { ?>
<h3>站点导航~</h3>
<ul>
<li><a href="index.php"><img src="image/icon/thread.gif">首页</a></li>
<li><a href="network.php"><img src="image/icon/click.gif">随便看看</a></li>
<li><a href="space.php"><img src="image/icon/profile.gif">我的主页</a></li>
<li><a href="space.php?do=friend"><img src="image/icon/friend.gif">我的好友</a></li>
<li><a href="space.php?do=pm"><img src="image/icon/pm.gif">站内信</a></li>
<li><a href="space.php?do=notice"><img src="image/icon/sitefeed.gif">通知</a></li>
</ul>
<?php } else { ?>
<h3>还没登陆？先随便看看吧~</h3>
<ul>
<li><a href="index.php"><img src="image/icon/thread.gif">首页</a></li>
<li><a href="network.php"><img src="image/icon/click.gif">随便看看</a></li>
</ul>
<?php } ?>	
</div>
</div>
</div>
</div>
</div>
<p class="bor_r mode_control_button"><a class="img_hover" title="我的个人中心" href="index.php"><span>&nbsp;</span><img class="icon_toolbar_cut" src="image/b.gif" id="imgTbSwitchMode"></a><a class="img_hover" title="个人设置" href="cp.php"><span>&nbsp;</span><img class="icon_toolbar_setting" src="image/b.gif"></a></p>
           <?php if($_SGLOBAL['supe_uid']) { ?>
<?php if($_SGLOBAL['member']['allnotenum']) { ?><div class="mode_other_business"><a class="img_hover" target="_blank" title="有新通知" href="space.php?do=notice"><span>&nbsp;</span><img src="image/gif-0257.gif">&nbsp;<b>有新通知</b>【<?=$_SGLOBAL['member']['allnotenum']?>】</a></div><?php } ?>
<?php if(!empty($_SGLOBAL['member']['newpm'])) { ?><div class="mode_other_business"><a class="img_hover" target="_blank" title="有新消息" href="space.php?do=pm"><span>&nbsp;</span><img src="image/gif-0259.gif">&nbsp;<b>有新消息</b></a></div><?php } ?>
           <?php } ?>
</div>

<div class="panel_right"></div>
</div>
<p title="隐藏工具条" class="panel_flex" id="pTbCtrl"><img class="icon_toolbar_up" src="image/b.gif" id="imgTbCCtrl"></p>
</div>


<div id="wrap">

<?php if(empty($_TPL['ownermode'])) { ?>
<div class="menu_t_b big_title" id="titleBar">
<div class="bg_menu_t" id="titleBG">
<div class="info">
<strong id="spacename">【<?php if($space['name']) { ?><?=$space['name']?><?php } else { ?><?=$space['username']?><?php } ?>的个人主页】</strong><span id="diamon" style="cursor: pointer;"><span class="yellow_lvn"><span><?=$space['star']?></span></span></span><a class="num" id="spaceurl" href="<?=$space['domainurl']?>" onclick="javascript:setCopy('<?=$space['domainurl']?>');return false;"><?=$space['domainurl']?></a>
</div>
<div class="op">
<?php if($space['self']) { ?>
<a title="装扮空间(ctrl+g)" class="ownermode" href="cp.php?ac=theme"><span>装扮主页</span></a>
<a title="隐私设置" class="clientmode" href="cp.php?ac=privacy" ><span>隐私设置</span></a>
<a title="设置" class="ownermode" href="cp.php?ac=avatar"><span>修改头像</span></a>
<a title="个人中心" class="ownermode" href="index.php"><span>个人中心</span></a>
<?php } else { ?>
<a title="打个招呼" class="clientmode" href="cp.php?ac=poke&op=send&uid=<?=$space['uid']?>" id="a_poke" onclick="ajaxmenu(event, this.id, 1)" ><span>打个招呼</span></a>
<?php if(!$space['isfriend']) { ?>
<a title="加为好友" class="clientmode" href="cp.php?ac=friend&op=add&uid=<?=$space['uid']?>" id="a_friend_li" onclick="ajaxmenu(event, this.id, 1)" ><span>加为好友</span></a>
<?php } ?>
<?php if($space['isfriend']) { ?>
<a title="解除好友" class="clientmode" href="cp.php?ac=friend&op=ignore&uid=<?=$space['uid']?>" id="a_ignore" onclick="ajaxmenu(event, this.id)" ><span>解除好友</span></a>
<?php } ?>
<a title="违规举报" class="ownermode" href="cp.php?ac=common&op=report&idtype=uid&id=<?=$space['uid']?>" id="a_report" onclick="ajaxmenu(event, this.id, 1)" ><span>违规举报</span></a>
<?php if(checkperm('managename')||checkperm('managespacegroup')||checkperm('managespaceinfo')||checkperm('managespacecredit')||checkperm('managespacenote')) { ?>
<a title="管理用户" class="ownermode" href="admincp.php?ac=space&op=manage&uid=<?=$space['uid']?>" id="a_infoCenter"><span>管理用户</span></a>
<?php } ?>
            <?php } ?>
</div>
<div class="modenav">
<a title="主页" class="ownermode" href="space.php?uid=<?=$space['uid']?>"><span>主页</span></a>
<a title="一句话" class="ownermode" href="javascript:;" onclick="getindex('doing');"><span>一句话</span></a>
<a title="日志" class="clientmode" href="javascript:;" onclick="getindex('blog');" ><span>日志</span></a>
<a title="相册" class="ownermode" href="javascript:;" onclick="getindex('album');"><span>相册</span></a>
<a title="话题" class="ownermode" href="javascript:;" onclick="getindex('thread');"><span>话题</span></a>
<a title="投票" class="ownermode" href="javascript:;" onclick="getindex('poll');"><span>投票</span></a>
<a title="分享" class="ownermode" href="javascript:;" onclick="getindex('share');"><span>分享</span></a>
<a title="个人档" class="ownermode" href="javascript:;" onclick="getindex('info');"><span>个人档</span></a>
<a title="好友" class="ownermode" href="javascript:;" onclick="getindex('friend');"><span>好友</span></a>	
</div>
</div>
    </div>
<?php } ?>

<?php } ?>

<?php } else { ?>
<?php $_TPL['ownermode']=1; ?>
﻿<?php if(empty($_SGLOBAL['inajax'])) { ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="content-type" content="text/html; charset=<?=$_SC['charset']?>" />
<meta http-equiv="x-ua-compatible" content="ie=7" />
<title><?php if($_TPL['titles']) { ?><?php if(is_array($_TPL['titles'])) { foreach($_TPL['titles'] as $value) { ?><?php if($value) { ?><?=$value?> - <?php } ?><?php } } ?><?php } ?><?php if($_SN[$space['uid']]) { ?><?=$_SN[$space['uid']]?> - <?php } ?><?=$_SCONFIG['sitename']?></title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<script language="javascript" type="text/javascript" src="source/script_jquery.js"></script>
<script language="javascript" type="text/javascript" src="source/script_cookie.js"></script>
<script language="javascript" type="text/javascript" src="source/script_common.js"></script>
<script language="javascript" type="text/javascript" src="source/script_menu.js"></script>
<script language="javascript" type="text/javascript" src="source/script_ajax.js"></script>
<script language="javascript" type="text/javascript" src="source/script_face.js"></script>
<script language="javascript" type="text/javascript" src="source/script_manage.js"></script>
<link id="skinc" href="/template/default/style.css" rel="stylesheet" type="text/css" />
<?php if($_TPL['css']) { ?>
<link id="skinc" href="/template/default/<?=$_TPL['css']?>.css" rel="stylesheet" type="text/css" />
<?php } ?>
<?php if(!empty($_SGLOBAL['space_theme'])) { ?>
<link id="skinc" href="/theme/<?=$_SGLOBAL['space_theme']?>/style.css" rel="stylesheet" type="text/css" />
<?php } elseif($_SCONFIG['template'] != 'default') { ?>
<link id="skinc" href="/template/<?=$_SCONFIG['template']?>/style.css" rel="stylesheet" type="text/css" />
<?php } ?>

<style type="text/css">
<?php if(!empty($_SGLOBAL['space_css'])) { ?>
<?=$_SGLOBAL['space_css']?> 
<?php } ?>
</style>
<link rel="shortcut icon" href="image/favicon.ico" />
<link rel="edituri" type="application/rsd+xml" title="rsd" href="xmlrpc.php?rsd=<?=$space['uid']?>" />

</head>
<body>
<div id="append_parent"></div>
<div id="ajaxwaitid"></div>
<div id="header">
<div class="wp">
<div id="logo"></div>

<div id="nav">
<div>
<?php if($_SGLOBAL['supe_uid']) { ?>
<a href="space.php">myspace</a>
<a href="cp.php?ac=common&op=logout&uhash=<?=$_SGLOBAL['uhash']?>">logout</a>
<?php } else { ?>
<a href="do.php?ac=<?=$_SCONFIG['login_action']?>">Share</a> | 
<a href="do.php?ac=<?=$_SCONFIG['login_action']?>">Login</a> | 
<a href="do.php?ac=<?=$_SCONFIG['register_action']?>">Register</a>
<?php } ?>
</div>
<div id="navitem">
<a href="network.php"><img src="/template/default/i/nav_home.jpg" /></a>
<a href="space.php?act=home&view=all"><img src="/template/default/i/nav_comm.jpg" /></a>
<a href="books.php"><img src="/template/default/i/nav_books.jpg" /></a>
<a href="movies.php"><img src="/template/default/i/nav_mov.jpg" /></a>
<a href="music.php"><img src="/template/default/i/nav_mus.jpg" /></a>
<a href="arts.php"><img src="/template/default/i/nav_art.jpg" /></a>
</div>
</div>
<div class="cl"></div>
</div>
</div>

<div id="wrap">

<?php if(empty($_TPL['nosidebar'])) { ?>
<div id="main">
<div id="app_sidebar">
<?php if($_SGLOBAL['supe_uid']) { ?>
    <h2>Personal Center</h2>
<ul class="app_list" id="default_userapp">
<li><a href="space.php?do=doing"><span class="icon i-app24 i-app24-status"></span>Fresh things</a></li>
<li><a href="space.php?do=album"><span class="icon i-app24 i-app24-album"></span>Albums</a><em><a href="cp.php?ac=upload" class="gray">upload</a></em></li>
<li><a href="space.php?do=blog"><span class="icon i-app24 i-app24-blog"></span>WebLog</a><em><a href="cp.php?ac=blog" class="gray">issue</a></em></li>
</ul>

            <h2>互动中心</h2>
<ul class="app_list" id="default_userapp">
<li><a href="space.php?do=poll"><span class="icon i-app24 i-app24-vote"></span>投票</a><em><a href="cp.php?ac=poll" class="gray">发起</a></em></li>
<li><a href="space.php?do=mtag"><span class="icon i-app24 i-app24-thread"></span>群组</a><em><a href="cp.php?ac=thread" class="gray">话题</a></em></li>
<li><a href="space.php?do=event"><span class="icon i-app24 i-app24-event"></span>活动</a><em><a href="cp.php?ac=event" class="gray">发起</a></em></li>
<li><a href="space.php?do=share"><span class="icon i-app24 i-app24-share"></span>分享</a></li>
<li><a href="space.php?do=topic"><span class="icon i-app24 i-app24-hot"></span>专题</a></li>
</ul>

           

<div id="appbarActions">
<?php if($_SCONFIG['my_status']) { ?><a class="act a-manage" href="cp.php?ac=userapp&op=menu" >设置</a>&nbsp;<?php } ?><?php if($_SGLOBAL['my_menu_more']) { ?><a href="javascript:;" id="a_app_more" onclick="userapp_open();" class="off">展开</a><?php } ?>
            </div>

<?php } else { ?>
<div class="bar_text">
<form id="loginform" name="loginform" action="do.php?ac=<?=$_SCONFIG['login_action']?>&ref" method="post">
<input type="hidden" name="formhash" value="<?php echo formhash(); ?>" />
<p><h2>登陆更精彩...</h2></p>
<p>账号:</p>
<p><input type="text" name="username" id="username" class="t_input" size="15" value="" /></p>
<p>密码:</p>
<p><input type="password" name="password" id="password" class="t_input" size="15" value="" /></p>
<p ><input type="checkbox" id="cookietime" name="cookietime" value="315360000" checked /><label for="cookietime">记住我</label></p>
<p>
<input type="submit" id="loginsubmit" name="loginsubmit" value="登录" class="submit" />
<input type="button" name="regbutton" value="注册" class="button" onclick="urlto('do.php?ac=<?=$_SCONFIG['register_action']?>');">
</p>
</form>

</div>
<?php } ?>
</div>

<div id="mainarea">

<?php if($_SGLOBAL['ad']['contenttop']) { ?><div id="ad_contenttop"><?php adshow('contenttop'); ?></div><?php } ?>
<?php } ?>

<?php } ?>

<?php } ?>

<?php if($narrowlist || $widelist) { ?>
<script type="text/javascript" src="source/script_swfobject.js"></script>
<?php } ?>
<div class="wrapBox">
<span class="wrapBoxHd"><span></span></span>
<div class="wrapBoxBd">

<div class="page-profile" id="page-profile">
    <div class="lay " id="profileIndexLay">
    
<div class="colMain">
<div class="colInt">
<div id="profileAvatar">						
<div class="avatarWrap"><i><i><i><i>
<?php if($space['magicstar'] && $space['magicexpire']>$_SGLOBAL['timestamp']) { ?>
<div class="magicstar">
<object codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,45,0" width="165" height="220">
<param name="movie" value="image/magic/star/<?=$space['magicstar']?>.swf" />
<param name="quality" value="high" />
<param NAME="wmode" value="transparent">
<embed src="image/magic/star/<?=$space['magicstar']?>.swf" quality="high" pluginspage="http://www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash" type="application/x-shockwave-flash"  wmode="transparent" width="165" height="220"></embed>
</object>
</div>
<div class="magicavatar"><?php echo avatar($space[uid],big); ?></div><?php } else { ?><?php echo avatar($space[uid],big); ?><?php } ?>
</i></i></i></i></div>
<?php if($space['self'] && $_SGLOBAL['magic']['superstar']) { ?>
<div class="avatarChange">
<?php if($space['magicstar'] && $space['magicexpire']>$_SGLOBAL['timestamp']) { ?>
<a id="a_magic_superstar" href="cp.php?ac=magic&op=cancelsuperstar" onclick="ajaxmenu(event, this.id)" class="act a-avatar">取消超级明星</a>
<?php } else { ?>
<a id="a_magic_superstar" href="magic.php?mid=superstar" onclick="ajaxmenu(event, this.id, 1)" class="act a-avatar">我要变超级明星</a>
<?php } ?>
</div>
<?php } ?>
</div>
<div id="profileActions">
<ul>
<?php if($space['self']) { ?>
<li><a href="cp.php?ac=avatar" class="act a-avatar">修改头像</a></li>
<li><a href="cp.php?ac=profile" class="act a-profile">修改档案</a></li>
<li><a href="cp.php?ac=theme" class="act a-profile">主页风格</a></li>
<li><a href="cp.php?ac=credit" class="act a-profile">我的积分</a></li>
<?php if($_SCONFIG['sendmailday']) { ?>
<li><a href="cp.php?ac=sendmail" class="act a-profile">邮件提醒</a></li>
<?php } ?>
<li><a href="cp.php?ac=privacy" class="act a-profile">隐私筛选</a></li>
<?php } else { ?>
<?php if(!$space['isfriend']) { ?>
<li><a href="cp.php?ac=friend&op=add&uid=<?=$space['uid']?>" id="a_friend_li" onclick="ajaxmenu(event, this.id, 1)" class="act a-leaveMsg">加为好友</a></li>
<?php } ?>
<li><a href="#comment"  class="act a-leaveMsg">给我留言</a></li>
<li><a href="cp.php?ac=poke&op=send&uid=<?=$space['uid']?>" id="a_poke" onclick="ajaxmenu(event, this.id, 1)" class="act a-leaveMsg">打个招呼</a></li>
<li><a href="cp.php?ac=pm&uid=<?=$space['uid']?>" id="a_pm" onclick="ajaxmenu(event, this.id, 1)"  class="act a-mail">发站内信</a></li>
<?php if($space['isfriend']) { ?>
<li><a href="cp.php?ac=friend&op=ignore&uid=<?=$space['uid']?>" id="a_ignore" onclick="ajaxmenu(event, this.id)" class="act a-leaveMsg">解除好友</a></li>
<?php } ?>
<li><a href="cp.php?ac=common&op=report&idtype=uid&id=<?=$space['uid']?>" id="a_report" onclick="ajaxmenu(event, this.id, 1)" class="act a-leaveMsg">违规举报</a></li>
<?php if(checkperm('managename')||checkperm('managespacegroup')||checkperm('managespaceinfo')||checkperm('managespacecredit')||checkperm('managespacenote')) { ?>
<li><a href="admincp.php?ac=space&op=manage&uid=<?=$space['uid']?>" id="a_manage" class="act a-leaveMsg">管理用户</a></li>
<?php } ?>
<li><a href="cp.php?ac=share&type=space&id=<?=$space['uid']?>" class="act a-share" id="a_share" onclick="ajaxmenu(event, this.id, 1)">分享用户</a></li>
<?php } ?>  
<li><a href="rss.php?uid=<?=$space['uid']?>" id="i_rss" class="act a-share" title="订阅 RSS">订阅主页</a></li>

</ul>
</div>
<div id="profileSysApps">
<ul>
<li><a href="javascript:;" onclick="getindex('info');"><span class="icon i-app-profile"></span></a> <a href="javascript:;" onclick="getindex('info');"><?php if($space['self']) { ?>我的<?php } else { ?>他的<?php } ?>档案</a></li>
<li><a href="javascript:;" onclick="getindex('doing');"><span class="icon i-app-doing"></span></a> <a href="javascript:;" onclick="getindex('doing');"><?php if($space['self']) { ?>我的<?php } else { ?>他的<?php } ?>记录</a><?php if($space['doingnum']) { ?><span class="count">(<?=$space['doingnum']?>)</span><?php } ?></li>
<li><a href="javascript:;" onclick="getindex('blog');"><span class="icon i-app-blog"></span></a> <a href="javascript:;" onclick="getindex('blog');"><?php if($space['self']) { ?>我的<?php } else { ?>他的<?php } ?>日志</a><?php if($space['blognum']) { ?><span class="count">(<?=$space['blognum']?>)</span><?php } ?></li>
<li><a href="javascript:;" onclick="getindex('album');"><span class="icon i-app-album"></span></a> <a href="javascript:;" onclick="getindex('album');"><?php if($space['self']) { ?>我的<?php } else { ?>他的<?php } ?>相册</a><?php if($space['albumnum']) { ?><span class="count">(<?=$space['albumnum']?>)</span><?php } ?></li>
<li><a href="javascript:;" onclick="getindex('thread');"><span class="icon i-app-thread"></span></a> <a href="javascript:;" onclick="getindex('thread');"><?php if($space['self']) { ?>我的<?php } else { ?>他的<?php } ?>话题</a><?php if($space['threadnum']) { ?><span class="count">(<?=$space['threadnum']?>)</span><?php } ?></li>
<li><a href="javascript:;" onclick="getindex('poll');"><span class="icon i-app-poll"></span></a> <a href="javascript:;" onclick="getindex('poll');"><?php if($space['self']) { ?>我的<?php } else { ?>他的<?php } ?>投票</a><?php if($space['pollnum']) { ?><span class="count">(<?=$space['pollnum']?>)</span><?php } ?></li>
<li><a href="javascript:;" onclick="getindex('event');"><span class="icon i-app-event"></span></a> <a href="javascript:;" onclick="getindex('event');"><?php if($space['self']) { ?>我的<?php } else { ?>他的<?php } ?>活动</a><?php if($space['eventnum']) { ?><span class="count">(<?=$space['eventnum']?>)</span><?php } ?></li>
<li><a href="javascript:;" onclick="getindex('share');"><span class="icon i-app-share"></span></a> <a href="javascript:;" onclick="getindex('share');"><?php if($space['self']) { ?>我的<?php } else { ?>他的<?php } ?>分享</a><?php if($space['sharenum']) { ?><span class="count">(<?=$space['sharenum']?>)</span><?php } ?></li>
<li><a href="javascript:;" onclick="getindex('friend');"><span class="icon i-app-friend"></span></a> <a href="javascript:;" onclick="getindex('friend');"><?php if($space['self']) { ?>我的<?php } else { ?>他的<?php } ?>好友</a><?php if($space['friendnum']) { ?><span class="count">(<?=$space['friendnum']?>)</span><?php } ?></li>
</ul>
</div>
<div id="profileApps">
<ul>
  
</ul>
</div>
<?php if($guidelist) { ?>
<div class="mod" id="space_app_guide">	
<div class="mCt">
<div class="mHd">
<h3>应用菜单</h3>
</div>
<div class="mBd">
<ul class="line_list">
<?php if(is_array($guidelist)) { foreach($guidelist as $value) { ?>
<li id="space_app_profilelink_<?=$value['appid']?>">
<?php if($space['self']) { ?>
<a href="cp.php?ac=space&op=delete&appid=<?=$value['appid']?>&type=profilelink" id="user_app_profile_<?=$value['appid']?>" class="r_option float_del" style="position: static;" onclick="ajaxmenu(event, this.id)" title="删除">删除</a>
<?php } ?>
<img src="http://appicon.manyou.com/icons/<?=$value['appid']?>"><?php eval($value[profilelink]); ?>
</li>
<?php } } ?>
</ul>
</div>
</div>
</div>
<?php } ?>
<?php if(is_array($narrowlist)) { foreach($narrowlist as $value) { ?>
<div class="mod" id="space_app_<?=$value['appid']?>">	
<div class="mCt">
<div class="mHd">
<h3>
<?php if($space['self']) { ?>
<a href="cp.php?ac=space&op=delete&appid=<?=$value['appid']?>" id="user_app_<?=$value['appid']?>" class="r_option float_del" onclick="ajaxmenu(event, this.id)" title="删除">删除</a>
<?php } ?><a href="<?=$value['appurl']?>"><?=$value['appname']?></a>
</h3>
</div>
<?php if($value['myml']) { ?>
<div class="mBd">
<?php eval($value[myml]); ?>
</div>
<?php } ?>
</div>
</div>
<?php } } ?>
</div>
</div>
<!--左侧 end-->
<div class="colRight">
    <div id="profileUser">
<div class="name">Hi, 我是
<?php if($_SCONFIG['realname']) { ?>
<?php if($space['name']) { ?><a href="space.php?uid=<?=$space['uid']?>"<?php g_color($space[groupid]); ?>><strong><?=$space['name']?></strong></a><?php } else { ?>未填写实名<?php } ?>
&nbsp;<span class="uspace">(用户名:<?=$space['username']?>)</span>
<?php } else { ?>
<a href="space.php?uid=<?=$space['uid']?>"<?php g_color($space[groupid]); ?>><strong><?=$space['username']?></strong></a>
<?php if($space['name']) { ?>&nbsp;<span class="uspace">(姓名:<?=$space['name']?>)</span><?php } ?>
<?php } ?>
<?php if($_SCONFIG['realname']) { ?>
<?php if($space['namestatus']) { ?>
&nbsp;<img src="image/realname_yes.gif" align="absmiddle" alt="已通过实名认证">
<?php } else { ?>
&nbsp;<img src="image/realname_no.gif" align="absmiddle" alt="未通过实名认证"> <span class="gray">实名未认证</span>
<?php } ?>
<?php } ?>

<?php if($_SCONFIG['videophoto']) { ?>	
<?php if($space['videostatus']) { ?>
&nbsp;<img src="image/videophoto_yes.gif" align="absmiddle" alt="已通过视频认证"> <a id="a_space_videophoto" href="space.php?uid=<?=$space['uid']?>&do=videophoto" onclick="ajaxmenu(event, this.id, 1)"><span style="color:red;font-weight:bold;font-size:12px;">查看视频认证照</span></a>
<?php } else { ?>
&nbsp; <img src="image/videophoto_no.gif" align="absmiddle" alt="未通过视频认证"> <span class="gray"><a href="cp.php?ac=videophoto">视频未认证</a></span>
<?php } ?>
<?php } ?>
</div>
<div class="career">
<div class="money">小金库：<?=$space['credit']?></div>
<div class="rankId">经验：<?=$space['experience']?>&nbsp;<?=$space['star']?></div>
</div>
</div>
<div class="colSub">
<div class="colInt">
<div id="profileUserIntro">
<div class="profileUserIntroHd"><span class="profileUserIntroHdInt"></span></div>
<div class="profileUserIntroBd">
<div class="profileUserIntroBdInt">

<div class="profileUserIntroText" <?php if($space['self']) { ?>onmouseover="this.className='profileUserIntroText profileUserIntroText-hover'" onmouseout="this.className='profileUserIntroText'" onclick="profile_edit_text();"<?php } ?> id="userIntroView">
<?php if(!$space['self'] && $space['spacenote']) { ?><?=$space['spacenote']?><?php } ?><?php if($space['self']) { ?><?=$space['spacenote']?><?php } ?> <a href="space.php?uid=<?=$space['uid']?>&do=doing">&raquo;</a>
</div>



<div style="display: none;" class="profileUserIntroInput" id="userIntroEdit">
<form method="post" action="cp.php?ac=doing" id="mood_addform">
<textarea name="message" id="mood_message" onkeydown="if(event.keyCode == 13 ){ event.returnValue=false;event.cancel = true;$('mood_add').click();$('mood_message').value='';this.blur(); };" class="text" tabindex="1"></textarea>
<div class="mcStatusAct">
<div class="mcStatusEmot"><span onclick="statusFace();" class="emot e-base-1"></span></div>
<div class="mcStatusBtn"><span class="button"><span><button onclick="ajaxpost('mood_addform', 'reloadMood');$('mood_message').value='';" name="add" id="mood_add" type="button" tabindex="2"> 发送 </button></span></span> <span class="button"><span><button onclick="bindBlur();return false;"> 取消 </button></span></span>
<input type="hidden" name="addsubmit" value="true" />
<input type="hidden" name="spacenote" value="true" />
<input type="hidden" name="formhash" value="<?php echo formhash(); ?>" /></div>
</div>
</form>
</div>
<?php if($space['self']) { ?>
﻿<script type="text/javascript">

    function profile_edit_text() {
$('userIntroEdit').style.display = 'block';
$('userIntroView').style.display = 'none';

}

function statusFace() {	
if($('mood_message_menu') != null) {
$('mood_message_menu').style.display = '';
} else {
var faceDiv = document.createElement("div");
faceDiv.id = 'mood_message_menu';
faceDiv.className = 'facebox';
faceDiv.style.position = 'absolute';
var faceul = document.createElement("ul");
for(i=1; i<31; i++) {
getStatusFace(i, faceul);	
}
faceDiv.appendChild(faceul);
$('append_parent').appendChild(faceDiv);
}
//定位菜单
setMenuPosition('mood_message', 0);
}
    
    function hiddenface() {
$('mood_message_menu').style.display = 'none';

}

function bindBlur() {
$('userIntroEdit').style.display = 'none';
$('userIntroView').style.display = 'block';

}

function getStatusFace(i, faceul) {
var faceli = document.createElement("li");
faceli.innerHTML = '<img src="image/face/'+i+'.gif" style="cursor:pointer; position:relative;" />';
faceli.getElementsByTagName('img').item(0).onclick = function(){var faceText = '[em:'+i+':]'; if($('mood_message') != null) { insertContent('mood_message', faceText);hiddenface();}};
faceul.appendChild(faceli);
}

function reloadMood(showid, result) {
var x = new Ajax();
x.get('cp.php?ac=doing&op=getmood', function(s){
$('userIntroView').innerHTML = s;
});
//提示获得积分
showreward();
bindBlur();
}
</script>
<?php } ?>
</div>
</div>
<div class="profileUserIntroFt"><span class="profileUserIntroFtInt"></span></div>
</div>

<?php if(!$space['isfriend']) { ?>
<div class="whiteBox" style="margin: 0pt 0pt 10px;">
<span class="whiteBoxHd"><span></span></span>
<div class="whiteBoxBd">
<p style="padding-bottom:10px;">如果您认识<?=$_SN[$space['uid']]?>，可以给TA留个言，或者打个招呼，或者添加为好友。<br />成为好友后，您就可以第一时间关注到TA的更新动态。</p>
<p><span class="button button-large"><span><a href="cp.php?ac=friend&op=add&uid=<?=$space['uid']?>" id="a_friend_notice" onclick="ajaxmenu(event, this.id, 1)">加为好友</a></span></span></p>
</div> 
<span class="whiteBoxFt"><span></span></span>
</div>
<?php } ?>

<div class="whiteBox">
<span class="whiteBoxHd"><span></span></span>
<div class="whiteBoxBd" id="maincontent">

<div class="mod" id="space_info">
<div class="mCt">
<div class="mHd">
<h3>个人档案</h3><?php if($space['self']) { ?><a href="cp.php?ac=profile" class="right">完善档案</a><?php } ?>
</div>
<div class="mBd">
<ul class="spacemenu_list">
<li><em>创建:</em><?php echo sgmdate('Y-m-d',$space[dateline],1); ?></li>
<li><em>登录:</em><?php if($space['lastlogin']) { ?><?php echo sgmdate('Y-m-d',$space[lastlogin],1); ?><?php } ?></li>
<?php if($isonline) { ?>
<li><em>活跃:</em><?=$isonline?> (当前在线)</li>
<?php } ?>
<?php if($space['sex']) { ?>
<li><em>性别:</em><?=$space['sex']?></li>
<?php } ?>
<?php if($space['birth']) { ?>
<li><em>生日:</em><?=$space['birth']?></li>
<?php } ?>
<?php if($space['blood']) { ?>
<li><em>血型:</em><?=$space['blood']?></li>
<?php } ?>
<?php if($space['marry']) { ?>
<li><em>婚恋:</em><?=$space['marry']?></li>
<?php } ?>
<?php if($space['residecity']) { ?>
<li><em>居住:</em><?=$space['residecity']?></li>
<?php } ?>
<?php if($space['birthcity']) { ?>
<li><em>家乡:</em><?=$space['birthcity']?></li>
<?php } ?>
<?php if($space['mobile']) { ?>
<li><em>手机:</em><?=$space['mobile']?></li>
<?php } ?>
<?php if($space['qq']) { ?>
<li><em>QQ:</em><?=$space['qq']?></li>
<?php } ?>
<?php if($space['msn']) { ?>
<li><em>MSN:</em><?=$space['msn']?></li>
<?php } ?>
</ul>
<div class="more"><a href="javascript:;" onclick="getindex('info');">查看全部个人资料 &raquo;</a></div>
</div>
</div>
</div>
<?php if($albumlist) { ?>
<div class="mod" id="space_photo">
<div class="mCt">
<div class="mHd">
<h3>相册</h3><?php if($space['self']) { ?><a href="space.php?uid=<?=$space['uid']?>&do=album&view=me" class="right">全部</a><?php } ?>
</div>
<div class="mBd">
<ul class="albumList">
<?php if(is_array($albumlist)) { foreach($albumlist as $key => $value) { ?>
<li class="albumItem">
<div class="albumCover"><div class="albumCoverInt"><a title="<?=$value['albumname']?>" href="space.php?uid=<?=$space['uid']?>&do=album&id=<?=$value['albumid']?>"><img src="<?=$value['pic']?>" alt="<?=$value['albumname']?>"/></a></div></div>
<h5><a href="space.php?uid=<?=$space['uid']?>&do=album&id=<?=$value['albumid']?>" target="_blank" title="<?=$value['albumname']?>"><?=$value['albumname']?></a></h5>
<p class="gray"><?=$value['picnum']?> 张照片</p>
<p class="meta"><?php echo sgmdate('m-d',$value[dateline],1); ?>更新</p>
</li>
<?php } } ?>
</ul>
</div>
</div>
</div>
<?php } ?>
<?php if($bloglist) { ?>
<div class="mod" id="space_photo">
<div class="mCt">
<div class="mHd">
<h3>日志</h3><?php if($space['self']) { ?><a href="space.php?uid=<?=$space['uid']?>&do=blog&view=me" class="right">全部</a><?php } ?>
</div>
<div class="mBd">
<ul class="blogList">
<?php if(is_array($bloglist)) { foreach($bloglist as $value) { ?>
<li class="blogItem">
<div class="blogHead">
<h4>
<a href="space.php?uid=<?=$space['uid']?>&do=blog&id=<?=$value['blogid']?>" title="<?=$value['subject']?>" target="_blank"><?=$value['subject']?></a> 
<span class="meta"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span>
</h4>
</div>
<div class="blogBody">
<p>
<?=$value['message']?>...
<a class="more" href="space.php?uid=<?=$space['uid']?>&do=blog&id=<?=$value['blogid']?>">查看全文 &raquo;</a>
</p>
</div>
</li>
<?php } } ?>
</ul>
</div>
</div>
</div>
<?php } ?>
<?php if($feedlist) { ?>
<?php $_TPL['hidden_hot']=1; ?>
<div class="mod" id="profileFeed">
<div class="mCt">
<div class="mHd">
<h3>新鲜事</h3><?php if($space['self']) { ?><a href="space.php?uid=<?=$space['uid']?>&do=feed&view=me" class="right">全部</a><?php } ?>
</div>
<div class="mBd">
<div class="profileFeedWrap">
<div class="minifeed" id="storyListEl">
<ul class="feedList minifeedList">
 <?php if(is_array($feedlist)) { foreach($feedlist as $value) { ?>
﻿<?php if($value['icon']=='doing') { ?>
<li class="feedItem feedItem-main feed-<?=$value['icon']?> " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);">    
    <div class="feedIcon">
        <span class="icon i-app-<?=$value['icon']?>"></span>	
    </div>
    <div class="feedContent feedStyle-short">
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<span class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-del">删除</a></span>
<?php } ?>
<h4>
<span class="statusWord"><i><i><i><i> <?=$value['title_template']?> </i></i></i></i></span>     
</h4>
</div>        
            <div class="feedFoot">                
                    <a title="通过手机发布" class="icon i-wap" href="#" style="display:none"></a>
                    <span class="time"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span>  -   
                    <?php if(empty($_TPL['hidden_menu'])) { ?><?php if($value['idtype']=='doid') { ?><span class="action"><a onclick="docomment_get('docomment_<?=$value['id']?>', 1);" id="do_a_op_<?=$value['id']?>" href="javascript:void(0)">回复</a></span><?php } ?><?php } ?><?php if(!empty($hiddenfeed_num[$value['icon']])) { ?>  -  
<div class="feedHead" id="feed_more_<?=$value['feedid']?>" style="display:none;">              
<?php if(is_array($hiddenfeed_list[$value['icon']])) { foreach($hiddenfeed_list[$value['icon']] as $appvalue) { ?>
<?php $appvalue = mkfeed($appvalue); ?>

<h4>
<?=$appvalue['title_template']?>
</h4>
<?php if($appvalue['body_template']) { ?>
<span class="meta time"><?=$appvalue['body_template']?></span>
<?php } ?>

<?php } } ?>
</div>
<span id="appfeed_open_<?=$value['feedid']?>"><a class="act a-tg-down" href="javascript:;" id="feed_a_more_<?=$value['feedid']?>" onclick="feed_more_show('<?=$value['feedid']?>');">显示更多(<?=$hiddenfeed_num[$value['icon']]?>)条</a></span><?php } ?>      
            </div> 
<?php if($value['idtype']=='doid') { ?>
<div class="feedComment" id="docomment_<?=$value['id']?>" style="display:none;"></div>
<?php } ?> 

    </div>
</li>

<?php } elseif($value['icon']=='poll') { ?>

<li class="feedItem  feedItem-main feed-<?=$value['icon']?> " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);"> 
    <div class="feedIcon">       
<span class="icon i-app-<?=$value['icon']?>"></span>	
    </div>
   <div class="feedContent feedStyle-short">
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<span class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-del">删除</a></span>
<?php } ?>
<h4>
 <?=$value['title_template']?>     
</h4>
</div>
<?php if($value['body_template']) { ?>
<div class="feedBody">
<div class="feedAttach"><div class="feedAttachContent"><?=$value['body_template']?></div></div>
</div>
<?php } ?>
            <div class="feedFoot">                
                    <span class="time"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span>  -   
                    <?php if(empty($_TPL['hidden_menu'])) { ?><?php if($value['idtype']=='doid') { ?><span class="action"><a onclick="docomment_get('docomment_<?=$value['id']?>', 1);" id="do_a_op_<?=$value['id']?>" href="javascript:void(0)">回复</a></span><?php } elseif(in_array($value['idtype'], array('blogid','picid','sid','pid','eventid'))) { ?><span class="action"><a onclick="feedcomment_get(<?=$value['feedid']?>);" id="feedcomment_a_op_<?=$value['feedid']?>" href="javascript:void(0)">评论</a></span><?php } ?><?php } ?><?php if(!empty($hiddenfeed_num[$value['icon']])) { ?>  -  
<div class="feedHead" id="feed_more_<?=$value['feedid']?>" style="display:none;">              
<?php if(is_array($hiddenfeed_list[$value['icon']])) { foreach($hiddenfeed_list[$value['icon']] as $appvalue) { ?>
<?php $appvalue = mkfeed($appvalue); ?>

<h4>
<?=$appvalue['title_template']?>
</h4>
<?php if($appvalue['body_template']) { ?>
<span class="meta time"><?=$appvalue['body_template']?></span>
<?php } ?>

<?php } } ?>
</div>
<span id="appfeed_open_<?=$value['feedid']?>"><a class="act a-tg-down" href="javascript:;" id="feed_a_more_<?=$value['feedid']?>" onclick="feed_more_show('<?=$value['feedid']?>');">显示更多(<?=$hiddenfeed_num[$value['icon']]?>)条</a></span><?php } ?>       
            </div> 
<?php if($value['idtype']) { ?>
<div class="feedComment" id="feedcomment_<?=$value['feedid']?>" style="display:none;"></div>
<?php } ?> 
    </div>
</li>

<?php } elseif($value['icon']=='blog') { ?>
<li class="feedItem  feedItem-main feed-<?=$value['icon']?> " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);">
    <div class="feedIcon">       
<span class="icon i-app-<?=$value['icon']?>"></span>
    </div>
    <div class="feedContent feedStyle-short">
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<span class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-del">删除</a></span>
<?php } ?>
<h4>
 <?=$value['title_template']?>     
</h4>
</div>
<?php if($value['body_template']) { ?>
<div class="feedBody">
<div class="feedAttach">
<?php if($value['image_1']) { ?>
<div class="feedAttachMedia"><a href="<?=$value['image_1_link']?>"<?=$value['target']?>><img src="<?=$value['image_1']?>" class="photo-50" /></a></div>
<?php } ?>
<div class="feedAttachContent"><?=$value['body_template']?></div></div>
</div>
<?php } ?>
            <div class="feedFoot">                
                    <span class="time"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span>  -   
                    <?php if(empty($_TPL['hidden_menu'])) { ?><?php if(in_array($value['idtype'], array('blogid','picid','sid','pid','eventid'))) { ?><span class="action"><a onclick="feedcomment_get(<?=$value['feedid']?>);" id="feedcomment_a_op_<?=$value['feedid']?>" href="javascript:void(0)">评论</a></span><?php } ?><?php } ?><?php if(!empty($hiddenfeed_num[$value['icon']])) { ?>  -  
<div class="feedHead" id="feed_more_<?=$value['feedid']?>" style="display:none;">              
<?php if(is_array($hiddenfeed_list[$value['icon']])) { foreach($hiddenfeed_list[$value['icon']] as $appvalue) { ?>
<?php $appvalue = mkfeed($appvalue); ?>

<h4>
<?=$appvalue['title_template']?>
</h4>
<?php if($appvalue['body_template']) { ?>
<span class="meta time"><?=$appvalue['body_template']?></span>
<?php } ?>

<?php } } ?>
   </div>	
<span id="appfeed_open_<?=$value['feedid']?>"><a class="act a-tg-down" href="javascript:;" id="feed_a_more_<?=$value['feedid']?>" onclick="feed_more_show('<?=$value['feedid']?>');">显示更多(<?=$hiddenfeed_num[$value['icon']]?>)条</a></span><?php } ?>         
            </div> 
<?php if($value['idtype']) { ?>
<div class="feedComment" id="feedcomment_<?=$value['feedid']?>" style="display:none;"></div>
<?php } ?>
    </div>
</li>

<?php } elseif($value['icon']=='thread') { ?>

<li class="feedItem  feedItem-main feed-<?=$value['icon']?> " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);">
    <div class="feedIcon">       
<span class="icon i-app-<?=$value['icon']?>"></span>	
    </div>
    <div class="feedContent feedStyle-short">
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<span class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-del" >删除</a></span>
<?php } ?>
<h4>
 <?=$value['title_template']?>     
</h4>
</div>
<?php if($value['body_template']) { ?>
<div class="feedBody">
<div class="feedAttach">
<div class="feedAttachContent"><?=$value['body_template']?></div></div>
</div>
<?php } ?>	
    </div>
</li>

<?php } elseif(in_array($value['icon'], array('profile','friend','joinpoll','click','comment','myop','mtag','task','wall','post','show','joinevent'))) { ?>

<li class="feedItem feedItem-sub feed-<?=$value['icon']?>  " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);">
<div class="feedIcon"><span class="icon i-app-<?=$value['icon']?>"></span></div>
<div class="feedContent feedStyle-oneline" >	
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<span class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-del" title="删除">删除</a></span>
<?php } ?>
<h4> <?=$value['title_template']?><span class="meta time"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span> 
<?php if(in_array($value['idtype'], array('commentid'))) { ?>
<span class="action"><a  onclick="feedcommentback_get(<?=$value['feedid']?>);" id="feedcomment_a_op_<?=$value['feedid']?>" href="javascript:void(0)">回应</a></span>

<?php } ?>
</h4>
<?php if(in_array($value['idtype'], array('commentid'))) { ?>
<div class="feedBody">
<?php if($value['body_template']) { ?><?=$value['body_template']?><?php } ?>
</div>
<?php } ?>
<?php if(in_array($value['idtype'], array('commentid'))) { ?>
<div class="feedComment" id="feedcomment_<?=$value['feedid']?>" style="display:none;"></div>
<?php } ?> 
<?php if(!empty($hiddenfeed_num[$value['icon']])) { ?>
<div class="feedFoot"> 
<div class="feedHead" id="feed_more_<?=$value['feedid']?>" style="display:none;">              
<?php if(is_array($hiddenfeed_list[$value['icon']])) { foreach($hiddenfeed_list[$value['icon']] as $appvalue) { ?>
<?php $appvalue = mkfeed($appvalue); ?>

<h4>
<?=$appvalue['title_template']?>
</h4>
<?php if($appvalue['body_template']) { ?>
<span class="meta time"><?=$appvalue['body_template']?></span>
<?php } ?>

<?php } } ?>
</div>                        
               <span id="appfeed_open_<?=$value['feedid']?>"><a class="act a-tg-down" href="javascript:;" id="feed_a_more_<?=$value['feedid']?>" onclick="feed_more_show('<?=$value['feedid']?>');">显示更多(<?=$hiddenfeed_num[$value['icon']]?>)条</a></span>
        </div>
<?php } ?>

</div>
</li>

<?php } elseif($value['icon']=='share') { ?>
<li class="feedItem  feedItem-main feed-<?=$value['icon']?> " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);">
    <div class="feedIcon">       
<span class="icon i-app-<?=$value['icon']?>"></span>	
    </div>
    <div class="feedContent feedStyle-short">
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<div class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-del" title="删除">删除</a></div>
<?php } ?>
<h4>
 <?=$value['title_template']?> 
</h4>
</div>
<div class="feedBody">
<div class="feedAttach feedAttach-user">
        <?php if($value['image_1'] && empty($value['body_data']['flashvar'])) { ?>
<div class="feedAttachMedia"><a href="<?=$value['image_1_link']?>"<?=$value['target']?>><img src="<?=$value['image_1']?>" class="photo-50" /></a></div>
<?php } ?>
<?php if($value['image_2']) { ?>
<a href="<?=$value['image_2_link']?>"<?=$value['target']?>><img src="<?=$value['image_2']?>" class="summaryimg1" /></a>
<?php } ?>
<?php if($value['image_3']) { ?>
<a href="<?=$value['image_3_link']?>"<?=$value['target']?>><img src="<?=$value['image_3']?>" class="summaryimg2" /></a>
<?php } ?>
<?php if($value['image_4']) { ?>
<a href="<?=$value['image_4_link']?>"<?=$value['target']?>><img src="<?=$value['image_4']?>" class="summaryimg3" /></a>
<?php } ?>
<?php if($value['thisapp'] && !empty($value['body_data']['flashvar'])) { ?>
<div class="feedAttachMedia">
<div class="playVideo">
<a id="media_id_<?=$value['feedid']?>" class="videoCover" title="播放该视频" onclick="javascript:showFlash('<?=$value['body_data']['host']?>', '<?=$value['body_data']['flashvar']?>', this, '<?=$value['feedid']?>');" style="cursor:pointer;"><img id=icon_id_<?=$value['feedid']?> src="<?php if(!empty($value['image_1'])) { ?><?=$value['image_1']?><?php } else { ?>image/videoCover.gif<?php } ?>" class="video"/><em>播放该视频</em></a>
</div>
</div>
<?php } elseif($value['thisapp'] && !empty($value['body_data']['musicvar'])) { ?>
<div class="feedAttachMedia">
<div class="playMusic">
<a onclick="javascript:showFlash('music', '<?=$value['body_data']['musicvar']?>', this, '<?=$value['feedid']?>');" style="cursor:pointer;" class="musicCover" title="播放该音乐" >播放该音乐</a>
</div>
</div>
<?php } elseif($value['thisapp'] && !empty($value['body_data']['flashaddr'])) { ?>
<div class="feedAttachMedia">
<div class="playFlash">
<a onclick="javascript:showFlash('flash', '<?=$value['body_data']['flashaddr']?>', this, '<?=$value['feedid']?>');" style="cursor:pointer;" class="musicCover" title="播放该音乐" >播放该音乐</a>
</div>
</div>
<?php } ?>
<?php if($value['body_template'] && empty($value['body_data']['flashvar']) && empty($value['body_data']['musicvar']) && empty($value['body_data']['flashaddr'])) { ?>
<div class="feedAttachContent"><?=$value['body_template']?></div>
<?php } ?> </div>
<?php if($value['body_general']) { ?>
<p class="quote"><?=$value['body_general']?><q></q></p>
<?php } ?>
</div>

            <div class="feedFoot">                
                    <span class="time"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span>  -   
                    <?php if(empty($_TPL['hidden_menu'])) { ?><?php if($value['idtype']=='doid') { ?><span class="action"><a onclick="docomment_get('docomment_<?=$value['id']?>', 1);" id="do_a_op_<?=$value['id']?>" href="javascript:void(0)">回复</a></span><?php } elseif(in_array($value['idtype'], array('blogid','picid','sid','pid','eventid'))) { ?><span class="action"><a onclick="feedcomment_get(<?=$value['feedid']?>);" id="feedcomment_a_op_<?=$value['feedid']?>" href="javascript:void(0)">评论</a></span><?php } ?><?php } ?>      
            </div> 
<?php if($value['idtype']) { ?>
<div class="feedComment" id="feedcomment_<?=$value['feedid']?>" style="display:none;"></div>
<?php } ?> 
    </div>
</li>

<?php } elseif(in_array($value['icon'], array('album'))) { ?>

<li class="feedItem feedItem-main feed-<?=$value['icon']?>  " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);">
<div class="feedIcon"><span class="icon i-app-<?=$value['icon']?>"></span></div>
<div class="feedContent feedStyle-short" >	
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<span class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-del" title="删除">删除</a></span>
<?php } ?>
<h4><?=$value['title_template']?>&nbsp;<?php if($value['body_template']) { ?><?=$value['body_template']?><?php } ?></h4></div>
<div class="feedBody">
<div class="albumSample"><ul class="albumCover">
<?php if($value['image_1']) { ?>
<li><a href="<?=$value['image_1_link']?>"<?=$value['target']?>><img src="<?=$value['image_1']?>" class="photo" /></a></li>
<?php } ?>
<?php if($value['image_2']) { ?>
<li><a href="<?=$value['image_2_link']?>"<?=$value['target']?>><img src="<?=$value['image_2']?>" class="photo" /></a></li>
<?php } ?>
<?php if($value['image_3']) { ?>
<li><a href="<?=$value['image_3_link']?>"<?=$value['target']?>><img src="<?=$value['image_3']?>" class="photo" /></a></li>
<?php } ?>
<?php if($value['image_4']) { ?>
<li><a href="<?=$value['image_4_link']?>"<?=$value['target']?>><img src="<?=$value['image_4']?>" class="photo" /></a></li>
<?php } ?>
</ul></div></div>
<div class="feedFoot"><span class="time"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span></div>
</div>

</li>

<?php } elseif(in_array($value['icon'], array('event'))) { ?>

<li class="feedItem feedItem-main feed-<?=$value['icon']?>  " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);">
<div class="feedIcon"><span class="icon i-app-<?=$value['icon']?>"></span></div>
<div class="feedContent feedStyle-short" >	
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<span class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-del" title="删除">删除</a></span>
<?php } ?>
<h4><?=$value['title_template']?>&nbsp;</h4></div>
<div class="feedBody"><div class="feedAttach feedAttach-event-img">
<?php if($value['image_1']) { ?><div class="feedAttachMedia"><a href="<?=$value['image_1_link']?>"<?=$value['target']?>><img src="<?=$value['image_1']?>" class="poster_pre" /></a></div><?php } ?>

<div class="feedAttachContent"><?php if($value['body_template']) { ?><?=$value['body_template']?><?php } ?></div></div></div>
<div class="feedFoot">                
<span class="time"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span>  -   
<?php if(empty($_TPL['hidden_menu'])) { ?><?php if(in_array($value['idtype'], array('blogid','picid','sid','pid','eventid'))) { ?><span class="action"><a onclick="feedcomment_get(<?=$value['feedid']?>);" id="feedcomment_a_op_<?=$value['feedid']?>" href="javascript:void(0)">评论</a></span><?php } ?><?php } ?>      
</div> 
<?php if($value['idtype']) { ?>
<div class="feedComment" id="feedcomment_<?=$value['feedid']?>" style="display:none;"></div>
<?php } ?> 	
</li>

<?php } elseif(in_array($value['icon'], array('sitefeed'))) { ?>

<li class="feedItem feedItem-main feed-<?=$value['icon']?>  " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);">
<div class="feedIcon"><span class="icon i-app-<?=$value['icon']?>"></span></div>
<div class="feedContent feedStyle-oneline" >	
<div class="feedHead">
<h4><?=$value['title_template']?></h4>
</div>
</div>
</li>

<?php } else { ?>
<li class="feedItem feedItem-sub feed-<?=$value['icon']?>  " id="feed_<?=$value['feedid']?>_li" onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);">
<div class="feedIcon"><a href="space.php?uid=<?=$_GET['uid']?>&do=feed&view=<?=$_GET['view']?>&appid=<?=$value['appid']?>&icon=<?=$value['icon']?>"><img src="<?=$value['icon_image']?>" /></a></div>
<div class="feedContent feedStyle-oneline" >	
<div class="feedHead">
<?php if($value['uid'] && empty($_TPL['hidden_more'])) { ?>
<span class="option" id="option_<?=$value['feedid']?>" style="visibility: hidden;"><a href="cp.php?ac=feed&op=menu&feedid=<?=$value['feedid']?>" id="a_feed_menu_<?=$value['feedid']?>"  onmouseover="feed_menu(<?=$value['feedid']?>,1);" onmouseout="feed_menu(<?=$value['feedid']?>,0);" onclick="ajaxmenu(event, this.id)" title="显示更多选项" class="icon i-del" title="删除">删除</a></span>
<?php } ?>
<h4> <?=$value['title_template']?><span class="meta time"><?php echo sgmdate('m-d H:i',$value[dateline],1); ?></span></h4>
</div>
<?php if(!empty($hiddenfeed_num[$value['icon']])) { ?>
<div class="feedFoot"> 
<div class="feedHead" id="feed_more_<?=$value['feedid']?>" style="display:none;">              
<?php if(is_array($hiddenfeed_list[$value['icon']])) { foreach($hiddenfeed_list[$value['icon']] as $appvalue) { ?>
<?php $appvalue = mkfeed($appvalue); ?>

<h4>
<?=$appvalue['title_template']?>
</h4>
<?php if($appvalue['body_template']) { ?>
<span class="meta time"><?=$appvalue['body_template']?></span>
<?php } ?>

<?php } } ?>
</div>                        
               <span id="appfeed_open_<?=$value['feedid']?>"><a class="act a-tg-down" href="javascript:;" id="feed_a_more_<?=$value['feedid']?>" onclick="feed_more_show('<?=$value['feedid']?>');">显示更多(<?=$hiddenfeed_num[$value['icon']]?>)条</a></span>
        </div>
<?php } ?>

</div>
</li>
<?php } ?>
<?php } } ?>
</ul>
</div>
<div style="display: block;" class="feedMore"><a href="space.php?uid=<?=$space['uid']?>&do=feed&view=me">查看更多新鲜事</a></div> 
</div>
</div>
</div>
</div>
<?php } ?>
<div class="mod" id="space_photo">
<div class="mCt">
<div class="mHd">
<h3>我正在玩</h3>
</div>
<div class="mBd">
<div class="tipTruth meta">和好友玩玩小游戏，可给你带来一天好心情，简直是居家旅行、秒杀疲惫的必备良药！~</div>
<ul class="fix writeTruthList">
<?php if(is_array($widelist)) { foreach($widelist as $value) { ?>
<?php if($value['myml']) { ?>
 <li>
 <div class="unRead"><p><span><a href="<?=$value['appurl']?>"><?=$value['appname']?></a></span></p><p>看看我玩的怎么样~</p></div>
 </li>
<?php } ?>
<?php } } ?>
</ul>
</div>
</div>
</div>

</div> 
<span class="whiteBoxFt"><span></span></span>
</div>
        
<!--留言-->
<div style="margin: 10px 0pt 0pt;" class="whiteBox">
<span class="whiteBoxHd"><span></span></span>
<div class="whiteBoxBd">
<div id="profileMsgBoard">
<div class="mod" id="comment">
<div class="mCt">
<div class="mHd">
<h3>留言板</h3><a href="space.php?uid=<?=$space['uid']?>&do=wall&view=me" class="right">全部</a>
</div>
<div class="mBd">
<div class="msgBoard">
<div class="msgComposer">
<form action="cp.php?ac=comment" id="quick_commentform_<?=$space['uid']?>" name="quick_commentform_<?=$space['uid']?>" method="post">
<div class="composer"><textarea max="250" name="message" id="comment_message" onkeydown="ctrlEnter(event, 'commentsubmit_btn');" class="text" style="overflow: hidden;"></textarea></div>
<div class="checkEmot"><span class="emot e-base-1"><a href="###" id="editface" onclick="showFace(this.id, 'comment_message');return false;"><img src="image/facelist.gif" align="absmiddle" /></a></span>
<?php if($_SGLOBAL['magic']['doodle']) { ?>
<a class="icon i-doodle"></a><a id="a_magic_doodle" href="magic.php?mid=doodle&showid=comment_doodle&target=comment_message" onclick="ajaxmenu(event, this.id, 1)">涂鸦板</a>
<?php } ?>&nbsp;
</div>
<div class="buttons"><span class="button button-main"><span><input type="button" id="commentsubmit_btn" name="commentsubmit_btn" value="留言" onclick="ajaxpost('quick_commentform_<?=$space['uid']?>', 'wall_add')" /></span></span></div>
<input type="hidden" name="refer" value="space.php?uid=<?=$space['uid']?>" />
<input type="hidden" name="id" value="<?=$space['uid']?>" />
<input type="hidden" name="idtype" value="uid" />
<input type="hidden" name="commentsubmit" value="true" />
<span id="__quick_commentform_<?=$space['uid']?>"></span>
<input type="hidden" name="formhash" value="<?php echo formhash(); ?>" />
</form>
</div>
</div>
<div class="msgListWrap">
<ul class="msgList" id="comment_ul">
<?php if(is_array($walllist)) { foreach($walllist as $value) { ?>
﻿

<?php if(empty($ajax_edit)) { ?><li class="msgItem" id="comment_<?=$value['cid']?>_li"><?php } ?>
                    <div class="msgAvatar">
<?php if($value['author']) { ?>
<a href="space.php?uid=<?=$value['authorid']?>" title="<?=$_SN[$value['authorid']]?>"><span class="avatar-48"><?php echo avatar($value[authorid],small); ?></span></a>		
<?php } else { ?>
<a href="javascript:void(0);" title="匿名用户"><span class="avatar-48"><img src="image/magic/hidden.gif"/></span></a>
<?php } ?>
</div>
                    <div class="msgContent">
                        <div class="msgHead">
                            <div class="option">
                                <?php if($value['authorid']==$_SGLOBAL['supe_uid'] || $value['uid']==$_SGLOBAL['supe_uid'] || checkperm('managecomment')) { ?>
<a href="cp.php?ac=comment&op=delete&cid=<?=$value['cid']?>" id="c_<?=$value['cid']?>_delete" onclick="ajaxmenu(event, this.id)" class="icon i-del j-msg-del" title="删除">删除</a>
<?php } ?>
                            </div>
                            <h4><strong><?php if($value['author']) { ?><a href="space.php?uid=<?=$value['authorid']?>" id="author_<?=$value['cid']?>"><?=$_SN[$value['authorid']]?></a><?php } else { ?>匿名<?php } ?></strong> <span class="meta time"><?php echo sgmdate('Y-m-d H:i',$value[dateline],1); ?>   
                                <?php if($value['authorid']!=$_SGLOBAL['supe_uid'] && ($value['idtype'] != 'uid' || $space['self'])) { ?> <a href="cp.php?ac=comment&op=reply&cid=<?=$value['cid']?>&feedid=<?=$feedid?>" id="c_<?=$value['cid']?>_reply" onclick="ajaxmenu(event, this.id, 1)">回复</a><?php } ?> <a href="cp.php?ac=common&op=report&idtype=comment&id=<?=$value['cid']?>" id="a_report_<?=$value['cid']?>" onclick="ajaxmenu(event, this.id, 1)">举报</a></span></h4>
                        </div>
                        <div class="msgBody<?php if($value['magicflicker']) { ?> magicflicker<?php } ?>" id="comment_<?=$value['cid']?>"><?=$value['message']?></div>
                    </div>
 
<?php if(empty($ajax_edit)) { ?></li><?php } ?>
<?php } } ?>
</ul>
<?php if($walllist) { ?><div class="more"><a href="space.php?uid=<?=$space['uid']?>&do=wall&view=me" >更多留言 &raquo;</a></div><?php } ?>
</div>
</div>
</div>
</div>
</div>
</div> 
<span class="whiteBoxFt"><span></span></span>
</div>
<!--留言 end-->
</div>
</div>
<!--中间 end-->
<div class="colExtra">
<div class="colInt">
    <div class="mod" >
<div class="mCt">
    <div class="mBd">
<?php if(!$space['self']) { ?>
<?php if($space['magiccredit']) { ?>
<div class="magichongbao" id="div_magic_gift">
<a id="a_magic_gift" href="cp.php?&ac=magic&op=receive&uid=<?=$space['uid']?>" onclick="ajaxmenu(event, this.id)">送你 <span><?=$space['magiccredit']?></span> 积分大红包</a>
</div>
<?php } ?>

<?php if($_SGLOBAL['magic']['viewmagiclog'] || $_SGLOBAL['magic']['viewmagic'] || $_SGLOBAL['magic']['viewvisitor']) { ?>
<div class="indexmagic">
<?php if(is_array(array('viewmagiclog','viewmagic','viewvisitor'))) { foreach(array('viewmagiclog','viewmagic','viewvisitor') as $mid) { ?>
<?php if($_SGLOBAL['magic'][$mid]) { ?>
<a id="a_magic_<?=$mid?>" href="magic.php?mid=<?=$mid?>&idtype=uid&id=<?=$space['uid']?>" onclick="ajaxmenu(event,this.id,1)">
<img src="image/magic/<?=$mid?>.small.gif" title="<?=$_SGLOBAL['magic'][$mid]?>" alt="<?=$_SGLOBAL['magic'][$mid]?>">
</a>
<?php } ?>
<?php } } ?>
</div>
<?php } ?>
<?php } else { ?>
<?php if($_SGLOBAL['magic']['gift']) { ?>
<div class="magichongbao" id="div_magic_gift">				
<?php if($space['magiccredit']) { ?>
<a id="a_magic_retrieve" href="cp.php?ac=magic&op=retrieve" onclick="ajaxmenu(event,this.id)">回收埋下的积分</a>
<?php } else { ?>
<a id="a_magic_gift" href="magic.php?mid=gift" onclick="ajaxmenu(event,this.id,1)">给来访者埋个红包</a>
<?php } ?>				
</div>
<?php } ?>
<?php } ?>
</div>
</div>
</div>
<?php if($visitorlist) { ?>
<div class="mod" id="profileVisitors" >
<div class="mCt">
<div class="mHd">
<h3>最近来访</h3><a href="space.php?uid=<?=$space['uid']?>&do=friend&view=visitor" class="right">全部</a>
<?php if(!$space['self'] && $_SGLOBAL['magic']['anonymous']) { ?>
<span class="gray"><a class="icon i-anonymous"></a><a id="a_magic_anonymous" href="magic.php?mid=anonymous&idtype=uid&id=<?=$space['uid']?>" onclick="ajaxmenu(event,this.id,1)">匿名</a></span>
<?php } ?>
</div>
<div class="mBd">
<ul class="friends">
<?php if(is_array($visitorlist)) { foreach($visitorlist as $key => $value) { ?>
<li class="friendItem">
<?php if($value['vusername'] == '') { ?>
<div class="friendAvatar">
<a href="javascript:void(0);"><img class="avatar-48" src="image/magic/hidden.gif" alt="匿名" /></a>
</div>
<div class="friendInfo">
<h4><a href="javascript:void(0);">匿名</a></h4>
<p class="meta"><?php echo sgmdate('n月j日',$value[dateline],1); ?></p>
</div>
<?php } else { ?>
<div class="friendAvatar">
<a href="space.php?uid=<?=$value['vuid']?>"><span class="avatar-48"><?php echo avatar($value[vuid],small); ?></span></a>
</div>
<div class="friendInfo">
<h4><?php if($ols[$value['vuid']]) { ?><a title="在线" class="icon i-online"></a><?php } ?><a href="space.php?uid=<?=$value['vuid']?>" title="<?=$_SN[$value['vuid']]?>"><?=$_SN[$value['vuid']]?></a></h4>
<p class="meta"><?php echo sgmdate('n月j日',$value[dateline],1); ?></p>
</div>
<?php } ?>
</li>
<?php } } ?>
</ul>
</div>
</div>
</div>
<?php } ?>
<?php if($friendlist) { ?>
<div class="mod" id="profileVisitors" >
<div class="mCt">
<div class="mHd">
<h3>好友</h3><span class="count">(<?=$space['friendnum']?>)</span><a href="space.php?uid=<?=$space['uid']?>&do=friend&view=me" class="right">全部</a>
</div>
<div class="mBd">
<ul class="friends">
<?php if(is_array($friendlist)) { foreach($friendlist as $value) { ?>
<li class="friendItem">

<div class="friendAvatar">
<a href="space.php?uid=<?=$value['fuid']?>"><span class="avatar-48"><?php echo avatar($value[fuid],small); ?></span></a>
</div>
<div class="friendInfo">
<h4><?php if($ols[$value['fuid']]) { ?><a title="在线" class="icon i-online"></a><?php } ?><a href="space.php?uid=<?=$value['fuid']?>"><?=$_SN[$value['fuid']]?></a></h4>
</div>

</li>
<?php } } ?>
</ul>
</div>
</div>
</div>
<?php } ?>

</div>
</div>
<!--右边 end-->
</div>
</div>
</div>
</div> 
<span class="wrapBoxFt"><span></span></span>
</div>
<?php if($_GET['theme']) { ?><div class="nn">您是否想使用这款个性风格?<br /><a href="cp.php?ac=theme&op=use&dir=<?=$_GET['theme']?>">[应用]</a><a href="cp.php?ac=theme">[取消]</a></div><?php } ?>
﻿<?php if(empty($_SGLOBAL['inajax'])) { ?>
<?php if(empty($_TPL['nosidebar'])) { ?>
<?php if($_SGLOBAL['ad']['contentbottom']) { ?><br style="line-height:0;clear:both;"/><div id="ad_contentbottom"><?php adshow('contentbottom'); ?></div><?php } ?>
</div>

<!--/mainarea-->
<div id="bottom"></div>
</div>
<!--/main-->
<?php } ?>

<div id="footer">

<p class="r_option">
<a href="javascript:;" onclick="window.scrollTo(0,0);" id="a_top" title="TOP"><img src="image/top.gif" alt="" style="padding: 5px 6px 6px;" /></a>
</p>

<?php if($_SGLOBAL['ad']['footer']) { ?>
<p style="padding:5px 0 10px 0;"><?php adshow('footer'); ?></p>
<?php } ?>

<?php if($_SCONFIG['close']) { ?>
<p style="color:blue;font-weight:bold;">
提醒：当前站点处于关闭状态
</p>
<?php } ?>
<p>
<?=$_SCONFIG['sitename']?> - 
<a href="mailto:<?=$_SCONFIG['adminemail']?>">联系我们</a>
<?php if($_SCONFIG['miibeian']) { ?> - <a  href="http://www.miibeian.gov.cn" target="_blank"><?=$_SCONFIG['miibeian']?></a><?php } ?>
</p>
<p>
Powered by <a  href="http://u.discuz.net" target="_blank"><strong>UCenter Home</strong></a> <span title="<?php echo X_RELEASE; ?>"><?php echo X_VER; ?></span>
<?php if(!empty($_SCONFIG['licensed'])) { ?><a  href="http://license.comsenz.com/?pid=7&host=<?=$_SERVER['HTTP_HOST']?>" target="_blank">Licensed</a><?php } ?>
&copy; 2001-2011 <a  href="http://www.comsenz.com" target="_blank">Comsenz Inc.</a>
</p>
<?php if($_SCONFIG['debuginfo']) { ?>
<p><?php echo debuginfo(); ?></p>
<?php } ?>
</div>
</div>
<!--/wrap-->

<?php if($_SGLOBAL['appmenu']) { ?>
<ul id="ucappmenu_menu" class="dropmenu_drop" style="display:none;">
<li><a href="<?=$_SGLOBAL['appmenu']['url']?>" title="<?=$_SGLOBAL['appmenu']['name']?>" target="_blank"><?=$_SGLOBAL['appmenu']['name']?></a></li>
<?php if(is_array($_SGLOBAL['appmenus'])) { foreach($_SGLOBAL['appmenus'] as $value) { ?>
<li><a href="<?=$value['url']?>" title="<?=$value['name']?>" target="_blank"><?=$value['name']?></a></li>
<?php } } ?>
</ul>
<?php } ?>


<?php if($_SGLOBAL['supe_uid']) { ?>
<?php if(!isset($_SCOOKIE['checkpm'])) { ?>
<script language="javascript"  type="text/javascript" src="cp.php?ac=pm&op=checknewpm&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>
<?php if(!isset($_SCOOKIE['synfriend'])) { ?>
<script language="javascript"  type="text/javascript" src="cp.php?ac=friend&op=syn&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>
<?php } ?>
<?php if(!isset($_SCOOKIE['sendmail'])) { ?>
<script language="javascript"  type="text/javascript" src="do.php?ac=sendmail&rand=<?=$_SGLOBAL['timestamp']?>"></script>
<?php } ?>

<?php if($_SGLOBAL['ad']['couplet']) { ?>
<script language="javascript" type="text/javascript" src="source/script_couplet.js"></script>
<div id="uch_couplet" style="z-index: 10; position: absolute; display:none">
<div id="couplet_left" style="position: absolute; left: 2px; top: 60px; overflow: hidden;">
<div style="position: relative; top: 25px; margin:0.5em;" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('uch_couplet');"><img src="image/advclose.gif"></div>
<?php adshow('couplet'); ?>
</div>
<div id="couplet_rigth" style="position: absolute; right: 2px; top: 60px; overflow: hidden;">
<div style="position: relative; top: 25px; margin:0.5em;" onMouseOver="this.style.cursor='hand'" onClick="closeBanner('uch_couplet');"><img src="image/advclose.gif"></div>
<?php adshow('couplet'); ?>
</div>
<script type="text/javascript">
lsfloatdiv('uch_couplet', 0, 0, '', 0).floatIt();
</script>
</div>
<?php } ?>
<?php if($_SCOOKIE['reward_log']) { ?>
<script type="text/javascript">
showreward();
</script>
<?php } ?>
</body>
</html>
<?php } ?>

<script>
function getindex(type) {
var plus = '';
if(type == 'event') plus = '&type=self';
ajaxget('space.php?uid=<?=$space['uid']?>&do='+type+'&view=me'+plus+'&ajaxdiv=maincontent', 'maincontent');
}

//彩虹炫
var elems = selector('div[class~=magicflicker]'); 
for(var i=0; i<elems.length; i++){
magicColor(elems[i]);
}

</script><?php ob_out();?>