<?php
if(!defined('IN_UCHOME')) exit('Access Denied');
$_SGLOBAL['magic']=Array
	(
	'invisible' => '隐身草',
	'friendnum' => '好友增容卡',
	'attachsize' => '附件增容卡',
	'thunder' => '雷鸣之声',
	'updateline' => '救生圈',
	'downdateline' => '时空机',
	'color' => '彩色灯',
	'hot' => '热点灯',
	'visit' => '互访卡',
	'icon' => '彩虹蛋',
	'flicker' => '彩虹炫',
	'gift' => '红包卡',
	'superstar' => '超级明星',
	'viewmagiclog' => '八卦镜',
	'viewmagic' => '透视镜',
	'viewvisitor' => '偷窥镜',
	'call' => '点名卡',
	'coupon' => '代金券',
	'frame' => '相框',
	'bgimage' => '信纸',
	'doodle' => '涂鸦板',
	'anonymous' => '匿名卡',
	'reveal' => '照妖镜',
	'license' => '道具转让许可证',
	'detector' => '探测器'
	)
?>