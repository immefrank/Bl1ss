<?php
if(!defined('IN_UCHOME')) exit('Access Denied');
$_SGLOBAL['network']=Array
	(
	'blog' => Array
		(
		'hot1' => 3,
		'cache' => 600
		),
	'pic' => Array
		(
		'hot1' => 3,
		'cache' => 700
		),
	'thread' => Array
		(
		'hot1' => 3,
		'cache' => 800
		),
	'event' => Array
		(
		'cache' => 900
		),
	'poll' => Array
		(
		'cache' => 500
		)
	)
?>