<?php

if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}
$cid = empty($_GET['cid'])?0:intval($_GET['cid']);
$list = array();
		
$query=$_SGLOBAL['db']->query("SELECT * from ".tname('commentback')." where cid=$cid");
while($row=$_SGLOBAL['db']->fetch_array($query))
{
	$row['avatar'] = avatar($row['uid'],'small');
	$list[]=$row; 
}
realname_get();
include_once template("comment/tpl/commentback");
?>