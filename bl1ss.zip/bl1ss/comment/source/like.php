<?php

if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}
$cid = empty($_GET['cid'])?0:intval($_GET['cid']);
$info['dateline']=mktime() ;
$info['author']= $_SGLOBAL['username'];

$info['authorid']=$_SGLOBAL['supe_uid'];
$info['cid']=$cid;
inserttable('commentlike',$info);
?>