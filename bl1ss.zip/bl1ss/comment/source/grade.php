<?php
header("Content-Type: text/html; charset=utf-8");
include_once('../../common.php');
function GetIP() { //获取IP 
    if ($_SERVER["HTTP_X_FORWARDED_FOR"]) 
        $ip = $_SERVER["HTTP_X_FORWARDED_FOR"]; 
    else if ($_SERVER["HTTP_CLIENT_IP"]) 
        $ip = $_SERVER["HTTP_CLIENT_IP"]; 
    else if ($_SERVER["REMOTE_ADDR"]) 
        $ip = $_SERVER["REMOTE_ADDR"]; 
    else if (getenv("HTTP_X_FORWARDED_FOR")) 
        $ip = getenv("HTTP_X_FORWARDED_FOR"); 
    else if (getenv("HTTP_CLIENT_IP")) 
        $ip = getenv("HTTP_CLIENT_IP"); 
    else if (getenv("REMOTE_ADDR"))
        $ip = getenv("REMOTE_ADDR"); 
    else 
        $ip = "Unknown"; 
    return $ip; 
} 
//检查信息
$cid = empty($_GET['cid'])?0:intval($_GET['cid']);
$idtype = empty($_GET['idtype'])?'':$_GET['idtype'];
$nowcon = array();
if($cid) {
	$query = $_SGLOBAL['db']->query("SELECT * FROM ".tname('comment')." WHERE cid='$cid'");
	$nowcon = $_SGLOBAL['db']->fetch_array($query);
}
if($_GET['act'] =='pf')
{
	$f = empty($_GET['f'])?0:intval($_GET['f']);
	$info['uid'] = $_SGLOBAL['supe_uid'];
	$info['fenshu'] = $f;
	$info['pftime'] = mktime();
	$info['ip'] = GetIP();
	$info['cid'] = $cid;
	$info['idtype'] = $idtype;
	$query = $_SGLOBAL['db']->query("SELECT * FROM ".tname('wzapp_pf')."  WHERE cid=$cid and idtype='".$idtype."' and ip='".$info['ip']."'");
	$con = $_SGLOBAL['db']->fetch_array($query);
	if(empty($con)) {
			inserttable('wzapp_pf',$info);
			$pf = GetPF($cid,$idtype);
			echo $pf['rs'].','.$pf['num'].','.$pf['pjf'];
			
	}else
	{
		echo -255;
	}

}
if($_GET['act'] == 'ding')
{
		$_SGLOBAL['db']->query("update ".tname('comment')." set dsum=dsum+1 WHERE cid=$cid");	
		$msg = intval($nowcon['dsum']) +1 ;
		echo $msg;
}
else if($_GET['act'] =='cai')
{
		$_SGLOBAL['db']->query("update ".tname('comment')." set csum=csum+1 WHERE cid=$cid");	
		$msg = intval($nowcon['csum']) +1 ;
		echo $msg;
}

?>