<?php

if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}
$id = empty($_GET['id'])?0:intval($_GET['id']);
$query=$_SGLOBAL['db']->query("SELECT * FROM ".tname('comment')." where cid=$id");
$newcon = $_SGLOBAL['db']->fetch_array($query);
if(!$newcon)
{
	showmessage('comments_do_not_exist');
}
//��Ӧ
$commentbacklist = array();
$query = $_SGLOBAL['db']->query("select * from ".tname('commentback')." where cid=".$id." ");
while ($value = $_SGLOBAL['db']->fetch_array($query)) {
		$commentbacklist[] = $value;
}

//����ģ����Ϣ
$idtype=$newcon['idtype'];
switch($idtype)
{
	case "moviesid":
		$query = $_SGLOBAL['db']->query("select * from ".tname('movies')." where id=".$newcon['id']);
		$PLModel = $_SGLOBAL['db']->fetch_array($query);
	break;
	case "booksid":
		$query = $_SGLOBAL['db']->query("select * from ".tname('books')." where id=".$newcon['id']);
		$PLModel = $_SGLOBAL['db']->fetch_array($query);
	break;
}
//�û�����������
$otherCommentlist = array();
$query = $_SGLOBAL['db']->query("select *,(select count(*) from ".tname('commentback')." where cid=a.cid) as bcount from ".tname('comment')." as a where a.uid=".$newcon['uid']."  order by bcount desc  LIMIT 0,5");
while ($value = $_SGLOBAL['db']->fetch_array($query)) {
		$otherCommentlist[] = $value;
}

if(submitcheck('consubmit')) 
{
	$info=$_POST['info'];
	$info['dateline']=mktime() ;
	$info['uname']= $_SGLOBAL['username'];
	$info['uid']=$_SGLOBAL['supe_uid'];
	$info['cid']=$id;
	$info['msg'] = preg_replace("/\[em:(\d+):]/is", "<img src=\"image/face/\\1.gif\" class=\"face\">", $info['msg']);
	inserttable('commentback',$info);
	if(!empty($_GET['ajax']))
	{
		showmessage('do_success','comment.php?do=view&id='.$id, 2);
	}
	else
	{
		$mycon['avatar'] = avatar($_SGLOBAL['supe_uid'],'small');
		$mycon['dateline'] = $info['dateline'];
		$mycon['msg']  = $info['msg'];
		$writecommentLi = 1;
	}
}

realname_get();
include_once template("comment/tpl/view");

?>