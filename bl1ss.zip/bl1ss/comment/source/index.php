<?php

if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}
$id = empty($_GET['id'])?0:intval($_GET['id']);
$idtype = empty($_GET['idtype'])?'booksid':$_GET['idtype'];
if(submitcheck('consubmit')) 
{
	$info=$_POST['info'];
//	
//	$bigimgdir='attachment/books/bigimg';//ͼƬ���·��
//	$smallimgdir='attachment/books/smallimg';
//	if(!empty($_FILES['upimgfile']['name']))
//	{
//		if(!is_dir(S_ROOT.$bigimgdir))
//		{
//			@mkdir(S_ROOT.$bigimgdir);
//		}
//		$coupic=explode('.',$_FILES['upimgfile']['name']);
//		$imgtype=$coupic[(count($coupic)-1)];
//		$imgfilename=$bigimgdir.'/'.mktime().'.'.$imgtype;
//		move_uploaded_file($_FILES['upimgfile']['tmp_name'],$imgfilename);
//		$info['bigimg']=$imgfilename;
//		$info['smallimg']=$imgfilename;
//	}
	$info['dateline']= mktime();
	$info['author']= $_SGLOBAL['username'];
	$info['uid']=$_SGLOBAL['supe_uid'];
	$info['id'] = $id;
	$info['authorid']=$_SGLOBAL['supe_uid'];
	$cid = inserttable('comment',$info,1);
	$pf = array();
	$pf['uid'] = $_SGLOBAL['supe_uid'];
	$pf['fenshu'] = $_POST['pf'];
	$pf['pftime'] = mktime();
	$pf['ip'] = '127.0.0.1';
	$pf['cid'] = $id;
	$pf['idtype']  = $idtype;
	inserttable('wzapp_pf',$pf,1);
	include_once(S_ROOT.'./source/function_feed.php');
	feed_publish_comment($cid);
	showmessage('do_success',$newmodel[$idtype].'.php?do=view&id='.$id, 2);
}
else
{
	switch($idtype)
	{
		case "booksid":
		$query=$_SGLOBAL['db']->query("SELECT * FROM ".tname("books")." where id=$id");
		$newcon = $_SGLOBAL['db']->fetch_array($query);
		break;
		case "moviesid":
		$query=$_SGLOBAL['db']->query("SELECT * FROM ".tname("movies")." where id=$id");
		$newcon = $_SGLOBAL['db']->fetch_array($query);
		break;
		case "musicid":
		$query=$_SGLOBAL['db']->query("SELECT * FROM ".tname("music")." where mid=$id");
		$newcon = $_SGLOBAL['db']->fetch_array($query);
		break;
		case "artsid":
		$query=$_SGLOBAL['db']->query("SELECT * FROM ".tname("arts")." where id=$id");
		$newcon = $_SGLOBAL['db']->fetch_array($query);
		break;
	}
	
	
}

realname_get();
include_once template("comment/tpl/index");

?>