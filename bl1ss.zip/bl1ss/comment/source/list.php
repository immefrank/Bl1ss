<?php

if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}
$idtypearr = array('booksid','moviesid','musicid','artsid');

$id = empty($_GET['id'])?0:intval($_GET['id']);
$page = empty($_GET['page'])?1:intval($_GET['page']);
if($page<1) $page=1;
$idtype = $_GET['idtype'];
if(in_array($idtype,$idtypearr))
{
    $wherestr='';
	$perpage = 5;
	if(empty($_GET['ajax']))
	{
		$perpage = 10;
		switch($idtype)
		{
			case "moviesid":
				$query = $_SGLOBAL['db']->query("select * from ".tname('movies')." where id=".$id);
				$PLModel = $_SGLOBAL['db']->fetch_array($query);
			break;
			case "booksid":
				$query = $_SGLOBAL['db']->query("select * from ".tname('books')." where id=".$id);
				$PLModel = $_SGLOBAL['db']->fetch_array($query);
			break;
		}
	}
	$perpage = mob_perpage($perpage);
	$start = ($page-1)*$perpage;
	ckstart($start, $perpage);
	if(!empty($_GET['xhp']))//仅显示好友评论
	{
		if($space['friendnum'])	
		{
			$fidarr=array();
			$query=$_SGLOBAL['db']->query("SELECT fuid FROM ".tname('friend')." main WHERE main.uid='$space[uid]' AND main.status='1'");
			  while($row=$_SGLOBAL['db']->fetch_array($query))
			  {
				$fidarr[]=$row['fuid'];
			  }
			  if($fidarr)
			  {
				$wherestr.=' and c.uid in('.implode(',',$fidarr).')';	
			  }
		}
	}
	if(!empty($_GET['by']))
   {
   		$by = $_GET['by'];
   		switch($by)
		{
			case "like":
			$wherestr.=' order by lcount desc';
			break;
			case "hot":
			$wherestr.=' order by bcount desc';
			break;
			case "new":
			$wherestr.=' order by c.dateline desc';
			break;
			case "f":
			$wherestr.=' order by c.dateline desc';
			break;
			default:
			$wherestr.=' order by c.dsum - c.csum desc';
			break;
		}
   }
   
	
	$count = $_SGLOBAL['db']->result($_SGLOBAL['db']->query("SELECT COUNT(*),(select count(1) from ".tname('commentback')." where cid=c.cid) as bcount,(select count(1) from ".tname('commentlike')." where cid=c.cid) as lcount FROM ".tname('comment')."  as c  WHERE c.id=$id and c.idtype='$idtype' $wherestr"),0);
	if(empty($_GET['act']))
	{
		$list = array();
		
		$query=$_SGLOBAL['db']->query("SELECT *,(select count(1) from ".tname('commentback')." where cid=c.cid) as bcount,(select count(1) from ".tname('commentlike')." where cid=c.cid) as lcount FROM ".tname('comment')." as c where c.idtype='$idtype' and c.id='$id' $wherestr LIMIT $start,$perpage");
		while($row=$_SGLOBAL['db']->fetch_array($query))
		{
			$row['avatar'] = avatar($row['uid'],'small');
			$queryback = $_SGLOBAL['db']->query("SELECT id,cid,msg,uid,dateline,uname FROM ".tname('commentback')." as cb where cb.cid='$row[cid]' LIMIT 0,1");
			
			while($barr=$_SGLOBAL['db']->fetch_array($queryback))
			{
				$barr['avatar'] = avatar($barr['uid'],'small');
				$row['backlist'][] = $barr;
			}
			$list[]=$row; 
		}
		$theurl='comment.php?do=list&idtype='.$idtype.'&id='.$id.'&by='.$_GET['by'];
		$multi = multi($count, $perpage, $page, $theurl);
		include_once template("comment/tpl/list");
	}else if($_GET['act'] == 'getcount')
	{
		$realpages = @ceil($count / $perpage);
		echo $realpages;
	}
	
	
	
	

}
else
{
	
}
?>