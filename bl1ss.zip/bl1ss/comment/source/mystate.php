<?php

if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}
if(empty($_SGLOBAL['supe_uid'])) {
	if($_SERVER['REQUEST_METHOD'] == 'GET') {
		//ssetcookie('_refer', rawurlencode($_SERVER['REQUEST_URI']));
	} else {
		//ssetcookie('_refer', rawurlencode('admincp.php?ac='.$_GET['ac']));
	}
	//showmessage('to_login', 'do.php?ac='.$_SCONFIG['login_action']);
	echo ' login  plsssssssssssssss';
	exit();
}
$appid = empty($_GET['appid'])?0:intval($_GET['appid']);
$idtype = empty($_GET['idtype'])?'':$_GET['idtype'];
$state = empty($_GET['state'])? "want" :$_GET['state'];
$act = empty($_GET['act'])? "" :$_GET['act'];
if($act == 'setmy')
{
	$query = $_SGLOBAL['db']->query("SELECT * from ".tname('mymodstate')." where appid=$appid and idtype='".$idtype."' and uid=".$_SGLOBAL['supe_uid']);
	$con = $_SGLOBAL['db']->fetch_array($query);
	$info['dateline']= mktime();
	$info['idtype']= $idtype;
	$info['appid']=$appid;
	$info['state']= $state;
	$info['uid']=$_SGLOBAL['supe_uid'];
	if(empty($con)) {
		
		inserttable('mymodstate',$info);
	}
	else
	{
		updatetable('mymodstate',$info,array('id'=>$con['id']));
	}
}
	$query = $_SGLOBAL['db']->query("SELECT * from ".tname('mymodstate')." where appid=$appid and idtype='".$idtype."' and uid=".$_SGLOBAL['supe_uid']);
	$con = $_SGLOBAL['db']->fetch_array($query);

	echo $con['state'];
?>