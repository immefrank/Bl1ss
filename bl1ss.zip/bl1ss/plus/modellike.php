<?php
include_once('../common.php');
$idtypearr = array('booksid','moviesid','musicid','artsid');

$id = empty($_GET['id'])?0:intval($_GET['id']);
$idtype = $_GET['idtype'];
$act= $_GET['act'];


if(!in_array($idtype,$idtypearr))
{
	exit('error');
}

if($act == 'add')
{
	$query = $_SGLOBAL['db']->query("SELECT * from ".tname('modellike')."  WHERE uid=".$_SGLOBAL['supe_uid']." and idtype='".$idtype."' and id=".$id);
	$con = $_SGLOBAL['db']->fetch_array($query);
	if(empty($con)) {
		$info = array();
		$info['id'] = $id;
		$info['idtype'] = $idtype;
		$info['uid'] = $_SGLOBAL['supe_uid'];
		$info['summary'] = '';
		inserttable('modellike',$info,1);
	}
	
	echo 'ok';
}
?>