<?php
if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}
$t = empty($_GET['t'])?'new':$_GET['t'];

$list = array();
$page = empty($_GET['page'])?1:intval($_GET['page']);
$perpage = 6;
$perpage = mob_perpage($perpage);
$start = ($page-1)*$perpage;
ckstart($start, $perpage);
$titleshow = 'list';
if($t == 'new')
{
	$subcat = empty($_GET['subcat'])?0:intval($_GET['subcat']);
	$query=$_SGLOBAL['db']->query("SELECT * FROM ".tname('books')." where xugou=$subcat  and status=1  order by id desc LIMIT $start,$perpage");
	while($row=$_SGLOBAL['db']->fetch_array($query))
	{
		$row['taglist'] = GetTag($row['id'],'books');
		$row['pf'] = GetPF($row['id'],'booksid');
		$list[]=$row;
	}
	$count = $_SGLOBAL['db']->result($_SGLOBAL['db']->query("SELECT count(1) FROM ".tname('books')." where  xugou=$subcat"),0);
	$theurl='books.php?do=list&t=new&subcat='.$subcat;
	if($subcat == 0)
	{
		$titleshow = '最新虚构图书';
	}
	else
	{
		$titleshow = '最新非虚构图书';
	}
}
else if($t == 'type')
{
	
}
else if($t == 'groom')
{
	$query=$_SGLOBAL['db']->query("SELECT * FROM ".tname('books')." where groom=1  and status=1  order by id desc LIMIT $start,$perpage");
	while($row=$_SGLOBAL['db']->fetch_array($query))
	{
		$row['taglist'] = GetTag($row['id'],'books');
		$row['pf'] = GetPF($row['id'],'booksid');
		$list[]=$row;
	}
	$count = $_SGLOBAL['db']->result($_SGLOBAL['db']->query("SELECT count(1) FROM ".tname('books')." where  groom=1"),0);
	$theurl='books.php?do=list&t=groom';
	$titleshow = '推荐图书';
}
else if($t == 'gf')
{
	$subcat = empty($_GET['subcat'])?0:intval($_GET['subcat']);
	$query=$_SGLOBAL['db']->query("SELECT *,(select AVG(fenshu) from ".tname('wzapp_pf')." where  cid=b.id and idtype='booksid') as wzpf FROM ".tname('books')." as b where b.xugou=$subcat and status=1  order by wzpf desc LIMIT $start,$perpage");
	while($row=$_SGLOBAL['db']->fetch_array($query))
	{
		$row['taglist'] = GetTag($row['id'],'books');
		$row['pf'] = GetPF($row['id'],'booksid');
		$list[]=$row;
	}
	$count = $_SGLOBAL['db']->result($_SGLOBAL['db']->query("SELECT count(1) FROM ".tname('books')." where  xugou=$subcat"),0);
	$theurl='books.php?do=list&t=gf&subcat='.$subcat;
	if($subcat == 0)
	{
		$titleshow = '高分虚构图书';
	}
	else
	{
		$titleshow = '高分非虚构图书';
	}
}
else if($t == 'rm')
{
	$subcat = empty($_GET['subcat'])?0:intval($_GET['subcat']);
	$query=$_SGLOBAL['db']->query("SELECT *,(select sum(fenshu) from ".tname('wzapp_pf')." where cid=b.id and idtype='booksid') as wzpf FROM ".tname('books')." as b where b.xugou=$subcat and status=1  order by b.viewcount desc LIMIT $start,$perpage");
	while($row=$_SGLOBAL['db']->fetch_array($query))
	{
		$row['taglist'] = GetTag($row['id'],'books');
		$row['pf'] = GetPF($row['id'],'booksid');
		$list[]=$row;
	}
	$count = $_SGLOBAL['db']->result($_SGLOBAL['db']->query("SELECT count(1) FROM ".tname('books')." where  xugou=$subcat"),0);
	$theurl='books.php?do=list&t=rm&subcat='.$subcat;
	if($subcat == 0)
	{
		$titleshow = '热门虚构图书';
	}
	else
	{
		$titleshow = '热门非虚构图书';
	}
}
else if($t == 'author')
{
	$name = $_GET['name'];
	$query=$_SGLOBAL['db']->query("SELECT * FROM ".tname('books')." where zzname='$name'  and status=1  order by id desc LIMIT $start,$perpage");
	while($row=$_SGLOBAL['db']->fetch_array($query))
	{
		$row['taglist'] = GetTag($row['id'],'books');
		$row['pf'] = GetPF($row['id'],'booksid');
		$list[]=$row;
	}
	$count = $_SGLOBAL['db']->result($_SGLOBAL['db']->query("SELECT count(1) FROM ".tname('books')." where   zzname='$name'"),0);
	$theurl='books.php?do=list&t=groom';
	$titleshow = '作者: '.$name.' 的其他图书';
}
else if($t == 'tag')
{
	
	if(empty($_GET['k']))
	{
		$taglist = array();
		$query=$_SGLOBAL['db']->query("SELECT * FROM ".tname('tag')." where tagtype='books' and status=1  ");
		while($row=$_SGLOBAL['db']->fetch_array($query))
		{
			$taglist[]=$row;
		}	
	}
	else
	{
		$k = $_GET['k'];
		$query=$_SGLOBAL['db']->query("SELECT * FROM ".tname('books')." where tag like '%$k%' and status=1   LIMIT $start,$perpage");
		while($row=$_SGLOBAL['db']->fetch_array($query))
		{
			$row['taglist'] = GetTag($row['id'],'books');
			$row['pf'] = GetPF($row['id'],'booksid');
			$list[]=$row;
			
		}
		$count = $_SGLOBAL['db']->result($_SGLOBAL['db']->query("SELECT count(1) FROM ".tname('books')." where tag like '%$k%'"),0);
		$theurl='books.php?do=tag&k='.urlencode($k);
		$titleshow = 'TAG:'.$k;
	}
}

$multi = multi($count, $perpage, $page, $theurl);
realname_get();
include_once template("books/tpl/list");

?>