<?php

if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}
$k = empty($_GET['k'])?'':$_GET['k'];
realname_get();
include_once template("books/tpl/search");

?>