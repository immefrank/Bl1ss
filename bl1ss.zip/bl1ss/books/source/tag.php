<?php
if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}
$t = empty($_GET['t'])?'new':$_GET['t'];

$list = array();

$query=$_SGLOBAL['db']->query("SELECT *,count(1) as c FROM ".tname('tag')." where  tagtype='books'  group by tagname order by c desc");
while($row=$_SGLOBAL['db']->fetch_array($query))
{
	$list[]=$row;
	
}
		
realname_get();
include_once template("books/tpl/tag");

?>