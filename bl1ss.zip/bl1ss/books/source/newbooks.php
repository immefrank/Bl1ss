<?php

if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}
$subcat = empty($_GET['subcat'])?0:intval($_GET['subcat']);
$subcatTitle = '';
$wherestr = "and a.xugou=".$subcat;
if(empty($_GET['subcat']))
{
	$wherestr ='';
}
else
{
	if($subcat==0)
	{
		$subcatTitle = '虚构';
	}
	else
	{
		$subcatTitle = '非虚构';
	}
}
//最新图书
$NewBooksList = array();
$newbooksquery=$_SGLOBAL['db']->query("SELECT a.*,b.typename FROM ".tname('books')." a left join ".tname('wzapptype')." b on b.id=a.typeid  WHERE  a.status=1 $wherestr order by a.submitdate desc LIMIT 0,6");
while ($value = $_SGLOBAL['db']->fetch_array($newbooksquery)) 
{
	$NewBooksList[]=$value;
}
$HotBooks = array();
$hotquery=$_SGLOBAL['db']->query("SELECT a.*,b.typename FROM ".tname('books')." a left join ".tname('wzapptype')." b on b.id=a.typeid  WHERE  a.status=1 order by a.viewcount desc LIMIT 0,5");
while ($value = $_SGLOBAL['db']->fetch_array($hotquery)) 
{
	$HotBooks[]=$value;
}
realname_get();
include_once template("books/tpl/newbooks");

?>