<?php
/*
	[UCenter Home] (C) 2007-2008 Comsenz Inc.
	$Id: space_blog.php 13208 2009-08-20 06:31:35Z liguode $
*/

if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}
$id = empty($_GET['id'])?0:intval($_GET['id']);

 //��ȡ����
$query = $_SGLOBAL['db']->query("SELECT * FROM ".tname('books')."  WHERE id='$id'");
$con = $_SGLOBAL['db']->fetch_array($query);

if(empty($con)) {
	showmessage('view_to_info_did_not_exist');
}

$info['viewcount'] = $con['viewcount']+1;
//���������
updatetable('books',$info,array('id'=>$con['id']));


$pf = GetPF($id,'booksid');



//�����˵�
$newguylist = array();
if(!empty($_SGLOBAL['supe_uid']))
{
	//��ʾ�����˵�����
	$wherestr = '';
	//��ú����б�
	$fidarr=array();
	$query=$_SGLOBAL['db']->query("SELECT fuid FROM ".tname('friend')." main WHERE main.uid='$space[uid]' AND main.status='1'");
	  while($row=$_SGLOBAL['db']->fetch_array($query))
	  {
		$fidarr[]=$row['fuid'];
	  }
	if($fidarr)
	  {
		$wherestr.=' and uid in('.implode(',',$fidarr).')';	
	  }
	$query = $_SGLOBAL['db']->query("SELECT * from  ".tname('share')." where type='books' and typeid=".$id." $wherestr LIMIT 0,9");
	while ($value = $_SGLOBAL['db']->fetch_array($query)) {
			$newguylist[] = $value;
	}
}
else
{
	
	//��ʾ�����˵��û�
	$query = $_SGLOBAL['db']->query("SELECT * from  ".tname('share')." where type='books' and typeid=".$id." LIMIT 0,9");
	while ($value = $_SGLOBAL['db']->fetch_array($query)) {
			$newguylist[] = $value;
	}
}

$commentcount =  $_SGLOBAL['db']->result($_SGLOBAL['db']->query("SELECT COUNT(*) FROM ".tname('comment')." WHERE idtype='booksid' and id=".$id), 0);

//�Ƿ�ϲ��
$lquery = $_SGLOBAL['db']->query("SELECT * from ".tname('modellike')."  WHERE uid=".$_SGLOBAL['supe_uid']." and idtype='booksid' and id=".$id);
$likecon = $_SGLOBAL['db']->fetch_array($lquery);
$likecount = $_SGLOBAL['db']->result($_SGLOBAL['db']->query("SELECT COUNT(*) FROM ".tname('modellike')." WHERE idtype='booksid' and id=".$id), 0);

//ϲ�����˻�ϲ��
$lovethat = array();
$likeuarr =  array();
$lovequery=$_SGLOBAL['db']->query("select uid from ".tname('modellike')." where idtype='booksid' and id=".$id." group by uid");
while ($value = $_SGLOBAL['db']->fetch_array($lovequery)) {
		$likeuarr[] = $value['uid'];
		
}
if(!empty($likeuarr))
{
	
	$lmquery=$_SGLOBAL['db']->query("select *,(select count(1) from ".tname('modellike')." where idtype='booksid' and id=b.id) as duolike from ".tname('modellike')." as ml left join ".tname('books')." as b on ml.id = b.id where ml.idtype='booksid' and ml.uid in(".implode(',',$likeuarr).") and ml.id <> ".$id." group by b.id order by duolike desc LIMIT 0,5");
	while ($value = $_SGLOBAL['db']->fetch_array($lmquery)) {
		$lovethat[] = $value;
	}
	
	//ϲ����Ȧ��
	$mtag = array();
	$mtaglist = array();
		$query = $_SGLOBAL['db']->query("SELECT m.tagname,m.tagid,m.pic,count(m.tagid) as mcount FROM ".tname('modellike')."  as  ml left join ".tname('tagspace')." as t on ml.uid= t.uid left join  ".tname('mtag')." as m  on m.tagid = t.tagid where ml.idtype='booksid' and ml.id=".$id." group by m.tagid order by mcount desc LIMIT 0,9");
		while ($value = $_SGLOBAL['db']->fetch_array($query)) {
			if(empty($value['pic'])) {
				$value['pic'] = 'image/nologo.jpg';
			}
			$mtaglist[] = $value;
			
		}
	if($mtaglist) {
		$mtag = sarray_rand($mtaglist, 9);
	}
}
include_once template("books/tpl/view");
?>
