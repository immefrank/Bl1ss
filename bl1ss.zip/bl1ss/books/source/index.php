<?php

if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}
function GetBooksList($where)
{
	global $_SGLOBAL;
	$list = array();
	$q=$_SGLOBAL['db']->query("SELECT b.id, b.`smallimg`, b.`bigimg`, `conname`, `zzname`, `typeid`, `tag`, `update`, `apptext`, `username`, `userid`, `submitdate`, `status`, `Press`, `lmid`, `music`, `viewcount`, `groom`, `authorabout`, `pf`, `pjf`, `gaishu`, `fenxi`, `xugou`, `authorid`,(select AVG(fenshu) from ".tname('wzapp_pf')." where cid=b.id and idtype='booksid') as wzpf FROM ".tname('books')." as b left join ".tname('author')." as ah on b.authorid=ah.id  WHERE  ".$where);
	while ($v = $_SGLOBAL['db']->fetch_array($q)) 
	{
		$v['pf'] = GetPF($v['id'],'booksid');
		$v['taglist'] = GetTag($v['id'],'books');
		$list[]=$v;
	}
	return $list;
}
//�����鹹
$NewXuGou = GetBooksList('xugou=0 and status=1 order by id desc LIMIT 0,4');
$NewNotXuGou = GetBooksList('xugou=1 and status=1 order by id desc LIMIT 0,4');
$HotXuGou = GetBooksList('xugou=0 and status=1 order by viewcount desc LIMIT 0,4');
$HotNotXuGou = GetBooksList('xugou=1 and status=1 order by viewcount desc LIMIT 0,4');
$HeightXuGou = GetBooksList('xugou=0 and status=1 order by wzpf desc LIMIT 0,4');
$HeightNotXuGou = GetBooksList('xugou=1 and status=1 order by wzpf desc LIMIT 0,4');
$GroomBooks = GetBooksList('groom=1 and status=1 order by groom desc LIMIT 0,4');

//���ű�ǩ
$hottag = array();
$query=$_SGLOBAL['db']->query("SELECT *,count(1) as c FROM ".tname('tag')." where  tagtype='books'  group by tagname order by c desc");
while($row=$_SGLOBAL['db']->fetch_array($query))
{
	$hottag[]=$row;
	
}
//���Ⱥ��
$grouplist = array();
$query=$_SGLOBAL['db']->query("SELECT * FROM ".tname('mtag')." where  fieldid='1'  order by membernum  desc LIMIT 0,4");
while($row=$_SGLOBAL['db']->fetch_array($query))
{
	if(empty($row['pic'])) {
				$row['pic'] = 'image/nologo.jpg';
			}
	$grouplist[]=$row;
	
}
realname_get();
include_once template("books/tpl/index");

?>