<?php

if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}

realname_get();
include_once template("books/tpl/my");

?>