<?php

if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}
$id = empty($_GET['id'])?0:intval($_GET['id']);
$query = $_SGLOBAL['db']->query("SELECT * from ".tname('arts')." where id=$id ");
$con = $_SGLOBAL['db']->fetch_array($query);
if(empty($con)) {
	showmessage('view_to_info_did_not_exist');
}

$pf = GetPF($id,'artid');
$whoover = array();
$query=$_SGLOBAL['db']->query("SELECT * FROM ".tname('mymodstate')." as ms left join ".tname('member')." as m on ms.uid=m.uid  WHERE ms.idtype='artid' and ms.appid=$id");
  while($row=$_SGLOBAL['db']->fetch_array($query))
  {
  	$row['avatar'] = avatar($row['uid'],'small');
	$whoover[]=$row;
  }
$_SGLOBAL['db']->query("update ".tname('arts')." set viewnum=viewnum+1 WHERE id=$id");	
include_once template("arts/tpl/view");

?>