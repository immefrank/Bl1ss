<?php

if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}
if(submitcheck('consubmit')) 
{
	$info=$_POST['info'];
	
	$bigimgdir='attachment/arts/bigimg';//ͼƬ���·��
	$smallimgdir='attachment/arts/smallimg';
	if(!empty($_FILES['upimgfile']['name']))
	{
		if(!is_dir(S_ROOT.$bigimgdir))
		{
			@mkdir(S_ROOT.$bigimgdir);
		}
		$coupic=explode('.',$_FILES['upimgfile']['name']);
		$imgtype=$coupic[(count($coupic)-1)];
		$imgfilename=$bigimgdir.'/'.mktime().'.'.$imgtype;
		move_uploaded_file($_FILES['upimgfile']['tmp_name'],$imgfilename);
		$info['pic']=$imgfilename;
	}
	$info['dateline']=mktime();
	$info['state']=0;
	$info['uid']=$_SGLOBAL['supe_uid'];
	
	$bid = inserttable('arts',$info,1);
	
	$tagarr = array();
	$tagarr = explode(",",$info['tag']);
	foreach($tagarr as  $t)
	{
		$tag = array();
		$tag['tagname'] = $t;
		$tag['dateline'] = mktime();
		$tag['blognum'] = 0;
		$tag['close'] = 0;
		$tag['tagtype'] = 'arts';
		$tag['id'] =$bid;
		inserttable('tag',$tag);
	}
	showmessage('do_success','arts.php', 2);
}
realname_get();
include_once template("arts/tpl/create");

?>