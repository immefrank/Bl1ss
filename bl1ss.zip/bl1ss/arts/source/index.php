<?php

if(!defined('IN_UCHOME')) {
	exit('Access Denied');
}
//������Ʒ
$newarts = array();
$query=$_SGLOBAL['db']->query("SELECT * from ".tname("arts")." order by dateline desc LIMIT 0,6");
while ($value = $_SGLOBAL['db']->fetch_array($query)) 
{
	$value['pf'] = GetPF($value['id'],'artsid');
	$value['tag'] = GetTag($value['id'],'arts');
	$newarts[]=$value;
}

//��������Ʒ
$hotarts = array();
$query=$_SGLOBAL['db']->query("SELECT *,(select count(1) from ".tname("comment")." where id=m.id and idtype='artsid') as ccount  from ".tname("arts")." as m order by ccount desc LIMIT 0,6");
while ($value = $_SGLOBAL['db']->fetch_array($query)) 
{
	$value['pf'] = GetPF($value['id'],'artsid');
	$value['tag'] = GetTag($value['id'],'arts');
	$hotarts[]=$value;
}
//�߷�����Ʒ
$harts = array();
$query=$_SGLOBAL['db']->query("SELECT *,(select sum(fenshu) from ".tname('wzapp_pf')." where cid=m.id and idtype='artsid') as wzpf from ".tname("arts")." as m order by wzpf desc LIMIT 0,6");
while ($value = $_SGLOBAL['db']->fetch_array($query)) 
{
	$value['pf'] = GetPF($value['id'],'artsid');
	$value['tag'] = GetTag($value['id'],'arts');
	$harts[]=$value;
}
//�Ƽ�����Ʒ
$groomarts = array();
$query=$_SGLOBAL['db']->query("SELECT *  from ".tname("arts")." where groom=1 LIMIT 0,4");
while ($value = $_SGLOBAL['db']->fetch_array($query)) 
{
	$value['pf'] = GetPF($value['id'],'artsid');
	$value['tag'] = GetTag($value['id'],'arts');
	$groomarts[]=$value;
}

//���ű�ǩ
$taglist = array();
$query=$_SGLOBAL['db']->query("SELECT *,count(1) as c FROM ".tname('tag')." where  tagtype='arts'  group by tagname order by c desc");
while ($value = $_SGLOBAL['db']->fetch_array($query)) 
{
	$taglist[]=$value;
}

//���Ⱥ��
$grouplist = array();
$query=$_SGLOBAL['db']->query("SELECT * FROM ".tname('mtag')." where  fieldid='4'  order by membernum  desc LIMIT 0,4");
while($row=$_SGLOBAL['db']->fetch_array($query))
{
	if(empty($row['pic'])) {
				$row['pic'] = 'image/nologo.jpg';
			}
	$grouplist[]=$row;
	
}

realname_get();
include_once template("arts/tpl/index");

?>